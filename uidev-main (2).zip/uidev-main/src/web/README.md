## Development server

Execute `npx nx serve shell` from a command line. This will build and run shell and all the federated apps. It's accessible from  http://localhost:4200/. The `--devRemotes=myapp` argument can be added to watch for changes on the app you're currently working on.

## Generate an application

Run `npx nx g @nrwl/angular:remote myapp --port=PORT` to generate an application. Avoid hyphens, underscores, and proper case. Nx will replace with hyphens which don't play nice with module federation.

When using Nx, you can create multiple applications and libraries in the same workspace.

## Generate a library

Run `npx nx g @nrwl/angular:lib my-lib` to generate a library.

Libraries are shareable across libraries and applications. They can be imported from `@uid/mylib`.

## Code scaffolding

Run `npx nx g @nrwl/angular:component my-component --project=myapp` to generate a new component.

## Build

Run `npx nx run-many --all --target=build --parallel` to build all the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Build Docker Image

Run `docker build -t myapp:latest --build-arg buildcommand=myapp:build:production .` to build the app into a production docker image.

## Running unit tests

If you're using VS Code, try the [Jest plugin](https://marketplace.visualstudio.com/items?itemName=Orta.vscode-jest) from Orta. It adds a nice test explorer, automatically runs all tests on save, and adds support for debugging your tests.

Run `npx nx run-many --all --target=test --parallel --coverage` to execute the unit tests via [Jest](https://jestjs.io). This will also create code coverage reports under the `./coverage` folder.

Run `npx nx affected:test` to only execute unit tests affected by your changes.

## Linting

VS Code should show linting errors while editing. To check for lint errors in all files and automatically fix them, run `npx nx run-many --all --target=lint --parallel --fix` from a command line.

## Understand your workspace

Run `npx nx dep-graph` to see a diagram of the dependencies of your projects.

## Further help

Visit the [Nx Documentation](https://nx.dev) to learn more.
