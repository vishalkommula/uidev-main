/* eslint-disable @typescript-eslint/no-unused-vars */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import getACHFilterInquirySearchRecord from '../mock-data/achfilter-inquiry-response.json';
import getACHFilterInquiryCopyFilterAccountList from '../mock-data/accountdetails-response.json';
import getACHFilterInformationDefaultValues from '../mock-data/achfilterinformation-defaultValues-response.json';
import { ACHFilterInquiryDeleteRequest } from '../models/achfilter-inquiry-delete-request.model';
import { ACHFilterInquiryModRequest } from '../models/achfilter-inquiry-mod-request.model';
import { ACHFilterInquiryModResponse } from '../models/achfilter-inquiry-mod-response.model';
import { AchFilterInquiryRequest } from '../models/achfilter-inquiry-request.model';
import { AchFilterInquiryResponse } from '../models/achfilter-inquiry-response.model';
import { CopyFilterAccountDetailsResponse } from '../models/copyfilter-accountdetails-response.model';
import { CopyFilterAccountDetailRequest } from '../models/copyfilter-request.model';
import { ACHFilterInformationDefaultValueResponse } from '../models/achfilter-information-defaultvalue-response.model';
import { FaultMsgRec } from '@uid/uid-models';

@Injectable({
    providedIn: 'root',
})
export class DataService {
    pipe: any;

    faultRec: FaultMsgRec[]=[{
        errCode:'100372',
        errCat:'Error',
        errDesc:'Value must be C = Credit or D = Debit.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.achCompanyName INDEX',
        errElemVal:'/1',
        errLoc:'ACFLTRMOD',
    },
    {
        errCode:'100372',
        errCat:'Error',
        errDesc:'status should not be active.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.achFilterStateType INDEX',
        errElemVal:'/1',
        errLoc:'LNBILLMOD',
    },
    {
        errCode:'100372',
        errCat:'Error',
        errDesc:'lowAmount should always be lesser than higherAmount.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.lowAmount INDEX',
        errElemVal:'/1',
        errLoc:'LNBILLMOD',
    },
    {
        errCode:'100372',
        errCat:'Error',
        errDesc:'Value must be C = Credit or D = Debit.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.achCompanyName INDEX',
        errElemVal:'/1',
        errLoc:'ACFLTRMOD',
    },
    {
        errCode:'100372',
        errCat:'Error',
        errDesc:'status should not be active.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.achFilterStateType INDEX',
        errElemVal:'/1',
        errLoc:'LNBILLMOD',
    },
    {
        errCode:'100372',
        errCat:'Error',
        errDesc:'lowAmount should always be lesser than higherAmount.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.lowAmount INDEX',
        errElemVal:'/1',
        errLoc:'LNBILLMOD',
    },
    {
        errCode:'200923',
        errCat:'Error',
        errDesc:'achFilterAacounterPerExceptionItemField should not be 20.',
        errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.achFilterAacounterPerExceptionItemField',
        errElemVal:'',
        errLoc:'LNBILLMOD',
    }];

    constructor(private http: HttpClient) {}

    getACHFilterInquiryInformationDetails(request: AchFilterInquiryRequest): Observable<AchFilterInquiryResponse> {
        const clone = JSON.parse(JSON.stringify(getACHFilterInquirySearchRecord));
        const modelValue: AchFilterInquiryResponse = {
            srchMsgRsHdr: clone.srchMsgRqHdr,
            achFilterInquirySearchRecord: clone.achFilterInquirySearchRecord,
            showACHAutoReturn: false,
        };
        return of(modelValue);
    }

    updateACHFilterInquiry(request: ACHFilterInquiryModRequest): Observable<ACHFilterInquiryModResponse> {
    //TODO: removed after API integration.to view request.
    //TODO : replace with api call
        const clone = JSON.parse(JSON.stringify(getACHFilterInquirySearchRecord));

        const modelValue: ACHFilterInquiryModResponse = {
            srchMsgRsHdr: clone.srchMsgRqHdr,
            achFilterInquirySearchRecord: {
                achFilterFields: clone.achFilterInquirySearchRecord.achFilterFields,
                achFilterInquiryInformation: request.destinationAccountDetails.acctId === '' ? request.achFilterInquirySearchRecords.achFilterInquiryInformation : clone.achFilterInquirySearchRecord.achFilterInquiryInformation,
                exceptionItems: request.destinationAccountDetails.acctId === '' ? request.achFilterInquirySearchRecords.exceptionItems : clone.achFilterInquirySearchRecord.exceptionItems,
            },
            showACHAutoReturn: true,
            faultRecInfoArray: request.achFilterInquirySearchRecords.achFilterInquiryInformation?.achFilterAacounterPerExceptionItemField=== 20 ?
                this.faultRec : [],
        };
        return of(modelValue);
    }
    // this method get the default value for ach filter finromation
    getDefaultValueACHFilterInformation(request: AchFilterInquiryRequest): Observable<ACHFilterInformationDefaultValueResponse> {
    //TODO: removed after API integration.to view request.
    //TODO : replace with api call
        const clone = JSON.parse(JSON.stringify(getACHFilterInformationDefaultValues));
        return of(clone);
    }

    // this fucntion used to delete all the records in the ACH Filter Inquiry.
    deleteACHFilterInquiry(request: ACHFilterInquiryDeleteRequest): Observable<AchFilterInquiryResponse> {
    //TODO : replace with api call
        const clone = JSON.parse(JSON.stringify(getACHFilterInquirySearchRecord));

        const deleteResponse: AchFilterInquiryResponse = {
            srchMsgRsHdr: clone.srchMsgRqHdr,
            showACHAutoReturn: false,
            achFilterInquirySearchRecord: {
                achFilterFields: clone.achFilterInquirySearchRecord.achFilterFields,
                achFilterInquiryInformation: {},
                exceptionItems: [],
            },
        };
        return of(deleteResponse);
    }

    // this function used to get the copyfilter account list.
    getCopyFilterAccountDetails(request: CopyFilterAccountDetailRequest): Observable<CopyFilterAccountDetailsResponse> {
        const clone = JSON.parse(JSON.stringify(getACHFilterInquiryCopyFilterAccountList));
        return of(clone);
    }
}
