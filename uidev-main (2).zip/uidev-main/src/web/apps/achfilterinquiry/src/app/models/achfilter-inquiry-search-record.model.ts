import { ACHFilterInquiryInformation } from './achfilter-inquiry-information.model';
import { AchFilterInquiryRecord } from './achfilter-inquiry-record.model';
import { SvcDescInfoRecModel } from './achfilter-inquiry-svcdescinfrorec.model';

export interface ACHFilterInquirySearchRecordModel {
  achFilterInquiryInformation?: ACHFilterInquiryInformation;
  exceptionItems?: AchFilterInquiryRecord[];
  // this property holds the dropdown values of each type.
  achFilterFields?: SvcDescInfoRecModel[];
}
