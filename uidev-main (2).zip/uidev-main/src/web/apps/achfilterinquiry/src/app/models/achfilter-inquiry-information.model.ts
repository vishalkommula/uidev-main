export interface ACHFilterInquiryInformation {
    allowPostivePayTypeField?: string;
    achAllowAllDebitsField?: string;
    achAlllowAllCreditsField?: string;
    achFilterOneTimeSetupField?: number;
    achFilterStatementCycleChangeField?: number;
    achFilterPerExceptionItemField?: number;
    achFilterAacounterOneTimeSetupField?: number;
    achFilterAacounterStatementCycleChangeField?: number;
    achFilterAacounterPerExceptionItemField?: number;
    accountAnalysisDescriptionField?: string;
}
