import { DateFormatterType, FieldMode, PageMode } from '@uid/uid-models';
import { DateTime } from 'luxon';
import { AchFilterFieldsType, ChangeStatusEnum } from '../../models/achfilter-inquiry.resource';
import * as achFilterFunction from '../achfilterinquiry/achfilterinquiry.function';
describe('ACHFilter Inquiry Function Test', () => {
    it('achfilterinquiryformfield should be executed', () => {
        const fields = achFilterFunction.getAchFilterInformationFormField();
        expect(fields).toBeTruthy();
    });

    it('hideaccountAnalysisDescriptionField should return true when accountAnalysisDescriptionField is not null', () => {
        const retVal = achFilterFunction.hideaccountAnalysisDescriptionField({ accountAnalysisDescriptionField: 'data1' } as any, {} as any, {} as any);
        expect(retVal).toStrictEqual(false);
    });

    it('hideaccountAnalysisDescriptionField should return true when accountAnalysisDescriptionField is null', () => {
        const retVal = achFilterFunction.hideaccountAnalysisDescriptionField({ accountAnalysisDescriptionField: null } as any, {} as any, {} as any);
        expect(retVal).toStrictEqual(true);
    });

    it('aCHFilterAccountAnalysisCountersLabel should return true when accountAnalysisDescriptionField is not null', () => {
        const retVal = achFilterFunction.aCHFilterAccountAnalysisCountersLabel({ accountAnalysisDescriptionField: 'data1' } as any, {} as any, {} as any);
        expect(retVal).toStrictEqual('ACH Filter Account Analysis Counters');
    });

    it('aCHFilterAccountAnalysisCountersLabel should return true when accountAnalysisDescriptionField is null', () => {
        const retVal = achFilterFunction.aCHFilterAccountAnalysisCountersLabel({ accountAnalysisDescriptionField: null } as any, {} as any, {} as any);
        expect(retVal).toStrictEqual('ACH Filter Charges');
    });

    it('positivePayAccountAnalysisCountersLabel should return true when accountAnalysisDescriptionField is not null', () => {
        const retVal = achFilterFunction.positivePayAccountAnalysisCountersLabel(
      { accountAnalysisDescriptionField: 'data1' } as any, {} as any, {} as any);
        expect(retVal).toStrictEqual('Positive Pay Account Analysis Counters');
    });

    it('positivePayAccountAnalysisCountersLabel should return true when accountAnalysisDescriptionField is null', () => {
        const retVal = achFilterFunction.positivePayAccountAnalysisCountersLabel({ accountAnalysisDescriptionField: null } as any, {} as any, {} as any);
        expect(retVal).toStrictEqual('Positive Pay Charges');
    });

    it('getOptions should return dropdown Value for StandardEntryClass', () => {
        const retVal = achFilterFunction.getOptions(
      { options:{ formState:{ achFilterFields:[{ description:AchFilterFieldsType.StandardEntryClass,elemCancocctype:[1,2,3] }] } },
          templateOptions:{ dropdownType:AchFilterFieldsType.StandardEntryClass } } as any);
        expect(retVal).toStrictEqual([1,2,3]);
    });

    it('getOptions should return dropdown Value for AllowTransactionType', () => {
        const retVal = achFilterFunction.getOptions(
      { options:{ formState:{ achFilterFields:[{ description:AchFilterFieldsType.AllowTransactionType,elemCancocctype:[1,2,3] }] } },
          templateOptions:{ dropdownType:AchFilterFieldsType.AllowTransactionType } } as any);
        expect(retVal).toStrictEqual([1,2,3]);
    });

    it('getOptions should return dropdown Value for CompanyAllowType', () => {
        const retVal = achFilterFunction.getOptions(
      { options:{ formState:{ achFilterFields:[{ description:AchFilterFieldsType.CompanyAllowType,elemCancocctype:[1,2,3] }] } },
          templateOptions:{ dropdownType:AchFilterFieldsType.CompanyAllowType } } as any);
        expect(retVal).toStrictEqual([1,2,3]);
    });

    it('getOptions should return dropdown Value for FilterStateType', () => {
        const retVal = achFilterFunction.getOptions(
      { options:{ formState:{ achFilterFields:[{ description:AchFilterFieldsType.FilterStateType,elemCancocctype:[1,2,3] }] } },
          templateOptions:{ dropdownType:AchFilterFieldsType.FilterStateType } } as any);
        expect(retVal).toStrictEqual([1,2,3]);
    });

    it('isViewScreen should return true', () => {
        const retVal = achFilterFunction.isViewScreen(
      { options:{ formState:{ pageMode:PageMode.Inquiry } } } as any);
        expect(retVal).toStrictEqual(true);
    });

    it('standardEntryClassOnchange should return Yes when standardEntryClassOnchange is UnChecked', () => {
        const field = {
            model: {
                achStandardEntryClassDesc: '',
            },
        };
        const event = {
            originalEvent: {
                srcElement:{
                    innerText:'121313',
                }
            },
        };
        achFilterFunction.standardEntryClassOnchange(field, event);
        expect(field.model.achStandardEntryClassDesc).toStrictEqual('121313');
    });

    it('dateISOFormatter returns formatted date', () => {
        const dateTime = DateTime.local(2018, 12, 19, 11, 25);
        const result = achFilterFunction.dateISOFormatter(dateTime.toISO());
        expect(result).toEqual(dateTime.toFormat(DateFormatterType.DisplayedDateFormatter));
    });

    it('dateISOFormatter returns input as is if not in ISO format', () => {
        expect(achFilterFunction.dateISOFormatter(undefined as any)).toEqual(undefined);
        expect(achFilterFunction.dateISOFormatter(null as any)).toEqual(null);
        expect(achFilterFunction.dateISOFormatter('' as any)).toEqual('');
        expect(achFilterFunction.dateISOFormatter('12/19/2018' as any)).toEqual('12/19/2018');
        expect(achFilterFunction.dateISOFormatter('12/19/2018' as any)).toEqual('12/19/2018');
    });

    it('setAchFilterStateTypFieldMode should return FieldMode is Inquiry when changeStatus is newly added.', () => {
        const field={ form: { get:jest.fn() },model:{ changeStatus:ChangeStatusEnum.Newlyadded } };
        const result= achFilterFunction.setAchFilterStateTypFieldMode( field as any);
        expect(result).toBe(FieldMode.Inquiry);
    });

    it('setAchFilterStateTypFieldMode should return FieldMode is Edit when changeStatus is newly added.', () => {
        const field={ form: { get:jest.fn() },model:{ changeStatus:ChangeStatusEnum.None } };
        const result= achFilterFunction.setAchFilterStateTypFieldMode( field as any);
        expect(result).toBe(FieldMode.Edit);
    });
});
