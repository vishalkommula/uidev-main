import { FaultMsgRec, SearchResponseHeaderModel } from '@uid/uid-models';
import { ACHFilterInquirySearchRecordModel } from './achfilter-inquiry-search-record.model';

export interface ACHFilterInquiryModResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    // achfltrsrchrec model which holds the excetion item details and ach information details
    achFilterInquirySearchRecord: ACHFilterInquirySearchRecordModel;
    faultRecInfoArray: FaultMsgRec[];
    showACHAutoReturn: boolean;
}
