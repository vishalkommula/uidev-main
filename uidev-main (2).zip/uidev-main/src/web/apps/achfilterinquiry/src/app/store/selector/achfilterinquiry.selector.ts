import { createFeatureSelector, createSelector } from '@ngrx/store';
import { FormlyFormOptions } from '@ngx-formly/core';
import { FormWidth, ResultInfoMessage } from '@uid/uid-models';
import { deepClone, formatErrorMessages } from '@uid/uid-utilities';
import { findErrElementForACHFilter } from '../../component/achfilterinquiry/achfilterinquiry.function';
import {
    ACHFilterInquiryInformationFormState,
    ExceptionDetailFormState,
} from '../../models/achfilter-inquiry-form.model';
import { AchFilterInquiryRecord } from '../../models/achfilter-inquiry-record.model';
import { ChangeStatusEnum } from '../../models/achfilter-inquiry.resource';
import { ACHFilterInquiryState } from '../state/achfilterinquiry.state';

export const selectRoot = createFeatureSelector<ACHFilterInquiryState>('achFilterInquiry');

// this selector is used to display the warning from API.
export const selectAchFltInquirySearchMessageResponseHeader = createSelector(
    selectRoot,
    (state) => state.achFilterInquiryResponse.srchMsgRsHdr
);

// this selector is used to display the ach filter information and holds all ACH Fiter inquiry record irrespective of delete status.
export const selectAchFilterInquirySearchRecord = createSelector(selectRoot, (state) =>
    deepClone(state.achFilterInquiryResponse?.achFilterInquirySearchRecord)
);

// this is used to show the dropdown Values in formly.
export const selectAchFilterFields = createSelector(selectRoot, (state) => {
    const achFilterFields = state.achFilterInquiryResponse?.achFilterInquirySearchRecord?.achFilterFields;
    return achFilterFields;
});

export const selectShowACHAutoReturn = createSelector(
    selectRoot,
    (state) => state.achFilterInquiryResponse.showACHAutoReturn
);

export const selectExceptionItemId = createSelector(selectRoot, (state) => state.selectedExceptionItemId);

export const selectPageMode = createSelector(selectRoot, (state) => state.pageMode);

export const selectFaultRecArray = createSelector(selectRoot, (state) => state.faultRecInfoArray);

export const selectErrorMessages = createSelector(selectFaultRecArray, (faultMessages) => {
    if (faultMessages.length) {
        return formatErrorMessages(faultMessages as ResultInfoMessage[], findErrElementForACHFilter);
    }
    return faultMessages;
});

// Extract the ExceptionItemID from Array of Error Messages
export const selectErrorMessagesItemID = createSelector(
    selectErrorMessages,
    selectAchFilterInquirySearchRecord,
    (errorMessages, achFilterInquirySearchRecord) => {
        let getArrayOfErrorMessagesAtIndex: number[] = [];
        // extract errElemVal and remove duplicate from array.
        errorMessages
            .filter((x) => x.errElemVal !== '')
            .forEach((x) => {
                const errElemVal = isNaN(+x.errElemVal) ? -1 : +x.errElemVal - 1;
                if (getArrayOfErrorMessagesAtIndex.indexOf(errElemVal) === -1) {
                    getArrayOfErrorMessagesAtIndex.push(errElemVal);
                }
            });
        // sorting getArrayOfErrorMessagesAtIndex in ascending order to show first record selected.
        getArrayOfErrorMessagesAtIndex = getArrayOfErrorMessagesAtIndex.sort((n1, n2) => n1 - n2);

        // Extracting exceptionItemID from getArrayOfErrorMessagesAtIndex.
        const errorMessagesItemIDList: string[] = [];
        if (getArrayOfErrorMessagesAtIndex?.length > 0) {
            getArrayOfErrorMessagesAtIndex?.forEach((x: number) => {
                if (x !== -1) {
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    errorMessagesItemIDList.push(achFilterInquirySearchRecord.exceptionItems![x].exceptionItemId ?? '');
                }
            });
        }
        return errorMessagesItemIDList;
    }
);

// filter the exception items which are not marked as delete in changeStatus.
// setting hasError to true when there is a error
export const selectExceptionItems = createSelector(
    selectRoot,
    selectErrorMessagesItemID,
    (state, errorMessagesItemIDList) => {
        const expectionItems = state.achFilterInquiryResponse?.achFilterInquirySearchRecord?.exceptionItems?.filter(
            (x) => x.changeStatus !== ChangeStatusEnum.Delete
        );

        if (errorMessagesItemIDList && errorMessagesItemIDList.length > 0) {
            // setting the
            const updatedExceptionItems: AchFilterInquiryRecord[] = [];
            expectionItems?.forEach((element) => {
                if (element.exceptionItemId && errorMessagesItemIDList.includes(element.exceptionItemId)) {
                    return updatedExceptionItems.push({ ...element, hasError: true });
                }
                return updatedExceptionItems.push({ ...element });
            });
            return updatedExceptionItems;
        }
        return expectionItems ? [...expectionItems] : [];
    }
);

// this selector is used to display selected exception item.
// this model used to bind the exception item formly model.
export const selectExceptionDetail = createSelector(
    selectExceptionItems,
    selectExceptionItemId,
    (exceptionItems, exceptionItemId) => {
        const exceptionDetail = exceptionItems?.find(
            (x: AchFilterInquiryRecord) => x.exceptionItemId === exceptionItemId
        );
        return { ...exceptionDetail };
    }
);

// Extract the current Index of selected Exeption ItemID
export const selectCurrentIndex = createSelector(
    selectExceptionItems,
    selectExceptionItemId,
    (exceptionItems, exceptionItemID) => exceptionItems?.findIndex((x) => x.exceptionItemId === exceptionItemID) ?? -1
);

// this selector is used for ach filter information formlyOptions
export const selectAchFilterInformationFormlyOptions = createSelector(
    selectPageMode,
    selectErrorMessages,
    (pageMode, errorMessages) => {
        const getErrorMessages = errorMessages.filter((x) => x.errElemVal === '');
        const formState: ACHFilterInquiryInformationFormState = {
            pageMode: pageMode,
            width: FormWidth.Full,
            errorMessages: getErrorMessages,
        };
        return formState as FormlyFormOptions;
    }
);

// this selector is used for Exception Item formstate
// this selector subscribe to the current index to show the error Messages based on index.
export const selectExceptionDetailFormlyOptions = createSelector(
    selectPageMode,
    selectAchFilterFields,
    selectCurrentIndex,
    selectErrorMessages,
    (pageMode, achFilterFields, selectedIndex, errorMessages) => {
        const getErrorMessages = errorMessages.filter((x) => Number(x.errElemVal) - 1 === selectedIndex);
        const formState: ExceptionDetailFormState = {
            pageMode: pageMode,
            width: FormWidth.Medium,
            achFilterFields: achFilterFields ?? [],
            errorMessages: getErrorMessages,
        };
        return formState as FormlyFormOptions;
    }
);

// this selector is used to get the account list from the copyfilter response.
export const selectAccountList = createSelector(
    selectRoot,
    (state) => state.copyFilterAccountDetailsResponse.accountDetails
);
