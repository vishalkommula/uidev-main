import { FaultMsgRec, PageMode } from '@uid/uid-models';
import { AchFilterInquiryResponse } from '../../models/achfilter-inquiry-response.model';
import { CopyFilterAccountDetailsResponse } from '../../models/copyfilter-accountdetails-response.model';

export interface ACHFilterInquiryState {
  achFilterInquiryResponse: AchFilterInquiryResponse;
  // this property holds the selected exception items ID. which will be used for change the status for delete and modified .
  // for particular item.
  selectedExceptionItemId: string;
  pageMode: PageMode;
  faultRecInfoArray: FaultMsgRec[];
  copyFilterAccountDetailsResponse: CopyFilterAccountDetailsResponse;
}
