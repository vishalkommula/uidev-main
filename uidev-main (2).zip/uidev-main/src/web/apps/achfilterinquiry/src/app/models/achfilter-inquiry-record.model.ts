import { BaseGridError } from '@uid/uid-models';
import { ChangeStatusEnum } from './achfilter-inquiry.resource';

export interface AchFilterInquiryRecord extends BaseGridError {
  achFilterStateType?: string;
  achCompanyId?: string;
  achCompanyName?: string;
  achStandardEntryClass?: string | null;
  lowAmount?: number;
  highAmount?: number;
  achBankingRountingNumber?: number | null;
  achAllowTransactionType?: string | null;
  achCompanyAllowType?: string | null;
  expirationDate?: string | null;
  achFilterRemark?: string;
  achCompanyFilterId?: string;
  exceptionItemId?: string;
  isModified?: boolean;
  changeStatus?: ChangeStatusEnum;
}
