import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { HomeModule } from './component/home/home.module';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
@NgModule({
    declarations: [AppComponent],
    imports: [BrowserModule,
        HomeModule,
        StoreModule.forRoot({}),
        EffectsModule.forRoot([]),
        RouterModule.forRoot([{ path: 'achfilterinquiry', component: HomeComponent }]),
    ],
    providers: [],
    bootstrap: [AppComponent],
})
export class AppModule {}
