import { FormWidth, PageMode } from '@uid/uid-models';
import * as Selectors from '../selector/achfilterinquiry.selector';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

describe('ACH Filter Inquiry Tests', () => {
    it('selectPageMode should project pageMode', () => {
        const result = Selectors.selectPageMode.projector({ pageMode: PageMode.Inquiry });

        expect(result).toBe(PageMode.Inquiry);
    });

    it('selectAchFltInquirySearchMessageResponseHeader should header message', () => {
        const result = Selectors.selectAchFltInquirySearchMessageResponseHeader.projector({ achFilterInquiryResponse: { srchMsgRsHdr: { header: 1 } } });

        expect(result).toStrictEqual({ header: 1 });
    });

    it('selectAchFilterFields should header achFilterFields', () => {
        const result = Selectors.selectAchFilterFields.projector({ achFilterInquiryResponse: { achFilterInquirySearchRecord: { achFilterFields: { header: 1 } } } });

        expect(result).toStrictEqual({ header: 1 });
    });


    it('selectAchFilterInquirySearchRecord should header achFilterFields', () => {
        const result = Selectors.selectAchFilterInquirySearchRecord.projector({ achFilterInquiryResponse: { achFilterInquirySearchRecord: { achFilterFields: { header: 1 } } } });

        expect(result).toStrictEqual({ achFilterFields: { header: 1 } });
    });

    it('selectFaultRecArray should project faultRecArray', () => {
        const state = { faultRecInfoArray: { errorCode: 'hello header' } };
        const result = Selectors.selectFaultRecArray.projector(state);

        expect(result).toMatchSnapshot();
    });

    it('selectAchFilterInformationFormlyOptions should project an options object', () => {
        const testFormlyOptions = {
            width: FormWidth.Full,
            pageMode: PageMode.Add,
            errorMessages:[{ errElemVal:'' }]
        };
        const result = Selectors.selectAchFilterInformationFormlyOptions.projector(PageMode.Add,[{ errElemVal:'' }] as any);
        expect(result).toStrictEqual(testFormlyOptions);
    });

    it('selectExceptionDetailFormlyOptions should project an options object', () => {
        const testFormlyOptions = {
            width: FormWidth.Medium,
            pageMode: PageMode.Add,
            achFilterFields: { header: 1 } as any,
            errorMessages:[{ errElemVal:'2323' }]
        };
        const result = Selectors.selectExceptionDetailFormlyOptions.projector(PageMode.Add, { header: 1 } as any,2322,[{ errElemVal:'2323' },{ errElemVal:'23231' }] as any);
        expect(result).toStrictEqual(testFormlyOptions);
    });

    it('selectErrorMessages should project faultRecArray', () => {
        const faultMessages = [{
            errCode:'100372',
            errCat:'Error',
            errDesc:'Value must be C = Credit or D = Debit.',
            errElem:'ACHFltrInfo.SvcPrvdInfo.SilverLake.ACHFltrArray.ACHFltrRec.achCompanyName INDEX',
            errElemVal:'/2',
            errLoc:'ACFLTRMOD',
        }];

        const expectedFaultMessages = [{
            errCode:'100372',
            errCat:'Error',
            errDesc:'Value must be C = Credit or D = Debit.',
            errElem:'achCompanyName',
            errElemVal:'2',
            errLoc:'INDEX',
        }];
        const result = Selectors.selectErrorMessages.projector(faultMessages);

        expect(result).toStrictEqual(expectedFaultMessages);
    });

    it('selectShowACHAutoReturn should project test array', () => {
        const state = { achFilterInquiryResponse: { showACHAutoReturn: true } };
        const result = Selectors.selectShowACHAutoReturn.projector(state);

        expect(result).toBe(true);
    });

    it('selectErrorMessagesItemID should project test array', () => {
        const result = Selectors.selectErrorMessagesItemID.projector([{ errElemVal:'1' },{ errElemVal:'2' }],
            { exceptionItems: [{ exceptionItemId:123 }, { exceptionItemId:1223 }] });

        expect(result).toEqual([123, 1223]);
    });

    it('selectExceptionItems should project test array', () => {
        const state = { achFilterInquiryResponse: { achFilterInquirySearchRecord: { exceptionItems: [{ exceptionItemId:123,hasError:false }, { exceptionItemId:1223 }] } }, selectedExceptionItemId: 123 };
        const result = Selectors.selectExceptionItems.projector(state,[123]);

        expect(result).toEqual([{ exceptionItemId:123,hasError:true }, { exceptionItemId:1223 }]);
    });

    it('selectExceptionItems should project test array with no error Messages', () => {
        const state = { achFilterInquiryResponse: { achFilterInquirySearchRecord: { exceptionItems: [{ exceptionItemId:123,hasError:false },
            { exceptionItemId:1223 }] } }, selectedExceptionItemId: 123 };
        const result = Selectors.selectExceptionItems.projector(state,[]);

        expect(result).toEqual([{ exceptionItemId:123,hasError:false }, { exceptionItemId:1223 }]);
    });

    it('selectCurrentIndex should project of ExceptionItemID', () => {
        const state = { achFilterInquiryResponse: { achFilterInquirySearchRecord: { exceptionItems: [123, 1235] } }, selectedExceptionItemId: 123 };
        const result = Selectors.selectCurrentIndex.projector( [{ exceptionItemId:123 }, { exceptionItemId:1223 }],123);

        expect(result).toEqual(0);
    });

    it('selectExceptionItemId should project test array', () => {
        const state = { achFilterInquiryResponse: { achFilterInquirySearchRecord: { exceptionItems: [123, 1235] } }, selectedExceptionItemId: 123 };
        const result = Selectors.selectExceptionItemId.projector(state);

        expect(result).toEqual(123);
    });

    it('selectExceptionDetail should project test array', () => {
        const state = { exceptionItems: [{ exceptionItemId: 123 }, { exceptionItemId: 1235 }] };
        const result = Selectors.selectExceptionDetail.projector(state.exceptionItems, 123);
        expect(result).toEqual({ exceptionItemId: 123 });
    });

    it('selectAccountList should project test array', () =>{
        const state = { copyFilterAccountDetailsResponse: {
            accountDetails: [91009,88880]
        } };
        const result = Selectors.selectAccountList.projector(state);
        expect(result).toEqual([91009,88880]);
    });
});


