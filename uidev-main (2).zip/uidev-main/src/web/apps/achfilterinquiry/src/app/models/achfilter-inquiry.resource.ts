/* eslint-disable @typescript-eslint/naming-convention */
export enum ChangeStatusEnum{
    Unchanged = 'UnChanged',
    Delete = 'Delete',
    Newlyadded = 'NewlyAdded',
    Modified = 'Modified',
    None = 'None'
}

export const AchFilterInquiryValueTypes= {
    deleteGlobalDialogBoxMessage: 'Are you sure you want to delete ACH Filter Information and All Exception Items?',
    deleteDialogBoxTitle:'Are you sure you want to delete Exception Item ?',
    deleteGlobalDialogBoxTitle:'Delete Confirmation',
    standardEntryClassDropdown:'standardentryclass-dropdown',
    achFilterChargesTitle:'ACH Filter Charges',
    achFilterAccountAnalysisCountersTitle:'ACH Filter Account Analysis Counters',
    positivePayChargesTitle:'Positive Pay Charges',
    positivePayAccountAnalysisCountersTitle:'Positive Pay Account Analysis Counters',
    copyFilterDialogBoxTitle:'Select accounts to copy ACH Filter to:',
    copyFilterDialogBoxTitleForNoRecord:'Copy ACH Filters',
    saveContinue:'Save & Continue >',
    select:'Select',
    copy:'Copy',
    finish:'Finish',
    backButton:'< Back',
    highAmountValidation:'Amount To: To amount must be greater than from amount',
};

// this enum hold the type of row select after client side delete and add.
export enum RowSelectionType {
    /**
     * Delete :- this is used to highlight the previous or next row after deleting the record.
     * Add :- this is used ot highlight the newly added record.
     * Error :-  this is used to highlight the respective record which has error.
     */
    NewRecordRowSelection='NewRecordRowSelection',
    /**
     * this is used to highlight the first record after save function.
     */
    RefreshRowSelection='RefreshRowSelection',
    None='None',
}

export enum AchFilterFieldsType {
    StandardEntryClass='StandardEntryClass',
    AllowTransactionType='AllowTransactionType',
    CompanyAllowType='CompanyAllowType',
    FilterStateType='FilterStateType',
}
