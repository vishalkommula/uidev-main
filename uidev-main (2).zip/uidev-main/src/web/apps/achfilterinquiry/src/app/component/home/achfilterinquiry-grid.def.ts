/* eslint-disable @typescript-eslint/member-ordering */
import { Injectable } from '@angular/core';
import { AmountRendererComponent, RuiIconRendererComponent } from '@uid/uid-grid';
import { AccountTypesIcons, DateFormatterType } from '@uid/uid-models';
import { formatDate, isNullUndefinedEmpty } from '@uid/uid-utilities';
import { ColDef, GridOptions, RowClassRules, ValueFormatterParams } from 'ag-grid-community';

@Injectable({ providedIn: 'root' })
export class ACHFilterInquiryGridColDef {
    public default: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    filterParams = {
    // provide comparator function
        comparator: (filterLocalDateAtMidnight: any, cellValue: any) => {
            if (cellValue == null) {
                return 0;
            }
            const dateAsString = cellValue;

            // In the example application, dates are stored as yyyy-mm-dd
            // We create a Date object for comparison against the filter date
            const dateParts = dateAsString.split('-');
            const year = Number(dateParts[0]);
            const month = Number(dateParts[1]) - 1;
            const day = Number(dateParts[2]);
            const cellDate = new Date(year, month, day);

            // Now that both parameters are Date objects, we can compare
            if (cellDate < filterLocalDateAtMidnight) {
                return -1;
            } else if (cellDate > filterLocalDateAtMidnight) {
                return 1;
            }
            return 0;
        },
    };

    public rowClassRules: RowClassRules = {
    // row style function
        'grid-error-display': (params) => {
            if(!params.data.hasError){
                return false;
            }
            return params.data.hasError;
        },
    };

    public columns: ColDef[] = [
        {
            field: 'exceptionItemId',
            headerName: 'exceptionItemId',
            hide: true,
            suppressColumnsToolPanel: true,
            suppressFiltersToolPanel: true,
        },
        {
            field: 'achFilterStateType',
            headerName: 'Status',
            filter: 'agSetColumnFilter',
        },
        {
            field: 'achCompanyName',
            headerName: 'Company Name',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'achCompanyId',
            headerName: 'Company ID',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'achStandardEntryClassDesc',
            headerName: 'Standard Entry Class',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'lowAmount',
            headerName: 'Amount From',
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: AmountRendererComponent,
            filter: 'agNumberColumnFilter',
        },
        {
            field: 'highAmount',
            headerName: 'Amount To',
            cellClass: 'ag-right-aligned-cell',
            cellRenderer: AmountRendererComponent,
            filter: 'agNumberColumnFilter',
        },
        // TODO : check cell class rendering for number.
        {
            field: 'achBankingRountingNumber',
            headerName: 'Bank Routing Number',
            filter: 'agNumberColumnFilter',
            hide: true,
        },
        {
            field: 'achAllowTransactionType',
            headerName: 'Credit/Debit',
            filter: 'agSetColumnFilter',
            hide: true,
        },
        {
            field: 'achCompanyAllowType',
            headerName: 'Allow/Disallow',
            filter: 'agSetColumnFilter',
            hide: true,
        },
        {
            field: 'achFilterRemark',
            headerName: 'Remarks',
            hide: true,
            filter: false,
            // suppressMenu: true,
            // resizable:false,
            // sortable: false,
            // suppressFiltersToolPanel:true,
            // suppressMovable:true,
        },
        {
            field: 'expirationDate',
            headerName: 'Expiration Date ',
            filter: 'agDateColumnFilter',
            cellClass: 'ag-right-aligned-cell',
            valueFormatter: this.dateFormatter,
            filterParams: this.filterParams,
            hide: true,
        },
    ];

    public exceptionItemsgridOptions: GridOptions = {
        rowSelection: 'single',
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        columnDefs: this.columns,
        defaultColDef: this.default,
        rowClassRules:this.rowClassRules
    };

    public copyFilterDefaultcolDef: ColDef = {
        resizable: false,
        sortable: true,
        filter: true,
        enablePivot: false,
        suppressMenu: false,
    };

    public copyFilterColumns: ColDef[] = [
        {
            field: 'acctId',
            headerName: 'Account',
            headerCheckboxSelection: true,
            checkboxSelection: true,
            filter: 'agTextColumnFilter',
            cellRendererSelector: (params) => ({
                component: RuiIconRendererComponent,
                params: { iconType:this.getAccountTypeEnumValue(params.data.acctType), iconContext: 'secondary-btn',cellText:params.value  },
            }),
        },
        {
            field: 'name',
            headerName: 'Name',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'acctType',
            headerName: 'AccountType',
            hide: true,
        },
    ];

    public copyFilterGridOptions: GridOptions = {
        rowSelection: 'multiple',
        suppressRowClickSelection:true,
        columnDefs: this.copyFilterColumns,
        defaultColDef: this.copyFilterDefaultcolDef,
        sideBar:false
    };

    // format date to MM/dd/yyyy
    dateFormatter(params: ValueFormatterParams) {

        if (isNullUndefinedEmpty(params.value)) {
            return '';
        }
        return formatDate(params.value, DateFormatterType.DisplayedDateFormatter);
    }
    getAccountTypeEnumValue(enumString: any){
        const enumValue = (<any>AccountTypesIcons)[enumString];
        return enumValue === undefined ? '' : enumValue;
    }
}
