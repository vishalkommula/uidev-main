import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveComponentModule } from '@ngrx/component';
// ag grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
// third party modules
import { AngularSplitModule } from 'angular-split';
import { JhaFormsModule } from '@jha/rui-angular/jha-forms';
import { DropdownModule } from 'primeng/dropdown';

// store
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
// shared libs
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';
import { UidAggridModule } from '@uid/uid-grid';
// component
import { HomeComponent } from './home.component';
import { reducer } from '../../store/reducer/achfilterinquiry.reducer';
import { ACHFilterInquiryEffects } from '../../store/effect/achfilterinquiry.effect';
import { DataService } from '../../service/dataservice';
import { FormlyModule } from '@ngx-formly/core';
import { AchFilterInquiryValueTypes } from '../../models/achfilter-inquiry.resource';
import { StandardEntryClassDropdownComponent } from './formly/type/standardentryclass-dropdown/standardentryclass-dropdown.component';



const routes: Routes = [{ path: '', component: HomeComponent }];

@NgModule({
    declarations: [HomeComponent,StandardEntryClassDropdownComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        UidDirectivesModule,
        UidPipesModule,
        AgGridModule,
        UidAngularControlsModule,
        FormlyModule.forRoot({
            types: [
                {
                    name: AchFilterInquiryValueTypes.standardEntryClassDropdown,
                    component: StandardEntryClassDropdownComponent,
                },
            ],
        }),
        RouterModule.forChild(routes),
        JhaFormsModule.forRoot(),
        AngularSplitModule,
        ReactiveFormsModule,
        DropdownModule,
        UidAggridModule,
        ReactiveComponentModule,
        StoreModule.forFeature('achFilterInquiry',reducer),
        EffectsModule.forFeature([ACHFilterInquiryEffects]),
    ],
    providers: [DataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule {}
