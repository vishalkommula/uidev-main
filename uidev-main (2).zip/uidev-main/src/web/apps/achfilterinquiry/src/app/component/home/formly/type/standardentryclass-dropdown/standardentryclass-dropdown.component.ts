import { Component, OnInit } from '@angular/core';
import { FieldType, FieldTypeConfig } from '@ngx-formly/core';

@Component({
    selector: 'uid-standardentryclass-dropdown',
    templateUrl: './standardentryclass-dropdown.component.html',
    styleUrls: ['./standardentryclass-dropdown.component.scss']
})
export class StandardEntryClassDropdownComponent extends FieldType<FieldTypeConfig> implements OnInit {
    optionsData!: any;

    constructor() {
        super();
    }

    ngOnInit() {
        this.optionsData = this.to.options;
    }
}
