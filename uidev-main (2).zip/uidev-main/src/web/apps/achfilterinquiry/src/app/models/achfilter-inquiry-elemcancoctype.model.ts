export interface ElemCancocType{
    elemConcocvalue: string ;
    eleConcocValueDescription: string;
}
