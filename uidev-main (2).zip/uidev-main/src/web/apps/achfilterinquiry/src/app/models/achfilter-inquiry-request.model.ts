import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface AchFilterInquiryRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    acctType: string;
};
