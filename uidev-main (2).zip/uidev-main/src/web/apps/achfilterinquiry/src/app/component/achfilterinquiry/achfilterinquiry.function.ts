/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { DateFormatterType, FaultMsgRec, FieldMode, PageMode } from '@uid/uid-models';
import { errorMessageDisplay, formatDate } from '@uid/uid-utilities';
import { ACHFilterInquiryInformationFormState } from '../../models/achfilter-inquiry-form.model';
import { ACHFilterInquiryInformation } from '../../models/achfilter-inquiry-information.model';
import { SvcDescInfoRecModel } from '../../models/achfilter-inquiry-svcdescinfrorec.model';
import { AchFilterFieldsType, AchFilterInquiryValueTypes, ChangeStatusEnum } from '../../models/achfilter-inquiry.resource';

export const hideaccountAnalysisDescriptionField = function (model: ACHFilterInquiryInformation, fomState: ACHFilterInquiryInformationFormState, field?: FormlyFieldConfig) {
    return !model.accountAnalysisDescriptionField ? true : false;
};

// this function is used to change the currency and number fields based on the account analysis type.
export function typeSelector(field: FormlyFieldConfig): string {
    return field.model.accountAnalysisDescriptionField !== undefined && field.model.accountAnalysisDescriptionField !== null ? FormDataTypeEnum.number : FormDataTypeEnum.currency;
}

// set the min value for currency and number
export function setMax(field: FormlyFieldConfig): number {
    return field.model.accountAnalysisDescriptionField !== undefined && field.model.accountAnalysisDescriptionField !== null ? 999 : 999.99;
}

// set the min value for currency and number
export function setMin(field: FormlyFieldConfig): number {
    return field.model.accountAnalysisDescriptionField !== undefined && field.model.accountAnalysisDescriptionField !== null ? -999 : -999.99;
}

export const aCHFilterAccountAnalysisCountersLabel = function (model: ACHFilterInquiryInformation, fomState: ACHFilterInquiryInformationFormState, field?: FormlyFieldConfig) {
    return !model.accountAnalysisDescriptionField ? AchFilterInquiryValueTypes.achFilterChargesTitle : AchFilterInquiryValueTypes.achFilterAccountAnalysisCountersTitle;
};

export const positivePayAccountAnalysisCountersLabel = function (model: ACHFilterInquiryInformation, fomState: ACHFilterInquiryInformationFormState, field?: FormlyFieldConfig) {
    return !model.accountAnalysisDescriptionField ? AchFilterInquiryValueTypes.positivePayChargesTitle : AchFilterInquiryValueTypes.positivePayAccountAnalysisCountersTitle;
};

export function dateISOFormatter(date: string): string {
    return date !== undefined ? formatDate(date, DateFormatterType.DisplayedDateFormatter) : date;
}

export const getOptions = function (field: FormlyFieldConfig) {
    if (field.templateOptions?.['dropdownType'] === AchFilterFieldsType.FilterStateType) {
        return field.options?.formState?.achFilterFields.filter((x: SvcDescInfoRecModel) => x.description === AchFilterFieldsType.FilterStateType)[0].elemCancocctype;
    } else if (field.templateOptions?.['dropdownType'] === AchFilterFieldsType.CompanyAllowType) {
        return field.options?.formState?.achFilterFields.filter((x: SvcDescInfoRecModel) => x.description === AchFilterFieldsType.CompanyAllowType)[0].elemCancocctype;
    } else if (field.templateOptions?.['dropdownType'] === AchFilterFieldsType.AllowTransactionType) {
        return field.options?.formState?.achFilterFields.
            filter((x: SvcDescInfoRecModel) => x.description === AchFilterFieldsType.AllowTransactionType)[0].elemCancocctype;
    } else if (field.templateOptions?.['dropdownType'] === AchFilterFieldsType.StandardEntryClass) {
        return field.options?.formState?.achFilterFields.filter((x: SvcDescInfoRecModel) => x.description === AchFilterFieldsType.StandardEntryClass)[0].elemCancocctype;
    }
};

// verify if page mode is inquiry.
export const isViewScreen = function (field: FormlyFieldConfig) {
    return field.options?.formState?.pageMode === PageMode.Inquiry ? true : false;
};

export const standardEntryClassOnchange = function (field: FormlyFieldConfig, $event: any) {
    field.model.achStandardEntryClassDesc = $event.originalEvent.srcElement.innerText;
};

export const setAchFilterStateTypFieldMode = function (field: FormlyFieldConfig) {
    return field.model.changeStatus !== ChangeStatusEnum.Newlyadded ? FieldMode.Edit : FieldMode.Inquiry;
};

export const highAmountValidation = function (field: FormlyFieldConfig) {
    const lowAmount = field?.form?.get('lowAmount')?.value;
    const highAmount = field?.form?.get('highAmount')?.value;
    if (lowAmount > highAmount) {
        field?.form?.get('highAmount')?.setErrors({ highAmountValidation: true });
    field.templateOptions!['validationMessages'] = [{ message: AchFilterInquiryValueTypes.highAmountValidation }];
    return true;
    } else if (field?.form?.get('highAmount')?.hasError('highAmountValidation')) {
    /**
     * checking if there a error of type elemKey which set to true.
     * if key's formcontrol has elemkey type of error then manually setting elemtype error to false and emptying validationMessages (optional property) of templateOptions
     */
        field?.form?.get('highAmount')?.setErrors({ highAmountValidation: false });
    field.templateOptions!['validationMessages'] = [];
    return false;
    }
    return false;
};

export function getAchFilterInformationFormField(): FormlyFieldConfig[] {
    return [
        {
            templateOptions: { label: 'ACH Filter Information' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'accountAnalysisDescriptionField',
                    templateOptions: {
                        label: 'Account Analysis',
                        fieldMode: FieldMode.Inquiry,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-accountAnalysisDescriptionField-01',
                        },
                    },
                    hideExpression: hideaccountAnalysisDescriptionField,
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'achAllowAllDebitsField',
                    templateOptions: {
                        label: 'Allow All Debits',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achAllowAllDebitsField-01',
                        },
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.yesnocheckbox,
                },
                {
                    key: 'achAlllowAllCreditsField',
                    templateOptions: {
                        label: 'Allow All Credits',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achAlllowAllCreditsField-01',
                        },
                    },
                    type: FormDataTypeEnum.yesnocheckbox,
                },
                {
                    key: 'allowPostivePayTypeField',
                    templateOptions: {
                        label: 'Enable Positive Pay',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-allowPostivePayTypeField-01',
                        },
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.yesnocheckbox,
                },
            ],
        },
        {
            expressionProperties: {
                'templateOptions.label': aCHFilterAccountAnalysisCountersLabel,
            },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'achFilterOneTimeSetupField',
                    defaultValue: 0,
                    templateOptions: {
                        label: 'One Time Setup',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        allowEmpty: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterOneTimeSetupField-01',
                        },
                    },
                    expressions: {
                        type: typeSelector,
                        'templateOptions.max': setMax,
                        'templateOptions.min': setMin,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.number,
                },
                {
                    key: 'achFilterStatementCycleChangeField',
                    defaultValue: 0,
                    templateOptions: {
                        label: 'Statement Cycle',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        allowEmpty: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterStatementCycleChangeField-01',
                        },
                    },
                    expressions: {
                        type: typeSelector,
                        'templateOptions.max': setMax,
                        'templateOptions.min': setMin,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.number,
                },
                {
                    key: 'achFilterPerExceptionItemField',
                    defaultValue: 0,
                    templateOptions: {
                        label: 'Per Exception Item',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        allowEmpty: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterPerExceptionItemField-01',
                        },
                    },
                    expressions: {
                        type: typeSelector,
                        'templateOptions.max': setMax,
                        'templateOptions.min': setMin,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.number,
                },
            ],
        },
        {
            expressionProperties: {
                'templateOptions.label': positivePayAccountAnalysisCountersLabel,
            },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'achFilterAacounterOneTimeSetupField',
                    defaultValue: 0,
                    templateOptions: {
                        label: 'One Time Setup',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        allowEmpty: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterAacounterOneTimeSetupField-01',
                        },
                    },
                    expressions: {
                        type: typeSelector,
                        'templateOptions.max': setMax,
                        'templateOptions.min': setMin,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.number,
                },
                {
                    key: 'achFilterAacounterStatementCycleChangeField',
                    defaultValue: 0,
                    templateOptions: {
                        label: 'Statement Cycle',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        allowEmpty: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterAacounterStatementCycleChangeField-01',
                        },
                    },
                    expressions: {
                        type: typeSelector,
                        'templateOptions.max': setMax,
                        'templateOptions.min': setMin,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.number,
                },
                {
                    key: 'achFilterAacounterPerExceptionItemField',
                    defaultValue: 0,
                    templateOptions: {
                        label: 'Per Exception Item',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        allowEmpty: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterAacounterPerExceptionItemField-01',
                        },
                    },
                    expressions: {
                        type: typeSelector,
                        'templateOptions.max': setMax,
                        'templateOptions.min': setMin,
                        'validation.show': errorMessageDisplay,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.number,
                },
            ],
        },
    ];
}

// TODO : check why form-field wrapper is not coming for dropdown type
// exception detail form field.
export function getExceptionDetailFormField(): FormlyFieldConfig[] {
    return [
        {
            templateOptions: { label: 'Exception Item Information ' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'achFilterStateType',
                    id:'field-achFilterStateType',
                    templateOptions: {
                        label: 'Status',
                        labelClasses: 'col-md-7',
                        dropdownType: 'FilterStateType',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        placeholder: '\u00A0', // this is to display empty placeholder
                        labelProp: 'elemConcocvalue',
                        valueProp: 'eleConcocValueDescription',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterStateType-01',
                        },
                    },
                    expressions: {
                        'templateOptions.fieldMode': setAchFilterStateTypFieldMode,
                        'templateOptions.options': getOptions,
                        'validation.show': errorMessageDisplay,
                    },
                    type: FormDataTypeEnum.dropdown,
                    wrappers: ['form-field'],
                },
                {
                    key: 'achCompanyName',
                    id:'field-achCompanyName',
                    templateOptions: {
                        label: 'Company Name',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        class: 'rui-form-control',
                        maxLength: 16,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achCompanyName-01',
                        },
                    },
                    expressions: {
                        'validation.show': errorMessageDisplay,
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'achCompanyId',
                    templateOptions: {
                        label: 'Company ID',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        maxLength: 10,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achCompanyId-01',
                        },
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'achStandardEntryClassDesc',
                    templateOptions: {
                        label: 'Standard Entry Class',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achStandardEntryClassDesc-01',
                        },
                    },
                    expressions: {
                        hide: (field)=>(!(isViewScreen(field))),
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'achStandardEntryClass',
                    templateOptions: {
                        label: 'Standard Entry Class',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        dropdownType: 'StandardEntryClass',
                        optionLabel: 'eleConcocValueDescription',
                        optionValue: 'elemConcocvalue',
                        style: { width: '10.75em' },
                        appendTo: 'body',
                        labelProp: 'elemConcocvalue',
                        valueProp: 'eleConcocValueDescription',
                        change: standardEntryClassOnchange,
                        placeholder: '\u00A0', // this is to display empty placeholder
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achStandardEntryClass-01',
                        },
                    },
                    expressions: {
                        hide: isViewScreen,
                        'templateOptions.options': getOptions,
                    },
                    wrappers: ['form-field'],
                    type: AchFilterInquiryValueTypes.standardEntryClassDropdown,
                },
                {
                    key: 'lowAmount',
                    id:'field-lowAmount',
                    templateOptions: {
                        label: 'Amount From',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        max: 999999999.99,
                        min: -999999999.99,
                        inputLength: 11,
                        allowEmpty: false,
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-lowAmount-01',
                        },
                    },
                    expressions: {
                        'validation.show': errorMessageDisplay,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'highAmount',
                    templateOptions: {
                        label: 'Amount To',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        max: 999999999.99,
                        min: -999999999.99,
                        inputLength: 11,
                        allowEmpty: false,
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'achfilterinquiry-highAmount-01',
                        },
                    },
                    expressions: {
                        'validation.show': highAmountValidation,
                    },
                    type: FormDataTypeEnum.currency,
                },
            ],
        },
        {
            templateOptions: { label: 'Additional Information' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'achBankingRountingNumber',
                    templateOptions: {
                        label: 'Banking Routing Number',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputLength: 9,
                        inputStyleClass: 'rui-form-control',
                        mode: 'decimal',
                        useGrouping: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achBankingRountingNumber-01',
                        },
                    },
                    type: FormDataTypeEnum.number,
                },
                {
                    key: 'achAllowTransactionType',
                    templateOptions: {
                        label: 'Credit/Debit',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        dropdownType: 'AllowTransactionType',
                        labelProp: 'elemConcocvalue',
                        valueProp: 'eleConcocValueDescription',
                        inputStyleClass: 'rui-form-control',
                        placeholder: '\u00A0', // this is to display empty placeholder
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achAllowTransactionType-01',
                        },
                    },
                    expressions: {
                        'templateOptions.options': getOptions,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.dropdown,
                },
                {
                    key: 'achCompanyAllowType',
                    id:'field-achCompanyAllowType',
                    templateOptions: {
                        label: 'Allow/Disallow',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        dropdownType: 'CompanyAllowType',
                        labelProp: 'elemConcocvalue',
                        valueProp: 'eleConcocValueDescription',
                        inputStyleClass: 'rui-form-control',
                        placeholder: '\u00A0', // this is to display empty placeholder
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achCompanyAllowType-01',
                        },
                    },
                    expressions: {
                        'templateOptions.options': getOptions,
                    },
                    wrappers: ['form-field'],
                    type: FormDataTypeEnum.dropdown,
                },
                {
                    key: 'expirationDate',
                    type: FormDataTypeEnum.datepicker,
                    parsers: [(value: string) => dateISOFormatter(value)],
                    templateOptions: {
                        label: 'Expiration Date',
                        placeholder: DateFormatterType.DatePlaceholder,
                        dateFormat: 'mm/dd/yy',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        showButtonBar: false,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-expirationDate-01',
                        },
                    },
                },
            ],
        },
        {
            templateOptions: { label: 'Remarks' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'achFilterRemark',
                    className: 'longer-width',
                    templateOptions: {
                        inputStyleClass: 'rui-form-control',
                        style: { 'margin-left': '1px' },
                        maxLength: 50,
                        attributes: {
                            'data-test-id': 'achfilterinquiry-achFilterRemark-01',
                        },
                    },
                    type: FormDataTypeEnum.input,
                },
            ],
        },
    ];
}

//TODO: implement this logic while intergration with api.
export function findErrElementForACHFilter(errorElements: string[]){
    return errorElements.findIndex(x => x === 'INDEX');
}
