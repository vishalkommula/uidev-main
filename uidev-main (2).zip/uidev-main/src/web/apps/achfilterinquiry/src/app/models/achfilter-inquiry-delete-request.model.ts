import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface ACHFilterInquiryDeleteRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    acctType: string;
    // this field used for global delete functionality.
    deleteField: string;
};
