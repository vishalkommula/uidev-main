import { ACHFilterInquiryGridColDef } from './achfilterinquiry-grid.def';

jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

let sut: ACHFilterInquiryGridColDef;

describe('ACHFilterInquiryGridColDef', () => {
    beforeEach(() => {
        sut = new ACHFilterInquiryGridColDef();
    });

    it('service should be created', () => {
        expect(sut).toBeTruthy();
    });

    it('dateFormatter convert date to MM/dd/YYYY format', () => {
        const params = { value: '2022-07-07' };
        expect(sut.dateFormatter(params as any)).toBe('07/07/2022');
    });

    it('dateFormatter invalid date', () => {
        const params = { value: '07-07-2022' };
        expect(sut.dateFormatter(params as any)).toBe('07/07/2022');
    });

    it('dateFormatter undefined date', () => {
        const params = { value: undefined };
        expect(sut.dateFormatter(params as any)).toBe('');
    });
    it('getAccountTypeEnumValue method - should be executed', () => {
        const enumString = 'D' ;
        expect(sut.getAccountTypeEnumValue(enumString)).toBe('check');
    });
    it('getAccountTypeEnumValue method undefined - should be executed', () => {
        const  enumString =  '' ;
        expect(sut.getAccountTypeEnumValue(enumString as any)).toBe('');
    });
});
