import { FaultMsgRec, FormWidth, PageMode } from '@uid/uid-models';
import { SvcDescInfoRecModel } from './achfilter-inquiry-svcdescinfrorec.model';

export interface ACHFilterInquiryInformationFormState {
    pageMode: PageMode;
    width: FormWidth;
    errorMessages: FaultMsgRec[];
};

export interface ExceptionDetailFormState {
    pageMode: PageMode;
    width: FormWidth;
    // achFilterFields holds the different dropdown type values.
    achFilterFields: SvcDescInfoRecModel[];
    errorMessages: FaultMsgRec[];
};
