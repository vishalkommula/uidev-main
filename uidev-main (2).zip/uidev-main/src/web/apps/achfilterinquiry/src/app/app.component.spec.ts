import { AppComponent } from './app.component';

describe('AppComponent', () => {
    let component: AppComponent;
    beforeEach(async () => {
        component=new AppComponent();
    });

    it('should create the component', () => {
        expect(component).toBeTruthy();
    });

    it('should have as title \'achfilterinquiry\'', () => {
        expect(component.title).toEqual('achfilterinquiry');
    });
});
