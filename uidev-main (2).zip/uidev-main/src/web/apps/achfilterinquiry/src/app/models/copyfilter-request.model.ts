import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface CopyFilterAccountDetailRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    custId: string;
};
