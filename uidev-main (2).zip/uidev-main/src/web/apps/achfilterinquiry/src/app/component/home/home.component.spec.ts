import { ButtonText, DialogBoxType } from '@uid/uid-models';
import { AchFilterInquiryValueTypes, RowSelectionType } from '../../models/achfilter-inquiry.resource';
import { of } from 'rxjs';
import { HomeComponent } from './home.component';
import { AbbName_Type } from '@jhxp/x3-web-api';

jest.mock('@uid/uid-root-store', () => jest.fn());

jest.mock('../../store', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

Object.defineProperty(global.self, 'crypto', {
    value: {
        randomUUID: jest.fn().mockReturnValue('12121212'),
    },
});

let sut: HomeComponent;

const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(),
};

const gridDefMock = {
    gridOptions: {
        selectRecord: jest.fn(),
    },
    exceptionItemsgridOptions:{
        onModelUpdated:jest.fn(),
        onGridSizeChanged:jest.fn(),
        onRowSelected:jest.fn(),
        getRowId:jest.fn(),
        onGridReady:jest.fn()
    },
    api: {
        getSelectedNodes: jest.fn().mockReturnValue(1),
        getDisplayedRowAtIndex: jest.fn().mockImplementation((data) => {
            if (data === 1) {
                return 1;
            } else if (data === 2) {
                return undefined;
            } else {
                return 2;
            }
        }),
        getRowNode: jest.fn(),
        sizeColumnsToFit: jest.fn()
    },
};

const uidGrid = {
    uidApi: {
        selectRecord: jest.fn(),
    },
    api: {
        getSelectedNode: jest.fn(),
        getSelectedNodes: jest.fn().mockReturnValue([1, 2, 3]),
        getDisplayedRowAtIndex: jest.fn(),
        getRowNode: jest.fn(),
        sizeColumnsToFit: jest.fn(),
        getSelectedRows:jest.fn().mockReturnValue([{ acctId:'1',name:'232',acctType:'1232' }]),
    },
};

const copyUidGrid={
    uidApi: {
        selectRecord: jest.fn(),
    },
    api: {
        getSelectedNodes: jest.fn().mockReturnValue([1, 2, 3]),
        getDisplayedRowAtIndex: jest.fn(),
        getRowNode: jest.fn(),
        getSelectedRows:jest.fn().mockReturnValue([{ acctId:'1',name:'232',acctType:'1232' }])
    },
};

const achFilterInquiryActionsMock = {
    getACHFilterInquirySearchRecords: jest.fn(),
    selectedExceptionItemId: jest.fn(),
    togglePageMode: jest.fn(),
    deleteExceptionDetail: jest.fn(),
    updateACHFilterInquiry: jest.fn(),
    deleteACHFilterInquiry: jest.fn(),
    updateACHFilterInquiryInformation:jest.fn(),
    updateExceptionDetail:jest.fn(),
    addExceptionDetail:jest.fn(),
    getCopyFilterAccountList: jest.fn(),
    addACHFilterInquiry:jest.fn(),
    addFaultRecMessages:jest.fn()
};

const achFilterInquirySelectorMock = {
    selectPageMode: jest.fn(),
    selectAchFilterInquiryInformation: jest.fn(),
    selectExceptionDetailFormlyOptions: jest.fn(),
    selectExceptionItemId: jest.fn(),
    selectExceptionDetail: jest.fn(),
};

describe('HomeComponent', () => {
    beforeEach(() => {
        sut = new HomeComponent(storeMock as any, gridDefMock as any);
        sut.achFilterInquiryActions = achFilterInquiryActionsMock as any;
        sut.achFilterInquirySelector = achFilterInquirySelectorMock as any;
        sut.exceptionGridAPI = uidGrid as any;
    });

    it('Component should be created', () => {
        expect(sut).toBeTruthy();
    });

    it('ngOnInit: should be called', () => {
        const event = { node: { isSelected: jest.fn().mockReturnValue(true) }, data: { exceptionItemId: 123 } };
        sut.errorMessagesAtItemID$=of();
        sut.exceptionDetail$=of();
        sut.achFilterInquirySearchRecord$=of();
        sut.ngOnInit();
        expect(sut.exceptionItemsgridOptions).toStrictEqual(gridDefMock.exceptionItemsgridOptions);
    });

    it('ngOnDestroy: should be called', () => {
        sut.errorMessagesAtItemID$=of();
        sut.exceptionDetail$=of();
        sut.ngOnDestroy();
    });

    it('onGridSizeChanged: should fire sizeColumnsToFit', () => {
        const event = { api: { sizeColumnsToFit: jest.fn() } };
        sut.onGridSizeChanged(event as any);
        expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
    });

    it('onRowSelected: if node is selected and recordNavigation is null, selectRecord dispatch should be called', () => {
        const event = { node: { isSelected: jest.fn().mockReturnValue(true) }, data: { exceptionItemId: 123 } };
        sut.onRowSelected(event as any);
        expect(achFilterInquiryActionsMock.selectedExceptionItemId).toBeCalledWith({ exceptionItemId: 123 });
    });

    it('onModelUpdated: with newData and selected row after adding new record', () => {
        sut.exceptionGridAPI = { getRowNode: jest.fn(), getDisplayedRowCount: jest.fn().mockReturnValue(2),
            deselectAll:jest.fn(),getDisplayedRowAtIndex: jest.fn().mockReturnValue({}) } as any;
        const event ={
            api:{ getRowNode: jest.fn(),
                getDisplayedRowCount: jest.fn().mockReturnValue(2),
                deselectAll:jest.fn(),
                getDisplayedRowAtIndex: jest.fn().mockReturnValue({})
            }
        };
        sut.rowSelectionType = RowSelectionType.NewRecordRowSelection;
        sut.onModelUpdated(event as any);
        expect(event.api.getRowNode).toBeCalledTimes(1);
    });
    it('onModelUpdated:  with newData and selected row after deleting the record.', () => {
        sut.exceptionGridAPI = { getRowNode: jest.fn(), getDisplayedRowCount: jest.fn().mockReturnValue(2),
            deselectAll:jest.fn(),getDisplayedRowAtIndex: jest.fn().mockReturnValue({}) } as any;
        const event ={
            api:{ getRowNode: jest.fn(),
                getDisplayedRowCount: jest.fn().mockReturnValue(2),
                deselectAll:jest.fn(),
                getDisplayedRowAtIndex: jest.fn().mockReturnValue({})
            }
        };
        sut.rowSelectionType = RowSelectionType.NewRecordRowSelection;
        sut.onModelUpdated(event as any);
        expect(event.api.getRowNode).toBeCalledTimes(1);
    });

    it('getRowId: should return rowid', () => {
        expect(sut.getRowId({ data: { exceptionItemId: 121 } } as any)).toBe(121);
    });

    it('deleteButton: click should show dialog box', () => {
        sut.showDialogBox = false;
        sut.deleteButton(true);
        expect(sut.dialogBoxTitle).toBe(AchFilterInquiryValueTypes.deleteGlobalDialogBoxTitle);
    });

    it('deleteButton: click should show dialog box with isDeleteACHFilterInquiry is false', () => {
        sut.showDialogBox = false;
        sut.deleteButton(false);
        expect(sut.dialogBoxTitle).toBe(AchFilterInquiryValueTypes.deleteDialogBoxTitle);
    });


    it('dialogBoxClose: close dialogbox of delete type', () => {
        sut.deleteExceptionItem = jest.fn();
        sut.dialogBoxClose({ detail: ButtonText.Delete } as any);
        expect(sut.deleteExceptionItem).toBeCalledTimes(1);
    });

    it('dialogBoxClose: close dialogbox of donot save type', () => {
        sut.deleteExceptionItem = jest.fn();
        sut.isUserInCopyACHFilter=true;
        sut.dialogBoxClose({ detail: ButtonText.DonotSave } as any);
        expect(achFilterInquiryActionsMock.getACHFilterInquirySearchRecords).toBeCalled();
    });

    it('dialogBoxClose: close dialogbox of delete type with global delete', () => {
        sut.isDeleteACHFilterInquiry=true;
        sut.deleteACHFilterInquiry = jest.fn();
        sut.dialogBoxClose({ detail: ButtonText.Delete } as any);
        expect(sut.deleteACHFilterInquiry).toBeCalledTimes(1);
    });

    it('dialogBoxClose: dont save dialogbox of delete type', () => {
        sut.deleteExceptionItem = jest.fn();
        sut.dialogBoxClose({ detail: ButtonText.DonotSave } as any);
        expect(achFilterInquiryActionsMock.getACHFilterInquirySearchRecords).toBeCalled();
    });

    it('cancelButton: load cancel dialogbox', () => {
        sut.cancelButton();
        expect(sut.showDialogBox).toBe(true);
    });

    it('overridedialogBoxClose: close dialogbox on override button click', () => {
        sut.saveAchFilterInquiry = jest.fn();
        sut.overridedialogBoxClose({ clickAction: ButtonText.Override } as any);
        expect(sut.saveAchFilterInquiry).toBeCalledTimes(1);
    });

    it('overridedialogBoxClose: close dialogbox on cancel button click', () => {
        sut.saveAchFilterInquiry = jest.fn();
        sut.overridedialogBoxClose({ clickAction: ButtonText.Cancel } as any);
        expect(sut.saveAchFilterInquiry).toBeCalledTimes(0);
        expect(achFilterInquiryActionsMock.addFaultRecMessages).toBeCalledTimes(1);
        expect(sut.showOverrideDialogBox).toBe(false);
    });

    it('copyDialogBoxClose: close dialogbox on select button click', () => {
        sut.saveAchFilterInquiry = jest.fn();
        sut.selectedAccountDetails=[{ acctId:'1',name:'232',acctType:'1232' }];
        sut.copyFiltergridOptions=copyUidGrid as any;
        expect(achFilterInquiryActionsMock.getACHFilterInquirySearchRecords).toBeCalled();
    });

    it('editACHFilterInquiry: dispatch toggle pageMode', () => {
        sut.editACHFilterInquiry();
        expect(achFilterInquiryActionsMock.togglePageMode).toBeCalled();
    });

    it('deleteExceptionItem: dispatch the delete action and previous row id 1,previous record', () => {
        sut.exceptionGridAPI.getSelectedNodes=jest.fn().mockReturnValue([{ rowIndex:2 },{ rowIndex:1 }]);
        sut.exceptionGridAPI.getDisplayedRowAtIndex=jest.fn().mockImplementation((data) => {
            if (data === 1) {
                return { data:{ exceptionItemId:'1' } };
            } else if (data === 2) {
                return { data:{ exceptionItemId:'1' } };
            } else {
                return undefined;
            }
        });
        sut.deleteExceptionItem();
        expect(sut.nextRowSelectionId).toBe('1');
        expect(achFilterInquiryActionsMock.deleteExceptionDetail).toBeCalled();
    });

    it('deleteExceptionItem: dispatch the delete action and next row id 1,next record', () => {
        sut.exceptionGridAPI.getSelectedNodes=jest.fn().mockReturnValue([{ rowIndex:1 },{ rowIndex:2 }]);
        sut.exceptionGridAPI.getDisplayedRowAtIndex=jest.fn().mockImplementation((data) => {
            if (data === 1) {
                return { data:{ exceptionItemId:'1' } };
            } else if (data === 2) {
                return { data:{ exceptionItemId:'1' } };
            } else {
                return undefined;
            }
        });
        sut.deleteExceptionItem();
        expect(sut.nextRowSelectionId).toBe('1');
        expect(achFilterInquiryActionsMock.deleteExceptionDetail).toBeCalled();
    });

    it('onDragEnd: set area value for section 1', () => {
        sut.onDragEnd(1, { sizes: [1, 2] } as any);
        expect(sut.sizes.section1.area1).toBe(1);
    });

    it('onDragEnd: set area value for section 2', () => {
        sut.onDragEnd(2, { sizes: [1, 2] } as any);
        expect(sut.sizes.section2.area1).toBe(1);
    });

    it('gutterDblClick: primary gutter double click', () => {
        sut.gutterDblClick({ sizes: [1, 2] } as any);
        expect(sut.sizes.section1.area1).toBe(30);
    });

    it('gutterDetailDblClick: detail gutter double click', () => {
        sut.gutterDetailDblClick({ sizes: [1, 2] } as any);
        expect(sut.sizes.section2.area1).toBe(50);
    });

    it('saveACHfilterInquiry: dispatch the update action', () => {
        sut.saveAchFilterInquiry({ exceptionItems: [12, 33], achFilterFields: [22, 22] } as any);
        expect(achFilterInquiryActionsMock.updateACHFilterInquiry).toBeCalled();
    });

    it('saveACHfilterInquiry: dispatch the update action in copy filter screen', () => {
        sut.isUserInCopyACHFilter=true;
        sut.currentAccountDetailIndex=0;
        sut.selectedAccountDetails=[{ acctId:'1',name:'232',acctType:'1232' }];
        sut.saveAchFilterInquiry({ exceptionItems: [12, 33], achFilterFields: [22, 22] } as any);
        expect(achFilterInquiryActionsMock.updateACHFilterInquiry).toBeCalled();
        sut.isUserInCopyACHFilter=false;
    });

    it('deleteACHfilterInquiry: dispatch the update action',() =>{
        sut.deleteACHFilterInquiry();
        expect(achFilterInquiryActionsMock.deleteACHFilterInquiry).toBeCalled();
    });

    it('updateACHFilterInformation: dipatch the update achfilterinformation action', () => {
        sut.updateACHFilterInformation({} as any);
        expect(achFilterInquiryActionsMock.updateACHFilterInquiryInformation).toBeCalled();
    });

    it('updateExceptionDetail: dipatch the update achfilterinformation action', () => {
        sut.updateExceptionDetail({ exceptionItemId: '1212', expirationDate: '10/10/2022' } as any);
        expect(achFilterInquiryActionsMock.updateExceptionDetail).toBeCalledTimes(1);
    });

    it('addACHFilterInquiry: dipatch the update addACHFiterInquiry action', () => {
        sut.addACHFilterInquiry(true);
        expect(achFilterInquiryActionsMock.addACHFilterInquiry).toBeCalledTimes(1);
    });

    it('getCopyFilterAccountDetails: copyfilter close dialoguebox should dispatch a getCopyFilterAccountList action', () => {
        sut.getCopyFilterAccountDetails();
        expect(achFilterInquiryActionsMock.getCopyFilterAccountList).toBeCalled();
    });

    it('compareObject: returns false for unmodified data', () => {
        const result=sut.compareObject({ data:123 },{ data:123 },'23');
        expect(result).toBe(false);
    });

    it('compareObject: returns true for modified data', () => {
        const result=sut.compareObject({ data:123 },{ data:23 },'23');
        expect(result).toBe(true);
    });
});
