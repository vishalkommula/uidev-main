import { Injectable } from '@angular/core';
import * as AchFilterInquiryActions from '../actions/achfilterinquiry.action';
import { DataService } from '../../service/dataservice';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { catchError, map, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { PageMode } from '@uid/uid-models';

@Injectable()
export class ACHFilterInquiryEffects {
    constructor(private dataService: DataService, private actions$: Actions) {}

    loadACHFilterInquiryResponse$ = createEffect(() =>
        this.actions$.pipe(
            ofType(AchFilterInquiryActions.getACHFilterInquirySearchRecords),
            switchMap((action) => {
                // action payload is undefined after receiving data from api
                const isUserInCopyACHFilter = action.isUserInCopyACHFilter;
                return this.dataService.getACHFilterInquiryInformationDetails(action.request).pipe(
                    switchMap((response) => {
                        const actionsToDispatch = [];
                        actionsToDispatch.push(AchFilterInquiryActions.getACHFilterInquirySearchRecordsRetrived({ response }));
                        actionsToDispatch.push(AchFilterInquiryActions.togglePageMode({ pageMode: isUserInCopyACHFilter ? PageMode.Edit : PageMode.Inquiry }));

                        return actionsToDispatch;
                    }),
                    catchError((error) =>
                        of(
                            AchFilterInquiryActions.getACHFilterInquirySearchRecordsRetrivedFailure({
                                error,
                            })
                        )
                    )
                );
            })
        )
    );

    updateACHFilterInquiryInformation$ = createEffect(() =>
        this.actions$.pipe(
            ofType(AchFilterInquiryActions.updateACHFilterInquiry),
            switchMap((action) => {
                // action payload is undefined after receiving data from api
                const isUserInCopyACHFilter = action.isUserInCopyACHFilter;
                return this.dataService.updateACHFilterInquiry(action.request).pipe(
                    switchMap((response) => {
                        const actionsToDispatch = [];
                        if (response.faultRecInfoArray && response.faultRecInfoArray !== null && response.faultRecInfoArray.length > 0) {
                            actionsToDispatch.push(AchFilterInquiryActions.addFaultRecMessages({ faultRec: response.faultRecInfoArray }));
                        } else {
                            actionsToDispatch.push(AchFilterInquiryActions.updateACHFilterInquirySuccesss({ response }));
                            actionsToDispatch.push(AchFilterInquiryActions.togglePageMode({ pageMode: isUserInCopyACHFilter ? PageMode.Edit : PageMode.Inquiry }));
                        }
                        return actionsToDispatch;
                    }),
                    catchError((error) =>
                        of(
                            AchFilterInquiryActions.updateACHFilterInquiryFailure({
                                error,
                            })
                        )
                    )
                );
            })
        )
    );

    deleteACHFilterInquiry$ = createEffect(() =>
        this.actions$.pipe(
            ofType(AchFilterInquiryActions.deleteACHFilterInquiry),
            switchMap((action) =>
                this.dataService.deleteACHFilterInquiry(action.deleteRequest).pipe(
                    switchMap((response) => {
                        const actionsToDispatch = [];
                        actionsToDispatch.push(AchFilterInquiryActions.deleteACHFilterInquirySuccess({ response }));

                        return actionsToDispatch;
                    }),
                    catchError((error) =>
                        of(
                            AchFilterInquiryActions.deleteACHFilterInquiryFailure({
                                error,
                            })
                        )
                    )
                )
            )
        )
    );

    addACHFilterInquiry$ = createEffect(() =>
        this.actions$.pipe(
            ofType(AchFilterInquiryActions.addACHFilterInquiry),
            switchMap((action) => {
                const exceptionItem = action.exceptionDetail;
                if (action.request) {
                    return this.dataService.getDefaultValueACHFilterInformation(action.request).pipe(
                        switchMap((defautlValues) => {
                            const actionsToDispatch = [];
                            /** first dispatching the default value of ACH Filter Information action to update store.
               * reusing the addACHException action to update newly added exception item.
               */
                            actionsToDispatch.push(AchFilterInquiryActions.getDefaultValueACHFilterInformationRetrived({ response: defautlValues }));
                            actionsToDispatch.push(AchFilterInquiryActions.addACHExceptionItems({ exceptionDetail: exceptionItem }));
                            return actionsToDispatch;
                        }),
                        catchError((error) =>
                            of(
                                AchFilterInquiryActions.getDefaultValueACHFilterInformationFailure({
                                    error,
                                })
                            )
                        )
                    );
                } else {
                    const actionsToDispatch = [];
                    actionsToDispatch.push(AchFilterInquiryActions.addACHExceptionItems({ exceptionDetail: exceptionItem }));
                    return actionsToDispatch;
                }
            })
        )
    );

    loadCopyFilterAccountDetails$ = createEffect(() =>
        this.actions$.pipe(
            ofType(AchFilterInquiryActions.getCopyFilterAccountList),
            switchMap((action) =>
                this.dataService.getCopyFilterAccountDetails(action.copyAccountDetailRequest).pipe(
                    switchMap((response) => {
                        const actionsToDispatch = [];
                        actionsToDispatch.push(AchFilterInquiryActions.getCopyFilterAccountListRetrived({ response }));
                        return actionsToDispatch;
                    }),
                    catchError((error) =>
                        of(
                            AchFilterInquiryActions.getCopyFilterAccountListFailure({
                                error,
                            })
                        )
                    )
                )
            )
        )
    );
}
