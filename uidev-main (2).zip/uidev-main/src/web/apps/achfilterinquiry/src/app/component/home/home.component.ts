import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Observable, of, Subscription } from 'rxjs';
// NGRX
import { Store } from '@ngrx/store';
import { FormlyFormOptions } from '@ngx-formly/core';
import * as ACHFilterInquirySelector from '../../store/selector/achfilterinquiry.selector';
import * as ACHFilterInquiryActions from '../../store/actions/achfilterinquiry.action';
// function
import * as ACHFilterInquiryFunctions from '../achfilterinquiry/achfilterinquiry.function';
// ACH Filter Models
import { ACHFilterInquiryInformation } from '../../models/achfilter-inquiry-information.model';
import { ACHFilterInquiryModRequest } from '../../models/achfilter-inquiry-mod-request.model';
import { AchFilterInquiryRecord } from '../../models/achfilter-inquiry-record.model';
import {
    GetRowIdParams,
    GridApi,
    GridOptions,
    GridReadyEvent,
    GridSizeChangedEvent,
    PaginationChangedEvent,
    RowNode,
    RowSelectedEvent
} from 'ag-grid-community';
import { ACHFilterInquiryGridColDef } from './achfilterinquiry-grid.def';
import { ButtonText, DateFormatterType, DialogBoxText, DialogBoxType, FaultMsgRec, PageMode } from '@uid/uid-models';
import { IOutputData } from 'angular-split';
import { ACHFilterInquirySearchRecordModel } from '../../models/achfilter-inquiry-search-record.model';
import { ACHFilterInquiryDeleteRequest } from '../../models/achfilter-inquiry-delete-request.model';
import {
    AchFilterInquiryValueTypes,
    ChangeStatusEnum,
    RowSelectionType
} from '../../models/achfilter-inquiry.resource';
import { AchFilterInquiryRequest } from '../../models/achfilter-inquiry-request.model';
import { formatDate, generateRandomString, unsubscribe } from '@uid/uid-utilities';
import { UntypedFormGroup } from '@angular/forms';
import { SelectedFaultError } from '@uid/uid-angular-controls';
import { CopyFilterAccountDetailRequest } from '../../models/copyfilter-request.model';
import { AccountDetails } from '../../models/acountdetails.model';
import { UidAggridComponent } from '@uid/uid-grid';

@Component({
    selector: 'uid-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {
    @ViewChild(UidAggridComponent) uidAggrid!: UidAggridComponent;

    // exception Items is used to display data in grid.
    showOverrideDialogBox = false;
    // exception Items is used to display data in grid and don't contain the changeStatus as deleted.
    exceptionItems$!: Observable<AchFilterInquiryRecord[]>;
    // enum declaration.
    pageModeEnum = PageMode;
    // achfilterinquiry selectors.
    achFilterInquirySelector = ACHFilterInquirySelector;
    // achfilterInquiry Actions.
    achFilterInquiryActions = ACHFilterInquiryActions;
    // enums
    achFilterInquiryValueTypes = AchFilterInquiryValueTypes;

    achFilterSerchRecords!: ACHFilterInquirySearchRecordModel;
    // formly models and formlyfield declaration
    achFilterInquiryFormState$: Observable<FormlyFormOptions>;

    // To get the ACH Filter Information Formly Configuration
    achFilterInquiryFormFields = ACHFilterInquiryFunctions.getAchFilterInformationFormField();

    exceptionDetailFormFields = ACHFilterInquiryFunctions.getExceptionDetailFormField();

    errorMessagesAtItemID$!: Observable<string[]>;

    exceptionDetailFormState$: Observable<FormlyFormOptions>;

    // used to diffrentiate the globle and row row level delete.
    isDeleteACHFilterInquiry!: boolean;
    // get exceptionItemId of selected record.
    exceptionItemId$!: Observable<string>;
    // get exceptionDetail of selected record.
    exceptionDetail$!: Observable<AchFilterInquiryRecord | undefined>;
    // showDialogBox displays the dialog box on cancel click and delete click .
    showDialogBox = false;
    // generic dialog box title display for delete and cancel click.
    dialogBoxTitle = '';
    // dialogBoxType defines the type of dialogbox like delete and cencel.
    dialogBoxType!: DialogBoxType;
    dialogBoxTypeEnum = DialogBoxType;

    buttonTextEnum = ButtonText;
    // dialogBoxText contains the body of dialog box
    dialogBoxText: string[] = [];
    showCopyDialogBox = false;
    // this property hold the selected Exception ItemId
    selectedExceptionItemId = '';
    // this property temporarily hold newly added exception detail until pushed to store.
    addExceptionDetail!: AchFilterInquiryRecord;
    // this holds the type of row select after client side delete and add.
    rowSelectionType = RowSelectionType.None;
    // nextRowSelectionId holds next record need to be selected.
    nextRowSelectionId = '';
    // as splitter screen sizes
    sizes = {
        section1: {
            area1: 30,
            area2: 70,
        },
        section2: {
            area1: 50,
            area2: 50,
        },
    };

    public exceptionItemsgridOptions: GridOptions = {
        onModelUpdated: event => this.onModelUpdated(event),
        onGridSizeChanged: event => this.onGridSizeChanged(event),
        onRowSelected: event => this.onRowSelected(event),
        getRowId: event => this.getRowId(event),
        onGridReady: event => this.onGridReadyACHFilter(event),
    };

    public copyFiltergridOptions: GridOptions = {
        onGridSizeChanged: event => this.onGridSizeChanged(event),
        onGridReady: event => this.onGridReadyCopyFilter(event)
    };
    exceptionGridAPI!: GridApi;
    copyFiltergridAPI!: GridApi;

    form!: UntypedFormGroup;
    subs: Subscription[] = [];

    achFilterInquiryInformation$!: Observable<ACHFilterInquiryInformation>;
    achFilterInquiryValues = AchFilterInquiryValueTypes;
    copyFilterAccountDetailRequest!: CopyFilterAccountDetailRequest;
    // used to get the account details for the copyfilter pop-up.
    currentAccountDetailIndex = -1;
    // this property holds newly added exception details to check if newly exception detail is modified or not.
    // this propertys helps to block saving the unmodified record to api
    addedExceptionDetails: AchFilterInquiryRecord[] = [];
    // get edit or add or view achfilter inquiry screen.
    pageMode$: Observable<PageMode>;
    achFilterInquirySearchRecord$!: Observable<ACHFilterInquirySearchRecordModel | undefined>;
    achFilterInquirySearchRecord!: ACHFilterInquirySearchRecordModel | undefined;
    accountDetails$!: Observable<AccountDetails[] | undefined>;
    selectedAccountDetails: AccountDetails[] = [];
    isUserInCopyACHFilter = false;
    // tracked modified data.
    isACHFilterInquiryModified = false;
    showUnsaveDialogBox = false;
    dialogBoxTextEnum = DialogBoxText;

    constructor(private store: Store, private gridDef: ACHFilterInquiryGridColDef) {
        this.pageMode$ = this.store.select(this.achFilterInquirySelector.selectPageMode);
        this.achFilterInquirySearchRecord$ = this.store.select(this.achFilterInquirySelector.selectAchFilterInquirySearchRecord);
        this.accountDetails$ = this.store.select(this.achFilterInquirySelector.selectAccountList);
        this.exceptionItems$ = this.store.select(this.achFilterInquirySelector.selectExceptionItems);
        // get ach filter information formly options.
        this.achFilterInquiryFormState$ = this.store.select(this.achFilterInquirySelector.selectAchFilterInformationFormlyOptions);
        this.exceptionDetailFormState$ = this.store.select(this.achFilterInquirySelector.selectExceptionDetailFormlyOptions);
        this.exceptionItemId$ = this.store.select(this.achFilterInquirySelector.selectExceptionItemId);
        this.exceptionDetail$ = this.store.select(this.achFilterInquirySelector.selectExceptionDetail);
        this.errorMessagesAtItemID$ = this.store.select(this.achFilterInquirySelector.selectErrorMessagesItemID);
        this.form = new UntypedFormGroup({});
    }

    onGridReadyACHFilter(event: GridReadyEvent) {
        this.exceptionGridAPI = event.api;
        event.api?.closeToolPanel();
        this.exceptionGridAPI.getRowNode('0')?.selectThisNode(true);
    }

    onGridReadyCopyFilter(event: GridReadyEvent) {
        this.copyFiltergridAPI = event.api;
    }

    ngOnInit(): void {
        // assigning grid options
        this.exceptionItemsgridOptions = { ...this.exceptionItemsgridOptions, ...this.gridDef.exceptionItemsgridOptions };
        // to get the ACH Filter Information.
        const achFilterRequest: AchFilterInquiryRequest = {
            srchMsgRqHdr: {
                trackingId: '',
                institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                workstationId: '',
                securityGroup: '',
                maxRecords: '10',
                cursor: '123'
            },
            acctId: '88880',
            acctType: 'A',
        };
        this.store.dispatch(this.achFilterInquiryActions.getACHFilterInquirySearchRecords({
            request: achFilterRequest,
            isUserInCopyACHFilter: this.isUserInCopyACHFilter
        }));

        // get the Error Messages for item IDs.
        const subErrorMessagesAtItemID = this.errorMessagesAtItemID$.subscribe((itemIDList) => {
            if (itemIDList && itemIDList.length > 0) {
                // highlight for least index of Error Messages. default ItemIDList is a sorted array.
                if (this.rowSelectionType === RowSelectionType.RefreshRowSelection) {
                    this.nextRowSelectionId = itemIDList[0];
                    this.rowSelectionType = RowSelectionType.NewRecordRowSelection;
                }
            }
        });

        const subACHFilterInquirySearchRecord = this.achFilterInquirySearchRecord$.subscribe((achfiltersearch) => {
            this.achFilterInquirySearchRecord = achfiltersearch;
            if (this.exceptionGridAPI) {
                this.exceptionGridAPI.redrawRows();
            }
        });

        this.subs.push(subErrorMessagesAtItemID, subACHFilterInquirySearchRecord);
    }


    ngOnDestroy(): void {
        unsubscribe(this.subs);
    }

    onRowSelected(event: RowSelectedEvent) {
        if (!this.form?.get('highAmount')?.hasError('highAmountValidation') && event.node.isSelected()) {
            this.store.dispatch(this.achFilterInquiryActions.selectedExceptionItemId({ exceptionItemId: event.data?.exceptionItemId }));
            this.selectedExceptionItemId = event.data?.exceptionItemId;
        } else if (event.data?.exceptionItemId !== this.selectedExceptionItemId) {
            event.node.setSelected(false);
            this.exceptionGridAPI.getRowNode(this.selectedExceptionItemId)?.selectThisNode(true);
        }
    }

    onModelUpdated(event: PaginationChangedEvent) {
        if (!this.exceptionGridAPI) {
            return;
        }
        if (this.rowSelectionType !== RowSelectionType.None) {
            event.api.deselectAll();
            // row selection is not able to retrieved when getting a new set of data from api.
            // below code force the first record to be highlight.
            if (this.rowSelectionType === RowSelectionType.RefreshRowSelection) {
                event.api.getRenderedNodes()[0].selectThisNode(true);
            } else {
                // forcing the newly adding record to highlight when rowSelectionType is NewRecordRowSelection.
                // forcing the deleted record to higlight previous or next record when rowselectionType is NewRecordRowSelection.
                event.api.getRowNode(this.nextRowSelectionId)?.selectThisNode(true);
            }
        }
        this.rowSelectionType = RowSelectionType.None;
    }

    getRowId(params: GetRowIdParams) {
        return params.data.exceptionItemId;
    }

    onGridSizeChanged(event: GridSizeChangedEvent) {
        event.api.sizeColumnsToFit();
    }

    // this event executes on click of delete button.
    deleteButton(isDeleteACHFilterInquiry = false) {
        this.isDeleteACHFilterInquiry = isDeleteACHFilterInquiry;
        this.dialogBoxType = this.dialogBoxTypeEnum.Delete;
        this.dialogBoxText = [];
        if (this.isDeleteACHFilterInquiry) {
            this.dialogBoxText.push(this.achFilterInquiryValueTypes.deleteGlobalDialogBoxMessage);
            this.dialogBoxTitle = this.achFilterInquiryValueTypes.deleteGlobalDialogBoxTitle;
        } else {
            this.dialogBoxTitle = this.achFilterInquiryValueTypes.deleteDialogBoxTitle;
        }
        this.showDialogBox = true;
    }

    cancelButton() {
        this.dialogBoxType = this.dialogBoxTypeEnum.unsavedChanges;
        this.dialogBoxTitle = this.dialogBoxTextEnum.CancelDialogBoxTitle;
        this.dialogBoxText = [];
        this.dialogBoxText.push(this.dialogBoxTextEnum.CancelDialogBoxText);
        this.showDialogBox = true;
    }

    getCopyFilterAccountDetails() {
        // this.dialogBoxType = this.achFilterInquiryValues.copy;
        this.showCopyDialogBox = true;
        this.dialogBoxTitle = this.achFilterInquiryValues.copyFilterDialogBoxTitle;
        this.copyFiltergridOptions = { ...this.copyFiltergridOptions, ...this.gridDef.copyFilterGridOptions };
        this.store.dispatch(this.achFilterInquiryActions.getCopyFilterAccountList({ copyAccountDetailRequest: this.copyFilterAccountDetailRequest }));
    }

    dialogBoxClose(e: any) {
        // this if else condition used to seperate the global delete and row level delete.
        if (e.detail === this.buttonTextEnum.Delete) {
            if (this.isDeleteACHFilterInquiry) {
                this.deleteACHFilterInquiry();
            } else {
                this.deleteExceptionItem();
            }
        }
        if (e.detail === this.buttonTextEnum.DonotSave) {
            if (this.isUserInCopyACHFilter) {
                this.isUserInCopyACHFilter = !this.isUserInCopyACHFilter;
            }
            this.rowSelectionType = RowSelectionType.RefreshRowSelection;
            //TODO : highlighting the first record after refresing the grid is handling after integreting with api.
            this.store.dispatch(this.achFilterInquiryActions.getACHFilterInquirySearchRecords({
                request: {} as AchFilterInquiryRequest,
                isUserInCopyACHFilter: this.isUserInCopyACHFilter
            }));
        }
        this.showDialogBox = false;
    }

    // this event will execute before closing of override dialog box
    // TODO : complete functionality for override dailog box will be implemented when screen is integrated with api.
    overridedialogBoxClose(selectedFaultError: SelectedFaultError) {
        if (selectedFaultError.clickAction === this.buttonTextEnum.Override) {
            this.saveAchFilterInquiry(selectedFaultError.faultRecInfoArray);
        } else if (selectedFaultError.clickAction === this.buttonTextEnum.Cancel) {
            // resetting fault error message in store to show the override dialogbox for same error message again.
            // override dialogbox will not display if same error message is stored again in ngrx store.
            this.store.dispatch(this.achFilterInquiryActions.addFaultRecMessages({ faultRec: [] }));
        }
        this.showOverrideDialogBox = false;
    }

    // dialog box close event trigger for dialog box buttons
    unsaveDialogBoxClose(unsaveDialogBoxEvent: any) {
        if (unsaveDialogBoxEvent.detail === this.buttonTextEnum.DonotSave) {
            this.getPreviousAccountACHFilterInquiry();
        }
        this.showUnsaveDialogBox = false;
    }

    copyDialogBoxClose(e: any) {
        if (e.detail === this.achFilterInquiryValues.select) {
            // get the selected account details
            this.selectedAccountDetails = this.copyFiltergridAPI.getSelectedRows() ?? [];
            this.currentAccountDetailIndex = 0;
            const achfilterreq: AchFilterInquiryRequest = {
                srchMsgRqHdr: {
                    trackingId: '',
                    institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                    workstationId: '',
                    securityGroup: '',
                    maxRecords: '10',
                    cursor: '123'
                },
                acctId: this.selectedAccountDetails[this.currentAccountDetailIndex].acctId,
                acctType: this.selectedAccountDetails[this.currentAccountDetailIndex].acctType,
            };
            this.isUserInCopyACHFilter = true;
            this.isACHFilterInquiryModified = false;
            this.store.dispatch(this.achFilterInquiryActions.getACHFilterInquirySearchRecords({
                request: achfilterreq,
                isUserInCopyACHFilter: this.isUserInCopyACHFilter
            }));
        }
        this.showCopyDialogBox = false;
    }

    // this function is used to change the page mode.
    editACHFilterInquiry() {
        this.store.dispatch(this.achFilterInquiryActions.togglePageMode({ pageMode: this.pageModeEnum.Edit }));
    }

    // this function is used to dispatch delete action
    deleteExceptionItem(faultArrayMessages: FaultMsgRec[] = []) {
        const node = this.exceptionGridAPI.getSelectedNodes()[0];
        const rowIndex = node?.rowIndex ?? 0;
        const previousRow = this.exceptionGridAPI.getDisplayedRowAtIndex(rowIndex - 1);
        // check if previous record is existing or not
        if (previousRow !== undefined) {
            // setting the exceptionItemID of previous record to hightlight.
            this.nextRowSelectionId = previousRow.data?.exceptionItemId;
            this.rowSelectionType = RowSelectionType.NewRecordRowSelection;
        } else {
            // if previous record is undefined next record shoudl display so checking next record in grid
            const nextRow = this.exceptionGridAPI.getDisplayedRowAtIndex(rowIndex + 1);
            if (nextRow !== undefined) {
                this.nextRowSelectionId = nextRow.data?.exceptionItemId;
                this.rowSelectionType = RowSelectionType.NewRecordRowSelection;
            } else {
                this.nextRowSelectionId = '';
            }
        }
        this.rowSelectionType = RowSelectionType.NewRecordRowSelection;
        this.store.dispatch(this.achFilterInquiryActions.deleteExceptionDetail({ exceptionItemId: this.selectedExceptionItemId }));
    }

    // add exception detail to exception item
    addACHFilterInquiry(includeACHFilterInformation = false) {
        // setting the intial values for newly added record to comparing unmodified or modified status.
        this.addExceptionDetail = {
            achFilterStateType: 'Active',
            exceptionItemId: generateRandomString(16),
            changeStatus: ChangeStatusEnum.Newlyadded,
            isModified: false,
            achCompanyAllowType: null,
            achAllowTransactionType: null,
            achCompanyName: '',
            achStandardEntryClass: null,
            achFilterRemark: '',
            expirationDate: null,
            achBankingRountingNumber: null,
            achCompanyId: '',
            lowAmount: 0,
            highAmount: 0,
        };
        /* dispatches the action to get default value for ach filter information. */
        let achFilterRequest!: AchFilterInquiryRequest;
        if (includeACHFilterInformation) {
            achFilterRequest = {
                srchMsgRqHdr: {
                    trackingId: '',
                    institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                    workstationId: '',
                    securityGroup: '',
                    maxRecords: '10',
                    cursor: '123'
                },
                acctId: '88880',
                acctType: 'A',
            };
        }
        this.rowSelectionType = RowSelectionType.NewRecordRowSelection;
        this.nextRowSelectionId = this.addExceptionDetail.exceptionItemId ?? '';
        this.addedExceptionDetails.push(this.addExceptionDetail);
        this.store.dispatch(this.achFilterInquiryActions.addACHFilterInquiry({
            exceptionDetail: this.addExceptionDetail,
            request: achFilterRequest
        }));
    }

    // gutter double click for right side screen.
    gutterDblClick(event: IOutputData) {
        this.sizes.section1.area1 = 30;
        this.sizes.section1.area2 = 70;
    }

    // gutter double click for left side screen.
    gutterDetailDblClick(event: IOutputData) {
        this.sizes.section2.area1 = 50;
        this.sizes.section2.area2 = 50;
    }

    // this function executed at the end of gutter drag.
    onDragEnd(section: number, e: { gutterNum: number; sizes: number[] }) {
        // section 1 is referrred for left side screen.
        if (section === 1) {
            // section 1 is referrred for left side screen.
            this.sizes.section1.area1 = e.sizes[0];
            this.sizes.section1.area2 = e.sizes[1];
        } else {
            // section 2 is referrred for right side screen.
            this.sizes.section2.area1 = e.sizes[0];
            this.sizes.section2.area2 = e.sizes[1];
        }
    }

    //this method used to update the achfilterinformation data in the Store.
    updateACHFilterInformation(modAchFilterInformation: ACHFilterInquiryInformation) {
        if (this.isUserInCopyACHFilter) {
            this.isACHFilterInquiryModified = true;
        }
        this.store.dispatch(this.achFilterInquiryActions.updateACHFilterInquiryInformation({ updateAchFilterInformation: modAchFilterInformation }));
    }

    // this event will fire when there is a model change in formly of Exception Detail.
    updateExceptionDetail(exceptionDetail: AchFilterInquiryRecord) {
        if (exceptionDetail.exceptionItemId) {
            if (this.isUserInCopyACHFilter) {
                // setting isACHFilterInquiryModified true to display unSavedChanges dialog box.
                this.isACHFilterInquiryModified = true;
            }
            if (exceptionDetail.changeStatus === ChangeStatusEnum.Newlyadded) {
                const previousStateExceptionDetail = this.addedExceptionDetails.find((x) => x.exceptionItemId === exceptionDetail.exceptionItemId);
                // comparing the old version of exception detail with updated exception detail
                exceptionDetail.isModified = this.compareObject(previousStateExceptionDetail, exceptionDetail, 'isModified');
            } else {
                exceptionDetail.isModified = true;
            }


            // validating the lowamount is greater than highamount and updating the hasError to highlight the error in grid.
            if ((exceptionDetail.lowAmount && exceptionDetail.highAmount)
                && (exceptionDetail.lowAmount > exceptionDetail.highAmount)) {
                exceptionDetail.hasError = true;
            } else {
                exceptionDetail.hasError = undefined;
            }

            if (exceptionDetail.expirationDate !== null && exceptionDetail.expirationDate !== '') {
                exceptionDetail.expirationDate = formatDate(exceptionDetail.expirationDate ?? '', DateFormatterType.IsoDateFormatter);
            }
            this.store.dispatch(this.achFilterInquiryActions.updateExceptionDetail({ updateExceptionDetail: exceptionDetail }));
        }
    }

    // this function is used to save the records.
    saveAchFilterInquiry(faultArrayMessages: FaultMsgRec[] = []) {
        if (!this.form?.get('highAmount')?.hasError('highAmountValidation')) {
            // filtering out the unmodified and newly added record from all exception items.
            const updatedExceptionItems = (this.achFilterInquirySearchRecord?.exceptionItems ?? []).filter((x) => {
                if (x.changeStatus === ChangeStatusEnum.Newlyadded && x.isModified === false) {
                    return;
                }
                return { ...x };
            });

            const achFilterInquiryModRequest: ACHFilterInquiryModRequest = {
                srchMsgRqHdr: {
                    trackingId: '',
                    institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                    workstationId: '',
                    securityGroup: '',
                    maxRecords: '10',
                    cursor: '123'
                },
                acctId: '12',
                acctType: 'A',
                // for each transaction user add, will update the data in store so same models are passed on save click to api.
                achFilterInquirySearchRecords: {
                    achFilterInquiryInformation: { ...this.achFilterInquirySearchRecord?.achFilterInquiryInformation },
                    exceptionItems: updatedExceptionItems,
                    // TODO : this property will be removed once api is integrated.
                    achFilterFields: [],
                },
                destinationAccountDetails: {
                    acctId: this.isUserInCopyACHFilter ? this.selectedAccountDetails[this.currentAccountDetailIndex].acctId : '',
                    acctType: this.isUserInCopyACHFilter ? this.selectedAccountDetails[this.currentAccountDetailIndex].acctType : '',
                    name: this.isUserInCopyACHFilter ? this.selectedAccountDetails[this.currentAccountDetailIndex].name : '',
                },
            };

            // reset to ach filter when user is in copy filter :
            /* checking if user is in copy filter.
                * resetting iscopyfilter to false when displayed account is last one in ach filter.
                * increement the currnetAccountDetails on click on save button to navigate to next record.
                */
            if (this.isUserInCopyACHFilter) {
                if (this.currentAccountDetailIndex === this.selectedAccountDetails.length - 1) {
                    this.selectedAccountDetails = [];
                    this.currentAccountDetailIndex = -1;
                    this.isUserInCopyACHFilter = false;
                } else {
                    this.currentAccountDetailIndex++;
                }
                this.isACHFilterInquiryModified = false;
            }
            // selecting the first record after save.
            this.rowSelectionType = RowSelectionType.RefreshRowSelection;
            this.store.dispatch(this.achFilterInquiryActions.updateACHFilterInquiry({
                request: achFilterInquiryModRequest,
                isUserInCopyACHFilter: this.isUserInCopyACHFilter
            }));
        }
    }

    // global delete functionality.
    deleteACHFilterInquiry() {
        const deleteACHFilterInquiryRequest: ACHFilterInquiryDeleteRequest = {
            deleteField: 'Y',
            srchMsgRqHdr: {
                trackingId: '',
                institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                workstationId: '',
                securityGroup: '',
                maxRecords: '10',
                cursor: '123'
            },
            acctId: '12',
            acctType: 'A',
        };
        this.store.dispatch(this.achFilterInquiryActions.deleteACHFilterInquiry({
            deleteRequest: deleteACHFilterInquiryRequest,
            isUserInCopyACHFilter: this.isUserInCopyACHFilter
        }));

    }

    /* event to get the previous ACH Filter Information for copy filter */
    backButton() {
        /* isACHFilterInquiryModified only set to true when modifing the data.
    when user deleted the records from exception Items ,isACHFilterInquiryModified is not true to show the unsaved dialog box whereas
    status of earch records are updated as Delete.this changeStatus determine if any record is deleted to show the unsaved dialog box.
    */
        if (this.isACHFilterInquiryModified || this.achFilterInquirySearchRecord?.exceptionItems?.some((x) => x.changeStatus === ChangeStatusEnum.Delete)) {
            this.showUnsaveDialogBox = true;
        } else {
            this.getPreviousAccountACHFilterInquiry();
        }
    }

    // get the previous account ACH Filter Inquiry Details
    getPreviousAccountACHFilterInquiry() {
        this.currentAccountDetailIndex--;
        const achfilterreq: AchFilterInquiryRequest = {
            srchMsgRqHdr: {
                trackingId: '',
                institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                workstationId: '',
                securityGroup: '',
                maxRecords: '10',
                cursor: '123'
            },
            acctId: this.selectedAccountDetails[this.currentAccountDetailIndex].acctId,
            acctType: this.selectedAccountDetails[this.currentAccountDetailIndex].name,
        };
        // selecting the first record.
        this.rowSelectionType = RowSelectionType.RefreshRowSelection;
        this.store.dispatch(this.achFilterInquiryActions.getACHFilterInquirySearchRecords({
            request: achfilterreq,
            isUserInCopyACHFilter: this.isUserInCopyACHFilter
        }));
        this.isACHFilterInquiryModified = false;
    }

    // comparing  OldData with newData. return true if newData is modified and false if newData is unmodified.
    // TODO: change it to generic.
    compareObject(oldData: any, newData: any, skipKey: string) {
        for (const key of Object.keys(oldData)) {
            if (key !== skipKey && oldData[key] !== newData[key]) {
                return true;
            }
        }
        return false;
    }
}
