import { createAction, props } from '@ngrx/store';
import { FaultMsgRec, PageMode } from '@uid/uid-models';
import {  CopyFilterAccountDetailRequest } from '../../models/copyfilter-request.model';
import { ACHFilterInquiryDeleteRequest } from '../../models/achfilter-inquiry-delete-request.model';
import { ACHFilterInquiryInformation } from '../../models/achfilter-inquiry-information.model';
import { ACHFilterInquiryModRequest } from '../../models/achfilter-inquiry-mod-request.model';
import { ACHFilterInquiryModResponse } from '../../models/achfilter-inquiry-mod-response.model';
import { AchFilterInquiryRecord } from '../../models/achfilter-inquiry-record.model';
import { AchFilterInquiryRequest } from '../../models/achfilter-inquiry-request.model';
import { AchFilterInquiryResponse } from '../../models/achfilter-inquiry-response.model';
import { CopyFilterAccountDetailsResponse } from '../../models/copyfilter-accountdetails-response.model';
import { ACHFilterInformationDefaultValueResponse } from '../../models/achfilter-information-defaultvalue-response.model';

export const getACHFilterInquirySearchRecords = createAction('[ACHFilter Inquiry] Get ACHFilter Inquiry Records ', props<{ request: AchFilterInquiryRequest;isUserInCopyACHFilter: boolean }>());

export const getACHFilterInquirySearchRecordsRetrived = createAction('[ACHFilter Inquiry] Get ACHFilter Inquiry Records Retrived', props<{ response: AchFilterInquiryResponse }>());

export const getACHFilterInquirySearchRecordsRetrivedFailure = createAction('[ACHFilter Inquiry] Get ACHFilter Inquiry Records Retrived Failure', props<{ error: Error }>());

export const selectedExceptionItemId = createAction('[ACHFilter Inquiry] Get selected ExceptionItemId', props<{ exceptionItemId: string }>());

export const togglePageMode = createAction('[ACHFilter Inquiry] Change Page Mode', props<{ pageMode: PageMode }>());

export const updateACHFilterInquiry =createAction('[ACHFilter Inquiry] Update ACHFilter Inquiry  Records',props<{ request: ACHFilterInquiryModRequest;isUserInCopyACHFilter: boolean}>());

export const updateACHFilterInquirySuccesss = createAction('[ACHFilter Inquiry] Update ACHFilter Inquiry  Records Success',props<{ response: ACHFilterInquiryModResponse}>());

export const updateACHFilterInquiryFailure = createAction('[ACHFilter Inquiry] Update ACHFilter Inquiry  Records Failure',props<{ error: Error }>());

export const addFaultRecMessages = createAction('[ACHFilter Inquiry] Add FaultRecMessages To Store', props<{ faultRec: FaultMsgRec[] }>());

export const deleteExceptionDetail = createAction('[ACHFilter Inquiry] Delete Exception Detail From Exception Items',
    props<{ exceptionItemId: string }>());

export const updateACHFilterInquiryInformation = createAction('[ACHFilter Inquiry] update achfilter information',props<{updateAchFilterInformation: ACHFilterInquiryInformation}>());

export const updateExceptionDetail =createAction('[ACHFilter Inquiry] Update Exception Detail In Store',
    props<{ updateExceptionDetail: AchFilterInquiryRecord}>());

export const deleteACHFilterInquiry = createAction('[ACHFilter Inquiry] Delete ACHFilter Inquiry  Records',props<{ deleteRequest: ACHFilterInquiryDeleteRequest;isUserInCopyACHFilter: boolean}>());

export const deleteACHFilterInquirySuccess = createAction('[ACHFilter Inquiry] Delete ACHFilter Inquiry  Records Success',props<{ response: AchFilterInquiryResponse}>());

export const deleteACHFilterInquiryFailure = createAction('[ACHFilter Inquiry] Delete ACHFilter Inquiry  Records Failure',props<{ error: Error}>());

export const getCopyFilterAccountList = createAction('[ACHFilter Inquiry] Get Copy Filter Records ', props<{ copyAccountDetailRequest: CopyFilterAccountDetailRequest }>());

export const getCopyFilterAccountListRetrived = createAction('[ACHFilter Inquiry] Get Copy Filter Records Retrived', props<{ response: CopyFilterAccountDetailsResponse }>());

export const getCopyFilterAccountListFailure = createAction('[ACHFilter Inquiry] Get Copy Filter Records Retrived Failure', props<{ error: Error }>());

export const addACHFilterInquiry =createAction('[ACHFilter Inquiry] Add ACH Filter Inquiry',
    props<{ exceptionDetail: AchFilterInquiryRecord;request: AchFilterInquiryRequest }>());

export const addACHExceptionItems =createAction('[ACHFilter Inquiry] Add Exception Detail',
    props<{ exceptionDetail: AchFilterInquiryRecord}>());

export const getDefaultValueACHFilterInformationRetrived = createAction('[ACHFilter Inquiry] Get Default Values For ACH Filter Information success', props<{ response: ACHFilterInformationDefaultValueResponse }>());

export const getDefaultValueACHFilterInformationFailure = createAction('[ACHFilter Inquiry] Get Default Values For ACH Filter Information Failure', props<{ error: Error }>());






