import { DataService } from './dataservice';

let service: DataService;

const httpMock = {
    get: jest.fn(),
    post: jest.fn(),
};

describe('DataService', () => {
    beforeEach(() => {
        service = new DataService(httpMock as any);
    });

    it('service should be created', () => {
        expect(service).toBeTruthy();
    });

    it('getACHFIlterInquiryInformationDetails returns modified mock data', () => {
        expect(service.getACHFilterInquiryInformationDetails({} as any)).toBeInstanceOf(Object);
    });

    it('updateACHFilterInquiry returns updates mock data', () => {
        expect(service.updateACHFilterInquiry({ achFilterInquiryAccountRequest: { srchMsgRqHdr: { data: 11 } }, destinationAccountDetails: { acctId: 11 }, achFilterInquirySearchRecords: {} } as any)).toBeInstanceOf(Object);
    });

    it('delete achFilterInquiry returns updates mock data', () => {
        expect(service.deleteACHFilterInquiry({} as any)).toBeInstanceOf(Object);
    });

    it('copy achFilterInquiry returns copy filter accoun list mock data', () => {
        expect(service.getCopyFilterAccountDetails).toBeInstanceOf(Object);
    });
});
