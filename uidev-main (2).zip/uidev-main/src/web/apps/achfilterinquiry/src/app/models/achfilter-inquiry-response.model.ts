import { SearchResponseHeaderModel } from '@uid/uid-models';
import { ACHFilterInquirySearchRecordModel } from './achfilter-inquiry-search-record.model';

export interface AchFilterInquiryResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    // achfltrsrchrec model which holds the excetion item details and ach information details
    achFilterInquirySearchRecord: ACHFilterInquirySearchRecordModel;
    showACHAutoReturn: boolean;
}
