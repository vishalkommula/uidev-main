import { ElemCancocType } from './achfilter-inquiry-elemcancoctype.model';

export interface SvcDescInfoRecModel{
    elemCancocctype: ElemCancocType[] ;
    description: string;
}
