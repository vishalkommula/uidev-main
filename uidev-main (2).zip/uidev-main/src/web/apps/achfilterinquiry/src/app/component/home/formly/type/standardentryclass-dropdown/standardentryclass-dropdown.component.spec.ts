import { StandardEntryClassDropdownComponent } from './standardentryclass-dropdown.component';

describe('StandardEntryClassDropdownComponent', () => {
    let component: StandardEntryClassDropdownComponent;

    beforeEach(() => {
        component = new StandardEntryClassDropdownComponent();
    });
    it('Component should be created', () => {
        expect(component).toBeTruthy();
    });
});
