import { SearchResponseHeaderModel } from '@uid/uid-models';
import { ACHFilterInquiryInformation } from './achfilter-inquiry-information.model';

export interface ACHFilterInformationDefaultValueResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    // holds the default values for ah filter inquiry information.
    achFilterInquiryInformation?: ACHFilterInquiryInformation;
}
