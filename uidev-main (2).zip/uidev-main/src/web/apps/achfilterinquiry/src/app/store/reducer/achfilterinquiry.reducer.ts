import * as ACHFilterInquiryActions from '../actions/achfilterinquiry.action';

import { createReducer, on } from '@ngrx/store';
import { PageMode } from '@uid/uid-models';
import { AchFilterInquiryResponse } from '../../models/achfilter-inquiry-response.model';
import { ACHFilterInquiryState } from '../state/achfilterinquiry.state';
import { ChangeStatusEnum } from '../../models/achfilter-inquiry.resource';
import { CopyFilterAccountDetailsResponse } from '../../models/copyfilter-accountdetails-response.model';

export const initialState: ACHFilterInquiryState = {
    achFilterInquiryResponse: {} as AchFilterInquiryResponse,
    pageMode: PageMode.Inquiry,
    faultRecInfoArray: [],
    selectedExceptionItemId: '',
    copyFilterAccountDetailsResponse: {} as CopyFilterAccountDetailsResponse,
};

export const reducer = createReducer(
    initialState,
    on(
        ACHFilterInquiryActions.getACHFilterInquirySearchRecordsRetrived,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            achFilterInquiryResponse: action.response,
            faultRecInfoArray: [],
        })
    ),

    on(
        ACHFilterInquiryActions.selectedExceptionItemId,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            selectedExceptionItemId: action.exceptionItemId,
        })
    ),

    on(
        ACHFilterInquiryActions.togglePageMode,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            pageMode: action.pageMode,
            faultRecInfoArray: [],
        })
    ),

    on(
        ACHFilterInquiryActions.updateACHFilterInquirySuccesss,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            achFilterInquiryResponse: {
                ...state.achFilterInquiryResponse,
                srchMsgRsHdr: action.response.srchMsgRsHdr,
                showACHAutoReturn: action.response.showACHAutoReturn,
                achFilterInquirySearchRecord: action.response.achFilterInquirySearchRecord,
            },
            faultRecInfoArray: [],
        })
    ),

    on(ACHFilterInquiryActions.deleteExceptionDetail, (state, action): ACHFilterInquiryState => {
        const exceptionDetailIndex = state.achFilterInquiryResponse.achFilterInquirySearchRecord?.exceptionItems?.findIndex((x) => x.exceptionItemId === action.exceptionItemId) ?? 0;
        // this condition is used to delete the newly added exception detail in exception items
        // newly added exception detail are permenantly removed from store.
        if ((state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems ?? [])[exceptionDetailIndex].changeStatus === ChangeStatusEnum.Newlyadded) {
            return {
                ...state,
                achFilterInquiryResponse: {
                    ...state.achFilterInquiryResponse,
                    achFilterInquirySearchRecord: {
                        ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                        exceptionItems: [
                            ...(state.achFilterInquiryResponse.achFilterInquirySearchRecord?.exceptionItems ?? []).slice(0, exceptionDetailIndex),
                            ...(state.achFilterInquiryResponse.achFilterInquirySearchRecord?.exceptionItems ?? []).slice(exceptionDetailIndex + 1),
                        ],
                    },
                },
            };
        } else {
            // this condition is used to update changeStatus to delete.
            // exception detail mark as delete in changeStatusEnum in store when exisint record is deleted.
            const exceptionDetail = (state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems ?? [])[exceptionDetailIndex];
            const updateExceptionDetail = { ...exceptionDetail };
            updateExceptionDetail.changeStatus = ChangeStatusEnum.Delete;
            return {
                ...state,
                achFilterInquiryResponse: {
                    ...state.achFilterInquiryResponse,
                    achFilterInquirySearchRecord: {
                        ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                        exceptionItems: [
                            ...(state.achFilterInquiryResponse.achFilterInquirySearchRecord?.exceptionItems ?? []).slice(0, exceptionDetailIndex),
                            // updating the exception detail to Exception Items with changeStatus to delete.
                            updateExceptionDetail,
                            ...(state.achFilterInquiryResponse.achFilterInquirySearchRecord?.exceptionItems ?? []).slice(exceptionDetailIndex + 1),
                        ],
                    },
                },
            };
        }
    }),

    on(
        ACHFilterInquiryActions.updateACHFilterInquiryInformation,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            achFilterInquiryResponse: {
                ...state.achFilterInquiryResponse,
                achFilterInquirySearchRecord: {
                    ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                    achFilterInquiryInformation: action.updateAchFilterInformation,
                },
            },
        })
    ),
    on(ACHFilterInquiryActions.addACHExceptionItems, (state, action): ACHFilterInquiryState => {
        const exceptionItems = state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems ? [...state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems] : [];
        exceptionItems.push(action.exceptionDetail);
        return {
            ...state,
            achFilterInquiryResponse: {
                ...state.achFilterInquiryResponse,
                achFilterInquirySearchRecord: {
                    ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                    exceptionItems: exceptionItems,
                },
            },
        };
    }),

    on(
        ACHFilterInquiryActions.getDefaultValueACHFilterInformationRetrived,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            achFilterInquiryResponse: {
                ...state.achFilterInquiryResponse,
                achFilterInquirySearchRecord: {
                    ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                    achFilterInquiryInformation: action.response.achFilterInquiryInformation,
                },
            },
            pageMode: PageMode.Add,
        })
    ),

    on(ACHFilterInquiryActions.updateExceptionDetail, (state, action): ACHFilterInquiryState => {
        const exceptionDetailIndex = state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems?.findIndex((x) => x.exceptionItemId === action.updateExceptionDetail.exceptionItemId) ?? 0;
        return {
            ...state,
            achFilterInquiryResponse: {
                ...state.achFilterInquiryResponse,
                achFilterInquirySearchRecord: {
                    ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                    exceptionItems: [
                        ...(state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems ?? []).slice(0, exceptionDetailIndex),
                        action.updateExceptionDetail,
                        ...(state.achFilterInquiryResponse.achFilterInquirySearchRecord.exceptionItems ?? []).slice(exceptionDetailIndex + 1),
                    ],
                },
            },
        };
    }),

    on(
        ACHFilterInquiryActions.deleteACHFilterInquirySuccess,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            achFilterInquiryResponse: {
                ...state.achFilterInquiryResponse,
                achFilterInquirySearchRecord: {
                    ...state.achFilterInquiryResponse.achFilterInquirySearchRecord,
                    //TODO : this will be replace with single reference after implementing the api.
                    achFilterInquiryInformation: action.response.achFilterInquirySearchRecord.achFilterInquiryInformation,
                    exceptionItems: action.response.achFilterInquirySearchRecord.exceptionItems,
                    achFilterFields: action.response.achFilterInquirySearchRecord.achFilterFields,
                },
            },
        })
    ),

    on(
        ACHFilterInquiryActions.getCopyFilterAccountListRetrived,
        (state, action): ACHFilterInquiryState => ({
            ...state,
            copyFilterAccountDetailsResponse: action.response,
        })
    ),
    on(ACHFilterInquiryActions.addFaultRecMessages, (state, action): ACHFilterInquiryState => ({
        ...state,
        faultRecInfoArray: action.faultRec,
    })),
);
