import { SearchRequestHeaderModel } from '@uid/uid-models';
import { AccountDetails } from './acountdetails.model';

export interface CopyFilterAccountDetailsResponse {
    srchMsgRsHdr: SearchRequestHeaderModel;
    accountDetails: AccountDetails[];
};
