import * as ACHFilterInquiryActions from '../actions/achfilterinquiry.action';
import { PageMode } from '@uid/uid-models';
import { initialState, reducer } from './achfilterinquiry.reducer';
import { ChangeStatusEnum } from '../../models/achfilter-inquiry.resource';

describe('ACH Filter Inquiry Reducers test', () => {
    it('achFilterInquirySearchRecords returns the correct state', () => {
        const responseModel = { this: 'is a test' };
        const state = reducer(initialState, ACHFilterInquiryActions.getACHFilterInquirySearchRecordsRetrived({ response: responseModel as any }));

        expect(state).toEqual({
            achFilterInquiryResponse: responseModel,
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
            selectedExceptionItemId: '',
            copyFilterAccountDetailsResponse: {},
        });
    });

    it('selectedExceptionItemId returns the correct state', () => {
        const responseModel = { this: 'is a test' };
        const state = reducer(initialState, ACHFilterInquiryActions.selectedExceptionItemId({ exceptionItemId: '123' }));

        expect(state).toEqual({
            achFilterInquiryResponse: {},
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
            selectedExceptionItemId: '123',
            copyFilterAccountDetailsResponse: {},
        });
    });

    it('togglePageMode returns the correct state', () => {
        const state = reducer(initialState, ACHFilterInquiryActions.togglePageMode({ pageMode: PageMode.Add }));

        expect(state).toEqual({
            achFilterInquiryResponse: {},
            pageMode: PageMode.Add,
            faultRecInfoArray: [],
            selectedExceptionItemId: '',
            copyFilterAccountDetailsResponse: {},
        });
    });

    it('updateACHFilterInquirySuccesss returs the correct state', () => {
        const responseModel = { achFilterInquiryResponse: { srchMsgRsHdr: {}, achFilterInquirySearchRecord: {} } };
        const state = reducer(
            initialState,
            ACHFilterInquiryActions.updateACHFilterInquirySuccesss({
                response: responseModel.achFilterInquiryResponse as any,
            })
        );

        expect(state).toEqual({
            achFilterInquiryResponse: responseModel.achFilterInquiryResponse,
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
            selectedExceptionItemId: '',
            copyFilterAccountDetailsResponse: {},
        });
    });

    it('deleteExceptionDetail returs the correct state when row is deleted', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.None },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                },
            },
        };
        const state = reducer(responseModel as any, ACHFilterInquiryActions.deleteExceptionDetail({ exceptionItemId: '12313' }));
        const expectedModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Delete },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                },
            },
        };
        expect(state).toStrictEqual(expectedModel);
    });

    it('deleteExceptionDetail returs the correct state when row is deleted for newly added record.', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                },
            },
        };
        const state = reducer(responseModel as any, ACHFilterInquiryActions.deleteExceptionDetail({ exceptionItemId: '12313' }));
        const expectedModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [{ exceptionItemId: '123', changeStatus: ChangeStatusEnum.None }],
                },
            },
        };
        expect(state).toStrictEqual(expectedModel);
    });

    it('updateACHFilterInquiryInformation returs the correct state with updated achFilter Information.', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        const state = reducer(responseModel as any, ACHFilterInquiryActions.updateACHFilterInquiryInformation({ updateAchFilterInformation: responseModel.achFilterInquiryResponse.achFilterInquirySearchRecord.achFilterInquiryInformation as any }));
        const expectedModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        expect(state).toStrictEqual(expectedModel);
    });

    it('updateExceptionDetail returs the correct state with updated expection item.', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        const state = reducer(responseModel as any, ACHFilterInquiryActions.updateExceptionDetail({ updateExceptionDetail: { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None } as any }));
        const expectedModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded },
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                    ],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        expect(state).toStrictEqual(expectedModel);
    });

    it('getDefaultValueACHFilterInformation returns the correct state', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [{ exceptionItemId: '123', changeStatus: ChangeStatusEnum.None }],
                    achFilterInquiryInformation: { allow: true },
                },
            },
            pageMode: PageMode.Inquiry,
        };
        const state = reducer(responseModel as any,
            ACHFilterInquiryActions.getDefaultValueACHFilterInformationRetrived(
        { response:{ achFilterInquiryInformation: { allow: false } } } as any));
        const expectedModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    achFilterInquiryInformation: { allow: false },
                    exceptionItems: [{ exceptionItemId: '123', changeStatus: ChangeStatusEnum.None }],
                },
            },
            pageMode: PageMode.Add,
        };
        expect(state).toEqual(expectedModel);
    });

    it('addACHExceptionItems returs the correct state', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [{ exceptionItemId: '123', changeStatus: ChangeStatusEnum.None }],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        const state = reducer(responseModel as any, ACHFilterInquiryActions.addACHExceptionItems({ exceptionDetail: { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded } as any }));
        const expectedModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [
                        { exceptionItemId: '123', changeStatus: ChangeStatusEnum.None },
                        { exceptionItemId: '12313', changeStatus: ChangeStatusEnum.Newlyadded },
                    ],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        expect(state).toEqual(expectedModel);
    });

    it('getCopyFilterAccountListRetrived returs the correct state', () => {
        const responseModel = {
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [{ exceptionItemId: '123', changeStatus: ChangeStatusEnum.None }],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        const state = reducer(responseModel as any, ACHFilterInquiryActions.getCopyFilterAccountListRetrived(
      { response: { allow: false } } as any));
        const expectedModel = {
            copyFilterAccountDetailsResponse: { allow: false },
            achFilterInquiryResponse: {
                achFilterInquirySearchRecord: {
                    exceptionItems: [{ exceptionItemId: '123', changeStatus: ChangeStatusEnum.None }],
                    achFilterInquiryInformation: { allow: true },
                },
            },
        };
        expect(state).toEqual(expectedModel);
    });
});
