import { SearchRequestHeaderModel } from '@uid/uid-models';
import { ACHFilterInquirySearchRecordModel } from './achfilter-inquiry-search-record.model';

import { AccountDetails } from './acountdetails.model';

export interface ACHFilterInquiryModRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    acctType: string;
    //achFilterInquirySearchRequest is hold the achfilterinformation and exception details.
    achFilterInquirySearchRecords: ACHFilterInquirySearchRecordModel;
    //destination Account details holds the destination accID to which ACH Filter Information should copy
    destinationAccountDetails: AccountDetails;
}
