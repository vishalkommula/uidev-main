import { Action, ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import mockData from '../../mock-data/achfilter-inquiry-response.json';
import getACHFilterInformationDefaultValues from '../../mock-data/achfilterinformation-defaultValues-response.json';
import { ACHFilterInquiryEffects } from './achfilterinquiry.effect';
import * as ACHFilterInquiryActions from '../../store/actions/achfilterinquiry.action';

jest.mock('@uid/uid-angular-controls', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

jest.mock('@ngrx/store', () => {
    const originalModule = jest.requireActual('@ngrx/store');

    return {
        ...originalModule,
        createSelector: jest.fn().mockReturnValue('test'),
    };
});

const dataServiceMock = {
    getACHFilterInquiryInformationDetails: () => of(mockData),
    updateACHFilterInquiry: () => of(mockData),
    deleteACHFilterInquiry: () => of(mockData),
    getDefaultValueACHFilterInformation:()=>of(getACHFilterInformationDefaultValues),
    getCopyFilterAccountDetails:()=>of([1,2])
};

const dataServiceErrorMock = {
    getACHFilterInquiryInformationDetails: () => throwError('Error Test'),
    updateACHFilterInquiry: () => throwError('Error Test'),
    deleteACHFilterInquiry: () => throwError('Error Test'),
    getDefaultValueACHFilterInformation:()=> throwError('Error Test'),
    getCopyFilterAccountDetails:()=>throwError('Error Test')
};

let actions: ActionsSubject;
let effects: ACHFilterInquiryEffects;

describe('ACH Filter Inquiry Effects tests', () => {
    beforeEach(() => {
        actions = new ActionsSubject();
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);
    });

    it('loadACHFilterInquiryResponse$ dispatches a achFilterInquiryRecordRetrieved action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.loadACHFilterInquiryResponse$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.getACHFilterInquirySearchRecords({} as any);
        actions.next(action);
        expect(result[0].type).toBe('[ACHFilter Inquiry] Get ACHFilter Inquiry Records Retrived');
        expect(result[1].type).toBe('[ACHFilter Inquiry] Change Page Mode');
    });

    it('loadACHFilterInquiryResponse$ dispatches a achFilterInquiryRecordFailure error action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceErrorMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.loadACHFilterInquiryResponse$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.getACHFilterInquirySearchRecords({ request: {} as any,isUserInCopyACHFilter:false });
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Get ACHFilter Inquiry Records Retrived Failure');
    });

    it('updateAchFileterInquiryInformation$ dispatches a Update ACHFIlter Inquiry  Records ', () => {
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.updateACHFilterInquiryInformation$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.updateACHFilterInquiry({} as any);
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Update ACHFilter Inquiry  Records Success');
    });

    it('updateAchFileterInquiryInformation$ dispatches a Failed ACHFilter Inquiry  action ', () => {
        effects = new ACHFilterInquiryEffects(dataServiceErrorMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.updateACHFilterInquiryInformation$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.updateACHFilterInquiry({} as any);
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Update ACHFilter Inquiry  Records Failure');
    });

    it('deleteACHFileterInquiry$ dispatches a Delete ACHFilter Inquiry action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.deleteACHFilterInquiry$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.deleteACHFilterInquiry({} as any);
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Delete ACHFilter Inquiry  Records Success');
    });

    it('deleteACHFileterInquiry$ dispatches a Failed Delete ACHFilter Inquiry action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceErrorMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.deleteACHFilterInquiry$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.deleteACHFilterInquiry({} as any);
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Delete ACHFilter Inquiry  Records Failure');
    });
    it('addACHFilterInquiry$ dispatches an action to update exception item', () => {
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.addACHFilterInquiry$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.addACHFilterInquiry({ request: {} as any,exceptionDetail:{ value:11 } as any });
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Get Default Values For ACH Filter Information success');
    });

    it('addACHFilterInquiry$ dispatches a success ACHFilter Information and exception Item action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.addACHFilterInquiry$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.addACHFilterInquiry({ request: { value:123 } as any,exceptionDetail:{ value:11 } as any });
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Get Default Values For ACH Filter Information success');
    });


    it('addACHFilterInquiry$ dispatch a failure ACHFilter Inquiry action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceErrorMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.addACHFilterInquiry$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.addACHFilterInquiry({ request: {} as any,exceptionDetail:{ value:11 } as any });
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Get Default Values For ACH Filter Information Failure');
    });

    it('loadCopyFilterAccountDetails$ dispatch a success getCopyFilterAccountListRetrive action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.loadCopyFilterAccountDetails$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.getCopyFilterAccountList({} as any);
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Get Copy Filter Records Retrived');
    });

    it('loadCopyFilterAccountDetails$ dispatch a failure getCopyFilterAccountListFailure action', () => {
        effects = new ACHFilterInquiryEffects(dataServiceErrorMock as any, actions);

        // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
        const result: Action[] = [];
        effects.loadCopyFilterAccountDetails$.subscribe((actionResponse) => {
            result.push(actionResponse);
        });
        const action = ACHFilterInquiryActions.getCopyFilterAccountList({} as any);
        actions.next(action);

        expect(result[0].type).toBe('[ACHFilter Inquiry] Get Copy Filter Records Retrived Failure');
    });
});
