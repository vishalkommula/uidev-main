
export interface AccountDetails{
    acctId: string;
    acctType: string;
    name: string;
};
