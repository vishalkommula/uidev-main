module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'achfilterinquiry',
    exposes: {
        './Module': 'apps/achfilterinquiry/src/app/component/home/home.module.ts',
    },
};
