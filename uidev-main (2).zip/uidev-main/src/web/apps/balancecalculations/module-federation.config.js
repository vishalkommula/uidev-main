module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'balancecalculations',
    exposes: {
        './Module': 'apps/balancecalculations/src/app/components/home/home.module.ts'
    },
};
