import * as BalanceCalculationsSelector from './balancecalculations.selector';

describe('Balance Calculations Selector Test',()=> {

    // Balance Calculations list selector test
    it('balance CalculationsDetails - should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[{ this: 'test data 1' },{ this: 'test data 2' }] } };
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });
    it('balanceCalculationsDetailsResponse - should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: {
            srchMsgRsHdr:{},
            acctId: '6001',
            acctType: 'S',
            acctBalInqRecArray:[{ this: 'test data 1' },{ this: 'test data 2' }],
            secondaryProductIsSupported:true
        } };
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsDetailsResponse.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse);
    });
    it('only available balance calculations with data- should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[{
            category:'Available Balance',
            activityType:'Previous Day\'s Balance',
            debits: 70,
            credits: 100,
            balance: 100,
            isCreditIncluded:true,
            isDebitIncluded:false
        },
        {
            category:'Available Balance',
            activityType:'Items Posted',
            debits: 200,
            credits: 400,
            balance: 200,
            isCreditIncluded:true,
            isDebitIncluded:true
        },
        ] } };
        const selector = BalanceCalculationsSelector.selectBalanceOnlyAvailableBalanceDataDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });
    it('only Collected balance calculations with data- should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[{
            category:'Collected Balance',
            activityType:'Previous Day\'s Balance',
            debits: 70,
            credits: 100,
            balance: 100,
            isCreditIncluded:true,
            isDebitIncluded:false
        },
        {
            category:'Collected Balance',
            activityType:'Items Posted',
            debits: 200,
            credits: 400,
            balance: 200,
            isCreditIncluded:true,
            isDebitIncluded:true
        },
        ] } };
        const selector = BalanceCalculationsSelector.selectBalanceOnlyCollectedBalanceDataDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });

    it('only Ledger balance calculations with data- should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[{
            category:'Ledger Balance',
            activityType:'Previous Day\'s Balance',
            debits: 70,
            credits: 100,
            balance: 100,
            isCreditIncluded:true,
            isDebitIncluded:false
        },
        {
            category:'Ledger Balance',
            activityType:'Items Posted',
            debits: 200,
            credits: 400,
            balance: 200,
            isCreditIncluded:true,
            isDebitIncluded:true
        },
        ] } };
        const selector = BalanceCalculationsSelector.selectBalanceOnlyLedgerBalanceDataDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });
    it('only available balance calculations with data- should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[{
            category:'Collected Balance',
            activityType:'Previous Day\'s Balance',
            debits: 70,
            credits: 100,
            balance: 100,
            isCreditIncluded:true,
            isDebitIncluded:false
        },
        {
            category:'Collected Balance',
            activityType:'Items Posted',
            debits: 200,
            credits: 400,
            balance: 200,
            isCreditIncluded:true,
            isDebitIncluded:true
        },
        ] } };
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsCollectedBalanceDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });

    it('only available balance calculations with data- should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[{
            category:'Ledger Balance',
            activityType:'Previous Day\'s Balance',
            debits: 70,
            credits: 100,
            balance: 100,
            isCreditIncluded:true,
            isDebitIncluded:false
        },
        {
            category:'Ledger Balance',
            activityType:'Items Posted',
            debits: 200,
            credits: 400,
            balance: 200,
            isCreditIncluded:true,
            isDebitIncluded:true
        },
        ] } };
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsLedgerBalanceDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });
    it('only balance calculations empty data - should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: { acctBalInqRecArray:[] } };
        const selector = BalanceCalculationsSelector.selectBalanceOnlyAvailableBalanceDataDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });

    it('BalanceCalculation AvailableBalanceResponse should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: {
            acctBalInqRecArray:[{
                category:'Available Balance',
                activityType:'Previous Day\'s Balance',
                debits: 0,
                credits: 100,
                balance: 100,
                isCreditIncluded:true,
                isDebitIncluded:false
            },
            {
                category:'Available Balance',
                activityType:'Items Posted',
                debits: 200,
                credits: 400,
                balance: 200,
                isCreditIncluded:true,
                isDebitIncluded:true
            },
            ] }
        } ;
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsAvailableBalanceDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });
    it('BalanceCalculation Calculated Balance response should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: {
            acctBalInqRecArray:[{
                category:'Collected Balance',
                activityType:'Previous Day\'s Balance',
                debits: 0,
                credits: 100,
                balance: 100,
                isCreditIncluded:true,
                isDebitIncluded:false
            },
            {
                category:'Collected Balance',
                activityType:'Items Posted',
                debits: 200,
                credits: 400,
                balance: 200,
                isCreditIncluded:true,
                isDebitIncluded:true
            },
            ] }
        };
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsCollectedBalanceDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);
    });
    it('BalanceCalculation Ledger Balance response should be excuted',()=> {
        const balanceCalculationsListMock = { balanceCalculationsResponse: {
            acctBalInqRecArray:[{
                category:'Ledger Balance',
                activityType:'Previous Day\'s Balance',
                debits: 0,
                credits: 100,
                balance: 100,
                isCreditIncluded:true,
                isDebitIncluded:false
            },
            {
                category:'Ledger Balance',
                activityType:'Items Posted',
                debits: 200,
                credits: 400,
                balance: 200,
                isCreditIncluded:true,
                isDebitIncluded:true
            },
            ] }
        };
        const selector = BalanceCalculationsSelector.selectBalanceCalculationsLedgerBalanceDetails.projector(balanceCalculationsListMock);
        expect(selector).toEqual(balanceCalculationsListMock.balanceCalculationsResponse.acctBalInqRecArray);

    });

    it('Available Balance Should be executed',() =>{
        const availableBalanceMock= { balanceCalculationsResponse :{
            availableBalance:{ category:'Collected Balance',
                activityType:'Items Posted',
                balance: 200, }
        }
        };
        const selector = BalanceCalculationsSelector.selectAvailableBalance.projector(availableBalanceMock);
        expect(selector).toEqual(availableBalanceMock.balanceCalculationsResponse.availableBalance);
    });

    it('Collected Balance Should be executed',() =>{
        const collectedBalanceMock= { balanceCalculationsResponse :{
            collectedBalance:{ category:'Collected Balance',
                activityType:'Items Posted',
                balance: 200, }
        }
        };
        const selector = BalanceCalculationsSelector.selectCollectedBalance.projector(collectedBalanceMock);
        expect(selector).toEqual(collectedBalanceMock.balanceCalculationsResponse.collectedBalance);
    });

    it('Ledger Balance Should be executed',() =>{
        const ledgerBalanceMock= { balanceCalculationsResponse :{
            ledgerBalance:{ category:'Collected Balance',
                activityType:'Items Posted',
                balance: 200, }
        }
        };
        const selector = BalanceCalculationsSelector.selectLedgerBalance.projector(ledgerBalanceMock);
        expect(selector).toEqual(ledgerBalanceMock.balanceCalculationsResponse.ledgerBalance);
    });



});
