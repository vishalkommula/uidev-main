export enum BalanceCalculationsEnum {
   availableBalance = 'Available Balance',
   collectedBalance = 'Collected Balance',
   ledgerBalance = 'Ledger Balance'
};
