import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// Ag-grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';

// UID
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';

import { HomeComponent } from './home.component';
import { DataService } from '../../service/data.service';
import { BalanceCalculationsEffects } from '../../store/effects/balancecalculations.effects';
import { balanceCalculationsReducer } from '../../store/reducers/balancecalculations.reducer';
import { UidAggridModule } from '@uid/uid-grid';

const routes: Routes = [
    { path: '', component: HomeComponent }
];

@NgModule({
    declarations: [
        HomeComponent,
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        AgGridModule,
        UidAngularControlsModule,
        UidAggridModule,
        UidDirectivesModule,
        UidPipesModule,
        ReactiveComponentModule,
        StoreModule.forFeature('balanceCalculations', balanceCalculationsReducer),
        EffectsModule.forFeature([BalanceCalculationsEffects]),
    ],
    providers:[DataService],
    schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule { }
