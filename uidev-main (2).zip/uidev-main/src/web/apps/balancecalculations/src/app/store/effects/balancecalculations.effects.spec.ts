
import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import balanceCalculationsMockData from '../../mock-data/balancecalculations.silverlake.mock.json';
import * as BalanceCalculationsActions from '../actions/balancecalculations.action';
import { BalanceCalculationsEffects } from './balancecalculations.effects';


// mocking success service method
const balanceCalculationsSuccess = {
    getBalanceCalculationDetails: ()=> of(balanceCalculationsMockData),
};

// mocking faiure service method
const balanceCalculationsFailureMock = {
    getBalanceCalculationDetails: ()=> throwError('Error - getting the balance calculations list'),
};

// mock action subject
let actions: ActionsSubject;

// mock effects
let effects: BalanceCalculationsEffects;

describe('Balance Calculations Effects Test',()=> {
    beforeEach(()=>{
        actions = new ActionsSubject();
    });
    // get balance calculations list info success response
    it('getBalanceCalculationDetails$ - should be excuted if success response', ()=>{
        effects = new BalanceCalculationsEffects(balanceCalculationsSuccess as any,actions);
        effects.getBalanceCalculationDetails$.subscribe((response: any)=>{
            expect(response).toEqual(BalanceCalculationsActions.getBalanceCalculationsSuccess({ response: {} as any }));
        });
        // dispatch the action method
        const action = BalanceCalculationsActions.getBalanceCalculations({ request:{} as any });
        actions.next(action);
    });

    // get balance calculations accounts list info failure response
    it('getAssociatedAccountsDetails$ - should be excuted if failure response', ()=>{
        effects = new BalanceCalculationsEffects(balanceCalculationsFailureMock as any,actions);
        effects.getBalanceCalculationDetails$.subscribe((failure: any)=>{
            expect(failure).toEqual(BalanceCalculationsActions.getBalanceCalculationsFailure({ error:{} as Error }));
        });
        // dispatch the action method
        const action = BalanceCalculationsActions.getBalanceCalculations({ request:{} as any });
        actions.next(action);
    });

});
