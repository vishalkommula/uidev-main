import { createFeatureSelector, createSelector } from '@ngrx/store';
import { BalanceCalculationsEnum } from '../../models/balancecalculations.enum';
import { BalanceCalculationsState } from '../state/balancecalculations.state';




export const selectBalanceCalculationsRoot = createFeatureSelector<BalanceCalculationsState>('balanceCalculations');

export const selectBalanceCalculationsDetails = createSelector(selectBalanceCalculationsRoot, (state: BalanceCalculationsState)=>state.balanceCalculationsResponse.acctBalInqRecArray);
export const selectBalanceCalculationsDetailsResponse = createSelector(selectBalanceCalculationsRoot, (state: BalanceCalculationsState)=>state.balanceCalculationsResponse);

// select balance only data selector
export const selectBalanceOnlyAvailableBalanceDataDetails = createSelector(selectBalanceCalculationsRoot, (state: BalanceCalculationsState)=> {
    const balanceOnlyData = state.balanceCalculationsResponse.acctBalInqRecArray;
    if(balanceOnlyData !== null && balanceOnlyData !== undefined && balanceOnlyData.length > 1){
        return balanceOnlyData.filter((data)=> (((data.debits !== 0 || data.credits !== 0 || data.balance !== 0) &&
                                                 (data.isCreditIncluded || data.isDebitIncluded) ||
                                                 (data.activityType === BalanceCalculationsEnum.availableBalance ||
                                                 data.activityType === BalanceCalculationsEnum.collectedBalance ||
                                                 data.activityType === BalanceCalculationsEnum.ledgerBalance))&&
                                                 data.category  === BalanceCalculationsEnum.availableBalance));
    };
    return [];
});

// select balance only data selector
export const selectBalanceOnlyCollectedBalanceDataDetails = createSelector(selectBalanceCalculationsRoot, (state: BalanceCalculationsState)=> {
    const balanceOnlyData = state.balanceCalculationsResponse.acctBalInqRecArray;
    if(balanceOnlyData !== null && balanceOnlyData !== undefined && balanceOnlyData.length > 1){
        return balanceOnlyData.filter((data)=> (((data.debits !== 0 || data.credits !== 0 || data.balance !== 0) &&
                                                 (data.isCreditIncluded || data.isDebitIncluded) ||
                                                 (data.activityType === BalanceCalculationsEnum.availableBalance ||
                                                 data.activityType === BalanceCalculationsEnum.collectedBalance ||
                                                 data.activityType === BalanceCalculationsEnum.ledgerBalance))&&
                                                 data.category  === BalanceCalculationsEnum.collectedBalance));
    };
    return [];
});

// select balance only data selector
export const selectBalanceOnlyLedgerBalanceDataDetails = createSelector(selectBalanceCalculationsRoot, (state: BalanceCalculationsState)=> {
    const balanceOnlyData = state.balanceCalculationsResponse.acctBalInqRecArray;
    if(balanceOnlyData !== null && balanceOnlyData !== undefined && balanceOnlyData.length > 1){
        return balanceOnlyData.filter((data)=> (((data.debits !== 0 || data.credits !== 0 || data.balance !== 0) &&
                                                 (data.isCreditIncluded || data.isDebitIncluded) ||
                                                 (data.activityType === BalanceCalculationsEnum.availableBalance ||
                                                 data.activityType === BalanceCalculationsEnum.collectedBalance ||
                                                 data.activityType === BalanceCalculationsEnum.ledgerBalance))&&
                                                 data.category  === BalanceCalculationsEnum.ledgerBalance));
    };
    return [];
});

export const selectBalanceCalculationsAvailableBalanceDetails = createSelector(selectBalanceCalculationsRoot ,(state: BalanceCalculationsState)=>{
    const availableBalanceData = state.balanceCalculationsResponse.acctBalInqRecArray;
    if(availableBalanceData !==null && availableBalanceData !== undefined){
        const availableBalance = availableBalanceData.filter((data)=>  data.category  === BalanceCalculationsEnum.availableBalance);
        return availableBalance;
    }
    return [];
});

export const selectBalanceCalculationsCollectedBalanceDetails = createSelector(selectBalanceCalculationsRoot ,(state: BalanceCalculationsState)=>{
    const collectedBalancData = state.balanceCalculationsResponse.acctBalInqRecArray;
    if(collectedBalancData !==null && collectedBalancData !== undefined){
        const collectedBalance = collectedBalancData.filter((data)=>  data.category  === BalanceCalculationsEnum.collectedBalance);
        return collectedBalance;

    }
    return [];
});
export const selectBalanceCalculationsLedgerBalanceDetails = createSelector(selectBalanceCalculationsRoot ,(state: BalanceCalculationsState)=>{
    const ledgerBalanceData = state.balanceCalculationsResponse.acctBalInqRecArray;
    if(ledgerBalanceData !==null && ledgerBalanceData !== undefined){
        const ledgerBalance = ledgerBalanceData.filter((data)=>  data.category  === BalanceCalculationsEnum.ledgerBalance);
        return ledgerBalance;
    }return [];
});

export const selectAvailableBalance = createSelector(selectBalanceCalculationsRoot , (state: BalanceCalculationsState) =>{
    const availableBalance = state.balanceCalculationsResponse.availableBalance;
    return availableBalance;
});
export const selectCollectedBalance = createSelector(selectBalanceCalculationsRoot , (state: BalanceCalculationsState) =>{
    const collectedBalance = state.balanceCalculationsResponse.collectedBalance;
    return collectedBalance;
});export const selectLedgerBalance = createSelector(selectBalanceCalculationsRoot , (state: BalanceCalculationsState) =>{
    const ledgerBalance = state.balanceCalculationsResponse.ledgerBalance;
    return ledgerBalance;
});
