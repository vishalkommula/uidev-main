import { SearchResponseHeaderModel, ViewParameterModel } from '@uid/uid-models';
import { BalanceCalulationBalanceModel } from './balancecalculation-balance.model';
import { AcctBalInqRecItemModel } from './balancecalculations-item.model';


export interface AcctBalInqResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    acctId: string;
    acctType: string;
    acctBalInqRecArray: AcctBalInqRecItemModel[];
    availableBalance: BalanceCalulationBalanceModel;
    collectedBalance: BalanceCalulationBalanceModel;
    ledgerBalance: BalanceCalulationBalanceModel;
    viewParameter: ViewParameterModel;
};
