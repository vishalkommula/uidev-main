import { Injectable } from '@angular/core';
import { CellClassParams, ColDef, GridOptions, ICellRendererParams, ValueGetterParams, ITooltipParams } from 'ag-grid-community';
import { TooltipRendererComponent,AgGridHyperlinkCellRendererComponent,AmountRendererComponent } from '@uid/uid-grid';



@Injectable({ providedIn: 'root' })
export class BalanceCalculationsGridService {
    displayTotal !: boolean;

    public tooltipShowDelay = 0;
    public tooltipHideDelay = 2000;

    public hyperLinkActivityType: string[] = [
        'Float',
        'Holds',
        'Overdraft Protection',
        'Bounce Protection',
        'OD Limit Code',
        'Sweep Balances',
        'Memo Posted',
        'ACH',
        'POD',
        'ATM',
        'Teller',
        'Investment Funds'
    ];

    public defaultColDef: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public autoGroupColumnDef: ColDef = {
        headerName: 'Category',
        minWidth: 210,
        filter: true,
        sortable: true,
    };

    public balanceCalculationGridOptions: GridOptions = {
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        suppressRowClickSelection:true,
        suppressAggFuncInHeader: true,
        groupDefaultExpanded : -1,
        sideBar:false,
        defaultColDef:this.defaultColDef,
        autoGroupColumnDef:this.autoGroupColumnDef,
        groupIncludeTotalFooter:true,
        tooltipShowDelay: this.tooltipShowDelay,
        tooltipHideDelay: this.tooltipHideDelay
    };

    public balanceCalculationsColDef(productIsSupported: boolean): ColDef[]{
        // this.displayTotal = productIsSupported;
        return [
            {
                field: 'category',
                headerName: 'Category',
                filter: true,
                hide: true,
                suppressColumnsToolPanel: true,
                suppressFiltersToolPanel: productIsSupported ? false : true,
            },
            {
                field: 'activityType',
                headerName: 'Activity',
                filter: 'agTextColumnFilter',
                sortable: true,
                cellRendererSelector: (params) => this.hyperLinkCellRenderer(params),
                cellClass: 'ag-left-aligned-cell',
                aggFunc: productIsSupported ? '' : 'total',
            },
            {
                field: 'debits',
                headerName: 'Debits',
                filter: 'agNumberColumnFilter',
                cellRendererSelector: (params) => ({
                    component: AmountRendererComponent,
                }),
                tooltipComponent: TooltipRendererComponent,
                tooltipValueGetter:this.tooltipValueRenderer,
                cellClass: 'ag-right-aligned-cell',
                cellRendererParams: {
                    amountFormatterParams : {   displayAsNegativeNumber: true }
                },
                cellStyle: this.isIncludedValuesItalic,
                aggFunc: 'sum'
            },
            {
                field: 'credits',
                headerName: 'Credits',
                filter: 'agNumberColumnFilter',
                cellRendererSelector: (params) => ({
                    component: AmountRendererComponent,
                }),
                tooltipComponent: TooltipRendererComponent,
                tooltipValueGetter: this.tooltipValueRenderer,
                cellClass: 'ag-right-aligned-cell',
                cellStyle: this.isIncludedValuesItalic,
                aggFunc: 'sum',


            },
            {
                field: 'balance',
                headerName: 'Balance',
                sortable: true,
                filter: 'agNumberColumnFilter',
                tooltipComponent: TooltipRendererComponent,
                tooltipValueGetter: this.tooltipValueRenderer,
                cellRendererSelector: (params) => ({
                    component: AmountRendererComponent,
                }),
                aggFunc: 'sum',
                cellClass: 'ag-right-aligned-cell',

            },

        ];
    }

    isIncludedValuesItalic(params: CellClassParams) {
        if (params.value && !params.node.group) {
            if ((params.data.isDebitIncluded === false && params.data.debits !== 0) || (params.data.isCreditIncluded === false && params.data.credits !== 0)) {
                return { fontStyle: 'italic', };
            }
        }
        return null;
    }

    hyperLinkCellRenderer(params: ICellRendererParams){
        if(params.value && !params.node.group){
            if(this.hyperLinkActivityType.includes(params.data.activityType)){
                return {
                    component: AgGridHyperlinkCellRendererComponent,
                };
            }
        }
        return{
            component: null
        };
    }

    tooltipValueRenderer(params: ITooltipParams){
        if (params.value) {
            if ((params.data?.isDebitIncluded === false && params.data.debits !== 0) || (params.data?.isCreditIncluded === false && params.data?.credits !== 0)) {
                return {
                    toolTipValue:'Value is not included in total' ,
                };
            }
        }return null;
    }

}
