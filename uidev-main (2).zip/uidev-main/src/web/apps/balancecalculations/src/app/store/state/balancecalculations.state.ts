import { AcctBalInqResponse } from '../../models/balancecalculations-response.model';


export interface BalanceCalculationsState{
    balanceCalculationsResponse: AcctBalInqResponse;
}
