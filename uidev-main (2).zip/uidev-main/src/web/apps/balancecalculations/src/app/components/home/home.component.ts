import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';

// Ag grid
import { ColumnApi, GridReadyEvent, GridSizeChangedEvent, ColDef, GridApi, GridOptions } from 'ag-grid-community';

// NGRX
import { Store } from '@ngrx/store';
import { Observable, of, Subscription } from 'rxjs';
import * as BalanceCalculationsActions from '../../store/actions/balancecalculations.action';
import * as BalanceCalculationsSelector from '../../store/selectors/balancecalculations.selector';

// Models
import { BalanceCalculationsGridService } from './balancecalculations-grid.def';
import { AcctBalInqRecItemModel } from '../../models/balancecalculations-item.model';
import { AcctBalInqResponse } from '../../models/balancecalculations-response.model';
import { isElementSupported, unsubscribe } from '@uid/uid-utilities';
import { BalanceCalulationBalanceModel } from '../../models/balancecalculation-balance.model';

//UID
import { UidAggridComponent } from '@uid/uid-grid';

@Component({
    selector: 'uid-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {

  @ViewChild(UidAggridComponent) uidAggrid!: UidAggridComponent;

  public colDefs!: ColDef[];
  public defaultColDefs!: ColDef;
  public gridOptions!: GridOptions;


  availableBalanceGridApi: GridApi = {} as GridApi;
  collectedBalanceGridApi: GridApi = {} as GridApi;
  ledgerBalanceGridApi: GridApi = {} as GridApi;

  availableBalancegridColumnApi!: ColumnApi;
  collectedBalanceGridColumnApi!: ColumnApi;
  ledgerBalanceGridColumnApi!: ColumnApi;

  availableBalance$: Observable<BalanceCalulationBalanceModel> = of();
  collectedBalance$: Observable<BalanceCalulationBalanceModel> = of();
  ledgerBalance$: Observable<BalanceCalulationBalanceModel> = of();

  balanceCalculationsActions = BalanceCalculationsActions;
  balanceCalculationsSelector = BalanceCalculationsSelector;
  balanceCalculationsDetails$: Observable<AcctBalInqRecItemModel[]> = of();
  balanceCalculationAvailableBalanceDetails$: Observable<AcctBalInqRecItemModel[]> = of();
  balanceCalculationCollectedBalanceDetails$: Observable<AcctBalInqRecItemModel[]> = of();
  balanceCalculationLedgerBalanceDetails$: Observable<AcctBalInqRecItemModel[]> = of();
  balanceCalculationsDetailsResponse$: Observable<AcctBalInqResponse> = of();
  balanceOnlyStatus = true;
  groupIncludeTotalFooter = true;
  displayCategory!: boolean;
  public subs: Subscription[] = [];
  public savedColumnState: any;
  availableBalanceGroupBoxExpanded = false;
  collectedBalanceGroupBoxExpanded = false;
  ledgerBalanceGroupBoxExpanded = false;

  public availableBalanceGridoptions: GridOptions = {
      onGridReady: (event) => this.availableBalanceOnGridReady(event),
  };
  public collectedBalanceGridoptions: GridOptions = {
      onGridReady: (event) => this.collectedBalanceOnGridReady(event),
  };
  public ledgerBalanceGridoptions: GridOptions = {
      onGridReady: (event) => this.ledgerBalanceonGridReady(event),
  };

  constructor(private store: Store, private gridDef: BalanceCalculationsGridService) {
      this.balanceCalculationAvailableBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceOnlyAvailableBalanceDataDetails);
      this.balanceCalculationCollectedBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceOnlyCollectedBalanceDataDetails);
      this.balanceCalculationLedgerBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceOnlyLedgerBalanceDataDetails);
      this.availableBalance$ = this.store.select(this.balanceCalculationsSelector.selectAvailableBalance);
      this.collectedBalance$ = this.store.select(this.balanceCalculationsSelector.selectCollectedBalance);
      this.ledgerBalance$ = this.store.select(this.balanceCalculationsSelector.selectLedgerBalance);
  }

  ngOnInit(): void {
      this.store.dispatch(this.balanceCalculationsActions.getBalanceCalculations({ request: {} as any }));
      const balanceCalculationSub = this.balanceCalculationsDetailsResponse$.subscribe((res) => {
          const id = 'category';
          this.displayCategory = isElementSupported(id, res.viewParameter);
          console.log(this.displayCategory);
          if (this.displayCategory) {
              this.groupIncludeTotalFooter = false;
          } else {
              this.groupIncludeTotalFooter = true;
          }
      });
      this.colDefs = this.gridDef.balanceCalculationsColDef(this.displayCategory);
      this.subs.push(balanceCalculationSub);
      this.availableBalanceGridoptions = { ...this.availableBalanceGridoptions, ...this.gridDef.balanceCalculationGridOptions };
      this.collectedBalanceGridoptions = { ...this.collectedBalanceGridoptions, ...this.gridDef.balanceCalculationGridOptions };
      this.ledgerBalanceGridoptions = { ...this.ledgerBalanceGridoptions, ...this.gridDef.balanceCalculationGridOptions };
  }

  availableBalanceOnGridReady(event: GridReadyEvent) {
      this.availableBalanceGridApi = event.api;
      this.availableBalanceGridApi?.setColumnDefs(this.colDefs);
  }

  collectedBalanceOnGridReady(event: GridReadyEvent) {
      this.collectedBalanceGridApi = event.api;
      this.collectedBalanceGridApi?.setColumnDefs(this.colDefs);
  }

  ledgerBalanceonGridReady(event: GridReadyEvent) {
      this.ledgerBalanceGridApi = event.api;
      this.ledgerBalanceGridApi?.setColumnDefs(this.colDefs);
  }


  balanceOnly() {
      if (this.balanceOnlyStatus) {
          this.balanceOnlyStatus = false;
          this.balanceCalculationAvailableBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceCalculationsAvailableBalanceDetails);
          this.balanceCalculationCollectedBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceCalculationsCollectedBalanceDetails);
          this.balanceCalculationLedgerBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceCalculationsLedgerBalanceDetails);
      } else {
          this.balanceOnlyStatus = true;
          this.balanceCalculationAvailableBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceOnlyAvailableBalanceDataDetails);
          this.balanceCalculationCollectedBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceOnlyCollectedBalanceDataDetails);
          this.balanceCalculationLedgerBalanceDetails$ = this.store.select(this.balanceCalculationsSelector.selectBalanceOnlyLedgerBalanceDataDetails);
      }
  }



  ngOnDestroy(): void {
      unsubscribe(this.subs);
  }
}
