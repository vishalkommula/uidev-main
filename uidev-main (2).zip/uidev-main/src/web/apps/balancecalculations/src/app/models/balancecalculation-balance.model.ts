export interface BalanceCalulationBalanceModel{
    category?: string;
    activityType?: string;
    balance?: number;
};
