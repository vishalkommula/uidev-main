import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface AcctBalInqRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    acctType: string;
};
