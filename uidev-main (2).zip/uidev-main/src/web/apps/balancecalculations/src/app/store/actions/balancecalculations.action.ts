import { createAction, props } from '@ngrx/store';
import { AcctBalInqRequest } from '../../models/balancecalculations-request.model';
import { AcctBalInqResponse } from '../../models/balancecalculations-response.model';


// BalanceCalculation details request action
export const getBalanceCalculations = createAction('[Balancen Calculation] get data request', props<{ request: AcctBalInqRequest }>());

// BalanceCalculation details action success response
export const getBalanceCalculationsSuccess = createAction('[Balance Calculation] get success response', props<{ response: AcctBalInqResponse }>());

// BalanceCalculation details action error response
export const getBalanceCalculationsFailure = createAction('[Balance Calculation] get failed response', props<{ error: Error }>());
