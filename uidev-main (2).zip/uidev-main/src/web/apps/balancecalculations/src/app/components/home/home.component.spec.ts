import { ComponentFixture } from '@angular/core/testing';

import { HomeComponent } from './home.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { of } from 'rxjs';
import { AcctBalInqResponse } from '../../models/balancecalculations-response.model';
import { AcctBalInqRequest } from '../../models/balancecalculations-request.model';
import { isElementSupported, unsubscribe } from '@uid/uid-utilities';

let component: HomeComponent;

const balanceCalculationsActionsMock = {
    getBalanceCalculations: jest.fn(),
};
const balanceCalculationsSelectorMock = {
    balanceCalculationsDetails: jest.fn(),
    balanceCalculationsDetailsResponse: jest.fn(),
    selectBalanceOnlyDataDetails: jest.fn()
};
const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() => ({
        subscribe: jest.fn(),
    })),
};
const gridDef = {
    balanceCalculationsColDef: jest.fn()
};

describe('HomeComponent', () => {

    beforeEach(() => {
        component = new HomeComponent(storeMock as any, gridDef as any);
        component.balanceCalculationsActions = balanceCalculationsActionsMock as any;
        component.balanceCalculationsSelector = balanceCalculationsSelectorMock as any;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('silverlake data should be fetched on oninit when IsSupported is true', () => {
        component.balanceCalculationsDetailsResponse$ = of({
            srchMsgRsHdr: {} as any,
            acctId: '8000',
            acctType: 'S',
            availableBalance: {
                category: '',
                activityType: '',
                balance: 0
            },
            collectedBalance: {
                category: '',
                activityType: '',
                balance: 0
            },
            ledgerBalance: {
                category: '',
                activityType: '',
                balance: 0
            },
            acctBalInqRecArray: [],
            viewParameter: {
                viewName: 'balance calculations',
                parameters: [
                    {
                        name: 'category',
                        isSupported: true,
                        attributes: {
                            isHidden: false,
                            otherValue: 'no'
                        }
                    }
                ],
            }
        });
        component.ngOnInit();
        component.balanceCalculationsDetailsResponse$.subscribe((res: AcctBalInqResponse) => {
            const id = 'category';
            component.displayCategory = isElementSupported(id, res.viewParameter);
            component.colDefs = gridDef.balanceCalculationsColDef(component.displayCategory);
            component.groupIncludeTotalFooter = false;
            expect(component.colDefs).toEqual(gridDef.balanceCalculationsColDef(component.displayCategory));
        });
    });

    it('cif data should be fetched on oninit when IsSupported is false', () => {
        component.balanceCalculationsDetailsResponse$ = of({
            srchMsgRsHdr: {} as any,
            acctId: '8000',
            acctType: 'S',
            availableBalance: {
                category: '',
                activityType: '',
                balance: 0
            },
            collectedBalance: {
                category: '',
                activityType: '',
                balance: 0
            },
            ledgerBalance: {
                category: '',
                activityType: '',
                balance: 0
            },
            acctBalInqRecArray: [],
            viewParameter: {
                viewName: 'balance calculations',
                parameters: [
                    {
                        name: 'category',
                        isSupported: false,
                        attributes: {
                            isHidden: true,
                            otherValue: 'no'
                        }
                    }
                ],
            }
        });
        component.ngOnInit();
        component.balanceCalculationsDetailsResponse$.subscribe((res: AcctBalInqResponse) => {
            const id = 'category';
            component.displayCategory = isElementSupported(id, res.viewParameter);
            component.colDefs = gridDef.balanceCalculationsColDef(component.displayCategory);
            component.groupIncludeTotalFooter = true;
            expect(component.colDefs).toEqual(gridDef.balanceCalculationsColDef(component.displayCategory));
        });
    });

    it('availableBalanceonGridReady method - should be executed', () => {
        component.availableBalanceGridApi = {
            closeToolPanel: jest.fn(),
            sizeColumnsToFit: jest.fn(),
            expandAll: jest.fn(),
            getRowNode: jest.fn(),
            setColumnDefs: jest.fn()
        } as any;
        const event = {
            api: {
                closeToolPanel: jest.fn(),
                sizeColumnsToFit: jest.fn(),
                expandAll: jest.fn(),
                getRowNode: jest.fn(),
                setColumnDefs: jest.fn()
            },
        };

        component.availableBalanceOnGridReady({} as any);
        expect(event.api.setColumnDefs).toBeTruthy();
    });
    it('collectedBalanceonGridReady method - should be executed', () => {
        component.collectedBalanceGridApi = {
            closeToolPanel: jest.fn(),
            sizeColumnsToFit: jest.fn(),
            expandAll: jest.fn(),
            getRowNode: jest.fn(),
            setColumnDefs: jest.fn()
        } as any;
        const event = {
            api: {
                closeToolPanel: jest.fn(),
                sizeColumnsToFit: jest.fn(),
                expandAll: jest.fn(),
                getRowNode: jest.fn(),
                setColumnDefs: jest.fn()
            },
        };

        component.collectedBalanceOnGridReady({} as any);
        expect(event.api.setColumnDefs).toBeTruthy();
    });
    it('ledgerBalanceonGridReady method - should be executed', () => {
        component.ledgerBalanceGridApi = {
            closeToolPanel: jest.fn(),
            sizeColumnsToFit: jest.fn(),
            expandAll: jest.fn(),
            getRowNode: jest.fn(),
            setColumnDefs: jest.fn()
        } as any;
        const event = {
            api: {
                closeToolPanel: jest.fn(),
                sizeColumnsToFit: jest.fn(),
                expandAll: jest.fn(),
                getRowNode: jest.fn(),
                setColumnDefs: jest.fn()
            },
        };

        component.ledgerBalanceonGridReady({} as any);
        expect(event.api.setColumnDefs).toBeTruthy();
    });

    it('balanceOnlyStatus method - should be excuted if balanceOnlyStatus true', () => {
        component.balanceOnlyStatus = true;
        component.balanceOnly();
        expect(component.balanceOnlyStatus).toEqual(false);
    });

    it('balanceOnlyStatus method - should be excuted if balanceOnlyStatus false', () => {
        component.balanceOnlyStatus = false;
        component.balanceOnly();
        expect(component.balanceOnlyStatus).toEqual(true);
    });

    it('ngOnDestroy() method should be execute', () => {
        component.subs = [of([1, 2, 3]).subscribe()] as any;
        component.ngOnDestroy();
        unsubscribe(component.subs);
        expect(component.subs).toBeTruthy();
    });
});
