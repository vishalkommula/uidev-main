import { AgGridHyperlinkCellRendererComponent } from '@uid/uid-grid';
import { BalanceCalculationsGridService } from './balancecalculations-grid.def';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());



let service: BalanceCalculationsGridService;

describe('BalanceCalculationsGridService', () => {

    beforeEach(() => {
        service = new BalanceCalculationsGridService();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should be created balanceCalculationsColDef', () => {
        expect(service.balanceCalculationsColDef).toBeTruthy();
    });
    it('isIncludedValuesItalic method - should be executed with italic', () => {
        const params = { value: 6565,
            node :{
                group: false
            },
            data: {
                isCreditIncluded: false,
                credits:150,
                isDebitIncluded: false,
                debits:100
            } };
        const res =  service.isIncludedValuesItalic(params as any);
        params.value = 6565;
        params.node.group = true;
        params.data.isCreditIncluded = false;
        params.data.credits = 150;
        params.data.isDebitIncluded = false;
        params.data.debits = 100;
        const val = { 'fontStyle': 'italic' };
        expect(res).toEqual(val);
    });

    it('isIncludedValuesItalic method - should be executed with italic', () => {
        const params = { value: 0,
            node :{
                group: false
            },
            data: {
                isCreditIncluded: true,
                credits:0,
                isDebitIncluded: true,
                debits:0
            } };
        const res =  service.isIncludedValuesItalic(params as any);
        params.value = 6565;
        params.node.group = false;
        params.data.isCreditIncluded = true;
        params.data.credits = 0;
        params.data.isDebitIncluded = true;
        params.data.debits = 0;
        const val = null;
        expect(res).toEqual(val);
    });

    it('hyperLinkCellRenderer method - should be executed with clickable', () => {
        const params = { value: 6565,
            node :{
                group: false
            },
            data:{
                activityType:'Memo Posted'
            }
        };
        const res =  service.hyperLinkCellRenderer(params as any);
        params.value = 6565;
        params.node.group = true;
        const val = { 'component': AgGridHyperlinkCellRendererComponent };
        expect(res).toEqual(val);
    });

    it('hyperLinkCellRenderer method - should be executed without clickable', () => {
        const params = { value: 6565,
            node :{
                group: true
            } };
        const res =  service.hyperLinkCellRenderer(params as any);
        params.value = 6565;
        params.node.group = true;
        const val = { 'component': null };
        expect(res).toEqual(val);
    });
    it('tooltipValueRenderer method - should be executed and return null', () => {
        const params = { value: 6565,
            node :{
                group: true
            } ,
            data:{
                isDebitIncluded : true,
                debits:0,
                isCreditIncluded: true,
                credits:0
            }
        };
        const res =  service.tooltipValueRenderer(params as any);
        params.value = 6565;
        params.node.group = true;
        const val = null;
        expect(res).toEqual(val);
    });

    it('tooltipValueRenderer method - should be executed and return tooltip message', () => {
        const params = { value: 6565,
            node :{
                group: true
            } ,
            data:{
                isDebitIncluded : false,
                debits:23,
                isCreditIncluded: false,
                credits:45
            }
        };
        const res =  service.tooltipValueRenderer(params as any);
        params.value = 6565;
        params.node.group = true;
        params.data.isDebitIncluded= false;
        params.data.debits = 90;
        params.data.credits=23;
        params.data.isCreditIncluded = false;
        const val = { toolTipValue:'Value is not included in total' };
        expect(res).toEqual(val);
    });
});
