import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { DataService } from '../../service/data.service';
import  * as balanceCalculationAction from '../actions/balancecalculations.action';
@Injectable()
export class BalanceCalculationsEffects{
    constructor(private dataService: DataService, private action$: Actions){}

    getBalanceCalculationDetails$ = createEffect(() => this.action$.pipe(
        ofType(balanceCalculationAction.getBalanceCalculations),
        switchMap((action) =>
            this.dataService.getBalanceCalculationDetails(action.request)
                .pipe(
                    map((response) => balanceCalculationAction.getBalanceCalculationsSuccess({ response })),
                    catchError((error)=> of(balanceCalculationAction.getBalanceCalculationsFailure({ error })))
                )
        )
    ));

}
