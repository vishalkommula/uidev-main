import { DataService } from './data.service';

describe('DataService', () => {
    let service: DataService;

    beforeEach(() => {
        service = new DataService();
    });
    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('getBalanceCalculationDetails method - should be executed this is silverLakeResponse', async () => {
        const request: any = {
            srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
            acctId: '12',
            acctType: 'A',
        };
        const actualValue = service.getBalanceCalculationDetails(request as any);
        service.secondaryProductIsSupported = false;
        expect(await actualValue.toPromise()).toBeTruthy();
    });
    it('getBalanceCalculationDetails method - should be executed this is cifResponse', async () => {
        const request: any = {
            srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
            acctId: '12',
            acctType: 'A',
        };
        service.secondaryProductIsSupported = true;
        const actualValue = service.getBalanceCalculationDetails(request as any);
        expect(await actualValue.toPromise()).toBeTruthy();
    });
});
