export interface AcctBalInqRecItemModel{
    category?: string;
    activityType?: string;
    credits?: number;
    debits?: number;
    balance?: number;
    isCreditIncluded?: boolean;
    isDebitIncluded?: boolean;
};

