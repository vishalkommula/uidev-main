import { createReducer, on } from '@ngrx/store';
import { AcctBalInqResponse } from '../../models/balancecalculations-response.model';
import * as balanceCalculationsActions from '../actions/balancecalculations.action';
import { BalanceCalculationsState } from '../state/balancecalculations.state';



export const initialBalanceCalculationsState: BalanceCalculationsState = {
    // balance calculation state
    balanceCalculationsResponse: {} as AcctBalInqResponse
};

export const balanceCalculationsReducer = createReducer(
    initialBalanceCalculationsState,

    //   balance calculations reducer
    on(
        balanceCalculationsActions.getBalanceCalculationsSuccess,
        (state, action): BalanceCalculationsState => ({
            ...state,
            balanceCalculationsResponse:action.response
        })
    ),

);
