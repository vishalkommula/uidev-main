import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { AcctBalInqRequest } from '../models/balancecalculations-request.model';
import { AcctBalInqResponse } from '../models/balancecalculations-response.model';
import  AccountBalInquirySilverLakeMockData from '../mock-data/balancecalculations.silverlake.mock.json';
import  AccountBalInquirCifMockData from '../mock-data/balancecalculations.cif.mock.json';
@Injectable({
    providedIn: 'root'
})
export class DataService {

    constructor() { }
    public secondaryProductIsSupported = false;
    getBalanceCalculationDetails(request: AcctBalInqRequest): Observable<AcctBalInqResponse>{
        if(this.secondaryProductIsSupported === false){
            const silverLakeResponse = JSON.parse(JSON.stringify(AccountBalInquirySilverLakeMockData));
            return of(silverLakeResponse);
        } else{
            const cifResponse = JSON.parse(JSON.stringify(AccountBalInquirCifMockData));
            return of(cifResponse);
        }
    }
}
