
import * as BalanceCalculationsActions  from '../actions/balancecalculations.action';
import { balanceCalculationsReducer, initialBalanceCalculationsState } from './balancecalculations.reducer';


const expectedState = {
    balanceCalculationsResponse :{} as any,
};

const responseData = { data: 'data' };

describe('Balance Calculations Reducers test', () => {

    it('getBalanceCalculationsSuccess - should be executed',()=>{
        const newState = initialBalanceCalculationsState;
        const state = balanceCalculationsReducer(newState, BalanceCalculationsActions.getBalanceCalculationsSuccess({ response: responseData as any }));
        expectedState.balanceCalculationsResponse = responseData;
        expect(state).toEqual(expectedState);
    });
});
