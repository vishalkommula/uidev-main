import { NgModule ,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { RouterModule, Routes } from '@angular/router';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';

// Ag-grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';

// shared libs
import { UidPrimaryDetailModule } from '@uid/uid-primary-detail';
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';
import { UidAggridModule } from '@uid/uid-grid';


const routes: Routes = [{ path: '', component: HomeComponent }];

@NgModule({
    declarations: [HomeComponent],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        AgGridModule,
        UidAggridModule,
        UidAngularControlsModule,
        UidPrimaryDetailModule,
        UidDirectivesModule,
        UidPipesModule,
        ReactiveComponentModule
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    providers:[]
})
export class HomeModule { }
