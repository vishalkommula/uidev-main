import { Component } from '@angular/core';

@Component({
    selector: 'uid-root',
    template: '<router-outlet></router-outlet>',
})
export class AppComponent {}
