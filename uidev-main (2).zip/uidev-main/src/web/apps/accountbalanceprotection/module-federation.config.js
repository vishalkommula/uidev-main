module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'accountbalanceprotection',
    exposes: {
        './Module': 'apps/accountbalanceprotection/src/app/components/home/home.module.ts',
    },
};
