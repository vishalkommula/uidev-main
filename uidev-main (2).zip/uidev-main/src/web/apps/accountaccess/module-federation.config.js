module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'accountaccess',
    exposes: {
        './Module': 'apps/accountaccess/src/app/components/home/home.module.ts',
    },
};
