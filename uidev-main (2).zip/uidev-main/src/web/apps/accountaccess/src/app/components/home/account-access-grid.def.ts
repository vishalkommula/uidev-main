import { Injectable } from '@angular/core';
import { ColDef, GridOptions, SideBarDef } from 'ag-grid-community';
import { AgGridHyperlinkCellRendererComponent, AmountRendererComponent, ButtonRendererClickParms,
    ButtonRendererComponent, ButtonRendererModel } from '@uid/uid-grid';
import { AccountTypesIcons } from '@uid/uid-models';

@Injectable({ providedIn: 'root' })
export class AccountAccessGridColDef {
    public buttonRendererList: ButtonRendererModel[] = [
        {
            iconType: 'preview',
            onClick: this.onPreview.bind(this)
        }
    ];

    public default: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public columns: ColDef[] = [
        {
            field: 'accessAlw',
            headerName: 'Access Allowed',
            rowGroup: true,
            hide: true,
            suppressFiltersToolPanel: true
        },
        {
            field: 'acctId',
            headerName: 'Account',
            filter: 'agTextColumnFilter',
            cellRendererSelector: (params) => ({
                component: AgGridHyperlinkCellRendererComponent,
                params: { iconType: params.node.group ? '' : this.getAccountTypeEnumValue(params.data.acctType), iconContext: 'secondary-btn' },
            }),
        },
        {
            field: 'stmtRetrvAnlysId',
            headerName: 'DDA Stmt Analysis Count',
            hide:true
        },
        {
            field: 'stmtRetrvFeeAmt',
            headerName: 'DDA Stmt Hard Charge',
            cellRenderer : AmountRendererComponent,
            hide:true
        },
        {
            field: 'acctElecDocType',
            headerName: 'E-Statement',
            hide:true
        },
        {
            field: 'feeChgStmtType',
            headerName: 'Hard Charge at Stmt',
            hide:true
        },
        {
            field: 'lnPmtAlw',
            headerName: 'Loan Payments',
            hide:true
        },
        {
            field: 'prodDesc',
            headerName: 'Product',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'aliasAcctName',
            headerName: 'Pseudo Name',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'acctRelDesc',
            headerName: 'Relationship',
        },
        {
            field: 'rmk',
            headerName: 'Remarks',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'stopPmtAddFeeAmt',
            headerName: 'Stop Hard Charge',
            cellRenderer : AmountRendererComponent,
            hide:true
        },
        {
            field: 'stopPmtAddAnlysId',
            headerName: 'Stop Pay Anaysis Count',
            hide:true
        },
        {
            field: 'xferFromAnlysId',
            headerName: 'Transfer From Analysis Count',
            hide:true
        },
        {
            field: 'xferFromFeeAmt',
            headerName: ' Transfer From Hard Charge',
            cellRenderer : AmountRendererComponent,
            hide:true
        },
        {
            field: 'actionButtons',
            headerName: '',
            sortable: false,
            filter: false,
            hide: true,
            pinned: 'right',
            cellRendererSelector: (params) => ({
                component: ButtonRendererComponent,
                params: { buttonList: params.node.group ? '' : this.buttonRendererList } ,
            }),
            suppressColumnsToolPanel: true,
            suppressFiltersToolPanel: true
        }
    ];

    public autoGroupColumnDef: ColDef = {
        headerName: 'Access Allowed',
        field: 'accessAlw',
    };

    public sideBar: SideBarDef = {
        toolPanels: [
            {
                id: 'columns',
                labelDefault: 'Columns',
                labelKey: 'columns',
                iconKey: 'columns',
                width:260,
                toolPanel: 'agColumnsToolPanel',
                toolPanelParams: {
                    suppressRowGroups: true,
                    suppressValues: true,
                    suppressPivots: true,
                    suppressPivotMode: true,
                },
            },
            'filters',
        ],
        defaultToolPanel: '',
    };
    public gridOptions: GridOptions = {
        columnDefs: this.columns,
        defaultColDef: this.default,
        autoGroupColumnDef: this.autoGroupColumnDef,
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        sideBar: this.sideBar
    };

    onPreview(event: ButtonRendererClickParms): void {
    }
    getAccountTypeEnumValue(enumString: any){
        const enumValue = (<any>AccountTypesIcons)[enumString];
        return enumValue === undefined ? '' : enumValue;
    }
}
