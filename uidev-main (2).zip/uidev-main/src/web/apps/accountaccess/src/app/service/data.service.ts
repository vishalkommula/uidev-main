import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IntnetFinInstIdInqRequestModel } from '../models/intnet-fin-inst-id-inq-request.model';
import { IntnetFinInstIdInqResponseModel } from '../models/intnet-fin-inst-id-inq-response.model';
import IntnetFinInstIdInqResponseMock from '../mock-data/intnet-fin-id-inq-response.mock.json';


@Injectable({
    providedIn: 'root'
})
export class DataService {

    constructor(private httpclient: HttpClient) { }

    getIntnetFinIdRecord(accountAccessCustInqReq: IntnetFinInstIdInqRequestModel): Observable<IntnetFinInstIdInqResponseModel> {
        const accountAccessCustInqResponse = JSON.parse(JSON.stringify(IntnetFinInstIdInqResponseMock)) as IntnetFinInstIdInqResponseModel;
        // set the defaut values for the fields
        if(accountAccessCustInqResponse.intnetAccessInfoRecord?.acctIdAccessArray !== undefined &&
      accountAccessCustInqResponse.intnetAccessInfoRecord.acctIdAccessArray.length >0){
            accountAccessCustInqResponse.intnetAccessInfoRecord.acctIdAccessArray.forEach((acc)=>{
                acc.stopPmtAddFeeAmt = acc.stopPmtAddFeeAmt === undefined ? 0 : acc.stopPmtAddFeeAmt;
                acc.xferFromFeeAmt = acc.xferFromFeeAmt === undefined ? 0 : acc.xferFromFeeAmt;
                acc.stmtRetrvFeeAmt = acc.stmtRetrvFeeAmt === undefined ? 0 : acc.stmtRetrvFeeAmt;
                acc.accessAlw = acc.accessAlw === 'Y' ? 'Yes' : 'No';
                acc.feeChgStmtType = acc.feeChgStmtType === 'Y' ? 'Yes' : 'No';
                acc.acctElecDocType = acc.acctElecDocType === 'Y' ? 'Yes' : 'No';
            });
        }
        return of(accountAccessCustInqResponse);
    }
}
