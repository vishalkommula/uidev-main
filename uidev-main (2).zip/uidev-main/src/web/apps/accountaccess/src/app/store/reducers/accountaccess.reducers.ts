import { createReducer, on } from '@ngrx/store';
import { AccIdAccessInfoRecItemModel } from '../../models/account-id-access-info-record-item.model';
import { IntnetFinInstIdInqResponseModel } from '../../models/intnet-fin-inst-id-inq-response.model';
import { AccountAccessState } from '../states/accountaccess.state';
import * as AccountAccessActions from '../actions/accountaccess.actions';

export const initialAccountAccessState: AccountAccessState = {
    intnetFinInstIdInqResponse: {} as IntnetFinInstIdInqResponseModel,
    acctIdAccessRecord: {} as AccIdAccessInfoRecItemModel,
};

export const accountAccessReducer = createReducer(
    initialAccountAccessState,

    on(AccountAccessActions.getIntnetAccessInfoRecordSuccess,(state,action): AccountAccessState => ({
        ...state,
        intnetFinInstIdInqResponse: action.intnetFinInstIdInqResponse,
    })),

    on(AccountAccessActions.updateCurrentSelectedRecord,(state,action): AccountAccessState => ({
        ...state,
        acctIdAccessRecord: action.currentRecord,
    }))
);
