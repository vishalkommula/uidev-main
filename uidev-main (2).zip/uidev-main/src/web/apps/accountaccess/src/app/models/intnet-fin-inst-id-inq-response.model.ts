import { SearchResponseHeaderModel } from '@uid/uid-models';
import { IntnetAccessInfoRecItemModel } from './intnet-access-info-record-item.model';

// if there is no data intnetAccessInfoRecord will be null
export interface IntnetFinInstIdInqResponseModel {
    srchMsgRsHdr: SearchResponseHeaderModel;
    intnetFinInstId: string;
    intnetAccessInfoRecord?: IntnetAccessInfoRecItemModel;
}
