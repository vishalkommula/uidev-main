import { AppComponent } from './app.component';

let componenet: AppComponent;

describe('App Component Test',()=> {
    beforeEach(()=> {
        componenet = new AppComponent();
    });

    it('Component should be created',()=> {
        expect(componenet).toBeTruthy();
    });
});
