import { AccountAccessGridColDef } from './account-access-grid.def';

let component: AccountAccessGridColDef;

describe('Account Access Grid Column Definition Component Test',() => {
    beforeEach(() => {
        component = new AccountAccessGridColDef();
    });

    it('Component should be created',() => {
        expect(component).toBeTruthy();
    });

    it('onPreview should be executed',()=> {
        component.onPreview({} as any);
    });
    it('getAccountTypeEnumValue method - should be executed', () => {
        const enumString = 'D' ;
        expect(component.getAccountTypeEnumValue(enumString)).toBe('check');
    });
    it('getAccountTypeEnumValue method undefined - should be executed', () => {
        const  enumString =  '' ;
        expect(component.getAccountTypeEnumValue(enumString as any)).toBe('');
    });
});
