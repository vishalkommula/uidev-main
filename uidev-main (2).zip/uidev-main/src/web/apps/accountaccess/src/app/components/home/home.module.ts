import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AngularSplitModule } from 'angular-split';
import { HttpClientModule } from '@angular/common/http';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// Ag-grid
import 'ag-grid-enterprise';

// UID
import { UidPrimaryDetailModule } from '@uid/uid-primary-detail';
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';
import { UidAggridModule } from '@uid/uid-grid';

import { HomeComponent } from './home.component';
import { DataService } from '../../service/data.service';
import { accountAccessReducer } from '../../store/reducers/accountaccess.reducers';
import { AccountAccessEffects } from '../../store/effects/accountaccess.effects';

const routes: Routes = [
    { path: '', component: HomeComponent }
];

@NgModule({
    declarations: [
        HomeComponent,
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        RouterModule.forChild(routes),
        UidAngularControlsModule,
        UidDirectivesModule,
        UidPipesModule,
        UidPrimaryDetailModule,
        UidAggridModule,
        AngularSplitModule,
        ReactiveComponentModule,
        StoreModule.forFeature('accountAccess', accountAccessReducer),
        EffectsModule.forFeature([AccountAccessEffects]),
    ],
    providers: [ DataService ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class HomeModule {}
