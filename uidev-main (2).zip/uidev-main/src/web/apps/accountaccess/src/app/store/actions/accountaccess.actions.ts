import { createAction, props } from '@ngrx/store';
import { AccIdAccessInfoRecItemModel } from '../../models/account-id-access-info-record-item.model';
import { IntnetFinInstIdInqRequestModel } from '../../models/intnet-fin-inst-id-inq-request.model';
import { IntnetFinInstIdInqResponseModel } from '../../models/intnet-fin-inst-id-inq-response.model';

export const getIntnetAccessInfoRecord = createAction('[Account Access] Get Intnet Access Info Record',
    props<{ intnetFinInstIdInqRequest: IntnetFinInstIdInqRequestModel }>());

export const getIntnetAccessInfoRecordSuccess = createAction('[Account Access] Get Intnet Access Info Record Success',
    props<{ intnetFinInstIdInqResponse: IntnetFinInstIdInqResponseModel }>());

export const getIntnetAccessInfoRecordFailure = createAction('[Account Access] Get Intnet Access Info Record Failure',
    props<{ error: Error }>());

export const updateCurrentSelectedRecord = createAction('[Account Access] Update The Current Selected Record',
    props<{ currentRecord: AccIdAccessInfoRecItemModel }>());

export const gridRowShowDetailButtonClicked = createAction('[Account Access] Grid Row Detail Button Clicked');
