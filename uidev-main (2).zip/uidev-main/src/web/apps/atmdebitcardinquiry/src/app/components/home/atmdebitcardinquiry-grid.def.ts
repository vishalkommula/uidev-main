import { Injectable } from '@angular/core';

// Ag grid
import { ColDef, GridOptions, ValueFormatterParams, ValueGetterParams } from 'ag-grid-community';

// UID
import { AgGridHyperlinkCellRendererComponent } from '@uid/uid-grid';
import { formatDate } from '@uid/uid-utilities';
import { AccountTypesIcons, DateFormatterType } from '@uid/uid-models';

@Injectable({ providedIn: 'root' })
export class AtmDebitCardInquiryGridService {
    // custom calendar filter
    filterParams = {
    // provide comparator function
        comparator: (filterLocalDateAtMidnight: any, cellValue: any) => {
            if (cellValue == null) {
                return 0;
            }
            const dateAsString = cellValue;
            // In the example application, dates are stored as yyyy-mm-dd
            // We create a Date object for comparison against the filter date
            const dateParts = dateAsString.split('-');
            const year = Number(dateParts[0]);
            const month = Number(dateParts[1]) - 1;
            const day = Number(dateParts[2]);
            const cellDate = new Date(year, month, day);
            // Now that both parameters are Date objects, we can compare
            if (cellDate < filterLocalDateAtMidnight) {
                return -1;
            } else if (cellDate > filterLocalDateAtMidnight) {
                return 1;
            }
            return 0;
        },
    };

    public columns: ColDef[] = [
        {
            field: 'eFTCardNum',
            headerName: 'Account Number',
            filter: 'agTextColumnFilter',
            cellRendererSelector: (params) => ({
                component: AgGridHyperlinkCellRendererComponent,
                params: { iconType:this.getAccountTypeEnumValue(this.acctType), iconContext: 'secondary-btn' },
            }),
        },
        {
            field: 'embosName',
            headerName: 'Emboss Name',
            filter: 'agTextColumnFilter',
            resizable: true
        },
        {
            field: 'secdEmbosName',
            headerName: 'Sec Emboss Name',
            filter: 'agTextColumnFilter',
            resizable: true,
        },
        {
            field: 'eFTCardStatDesc',
            headerName: 'Status',
            filter: true,
            resizable: true,
            cellStyle: (params: { value: string }) => (params.value === 'Hot Card' ? { color: 'red' } : null),
        },
        {
            field: 'custId',
            headerName: 'CIF Number',
            filter: 'agTextColumnFilter',
            resizable: true,
            cellClass: 'ag-left-aligned-cell',
            cellRendererSelector: (params) =>({
                component: AgGridHyperlinkCellRendererComponent,
                params: { iconType:'person', iconContext: 'secondary-btn' },
            }),
        },
        {
            field: 'taxId',
            headerName: 'Tax ID',
            filter: 'agTextColumnFilter',
            resizable: true,
            cellClass: 'ag-left-aligned-cell',
            cellRenderer: AgGridHyperlinkCellRendererComponent,
        },
        {
            field: 'lastActDt',
            headerName: 'Last Used',
            filter: 'agDateColumnFilter',
            cellClass: 'ag-right-aligned-cell',
            resizable: true,
            filterParams: this.filterParams,
            valueFormatter: this.dateFormatter,
        },
        {
            field: 'parmValDetail',
            headerName: 'ISO Description',
            filter: true,
            resizable: true,
        },
    ];

    public defautColDef: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public gridOptions: GridOptions = {
        columnDefs: this.columns,
        defaultColDef: this.defautColDef,
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        pagination: true,
        paginationPageSize: 25,
        rowHeight: 30,
        suppressRowClickSelection:true,
        suppressRowDeselection:true,
    };
    acctType !: string;


    constructor() {}

    // append the inquiry date and time
    dateFormatter(params: ValueFormatterParams) {
        return formatDate(params.value, DateFormatterType.DisplayedDateFormatter);
    }

    // return account id as empty if account id is 0
    getAccountId(params: ValueGetterParams) {
        return params.data.acctId > 0 ? params.data.acctId : '';
    }
    getAccountType(acctType: string){
        this.acctType = acctType;
    }
    getAccountTypeEnumValue(enumString: any){
        const enumValue = (<any>AccountTypesIcons)[enumString];
        return enumValue === undefined ? '' : enumValue;
    }
}
