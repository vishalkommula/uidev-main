import { createAction, props } from '@ngrx/store';
import { EFTCardSrchRequest } from '../../models/atmDebitCardInquiry-request.model';
import { EFTCardSrchResponse } from '../../models/atmDebitCardInquiry-response.model';

// Atm debit card inquiry details request action
export const getAtmDebitCardInquiry = createAction('Get Atmdebitcardinquiry data request', props<{ request: EFTCardSrchRequest }>());

// Atm debit card inquiry details action success response
export const getAtmDebitCardInquirySuccess = createAction('Get Atmdebitcardinquiry success response', props<{ response: EFTCardSrchResponse }>());

// Atm debit card inquiry details action error response
export const getAtmDebitCardInquiryFailure = createAction('Get Atmdebitcardinquiry failed response', props<{ error: Error }>());

// Exclude hot cards button action
export const getExcludeHotCardsSuccess = createAction('Exclude hot cards data filltered', props<{ hotcard: string }>());
