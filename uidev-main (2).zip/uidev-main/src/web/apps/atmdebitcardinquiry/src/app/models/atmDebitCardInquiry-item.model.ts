export interface EftCardSrcRecItemModel{
    eFTCardNum?: number;
    embosName?: string;
    secdEmbosName?: string;
    eFTCardStatDesc?: string;
    custId?: string;
    taxId?: string;
    lastActDt?: Date;
    parmValDetail?: string;
};

