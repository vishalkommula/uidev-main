import { SearchResponseHeaderModel } from '@uid/uid-models';
import { EftCardSrcRecItemModel } from './atmDebitCardInquiry-item.model';


export interface EFTCardSrchResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    acctId: string;
    acctType: string;
    eFTCardSrchArray: EftCardSrcRecItemModel[];
};
