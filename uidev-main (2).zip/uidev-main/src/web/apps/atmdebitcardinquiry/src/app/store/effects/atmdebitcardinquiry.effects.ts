import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { DataService } from '../../service/data.service';
import * as atmDebitCardInquiryAction from '../actions/atmdebitcardinquiry.action';

@Injectable()
export class AtmDebitCardInquiryEffects{

    constructor(private dataService: DataService, private actions$: Actions){}

    // Get Atm debit card inquiry data from data service
    getAtmDebitCardInquiryDetails$ = createEffect(() => this.actions$.pipe(
        ofType(atmDebitCardInquiryAction.getAtmDebitCardInquiry),
        switchMap((action) =>
            this.dataService
                .getAtmDebitCardInquiryDetails(action.request)
                .pipe(
                    map((response) => atmDebitCardInquiryAction.getAtmDebitCardInquirySuccess({ response })),
                    catchError((error) =>
                        of(atmDebitCardInquiryAction.getAtmDebitCardInquiryFailure({ error }))
                    )
                )
        )
    )
    );
}
