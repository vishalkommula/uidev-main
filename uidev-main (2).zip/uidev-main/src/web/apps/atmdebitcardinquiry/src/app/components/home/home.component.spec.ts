import { ComponentFixture } from '@angular/core/testing';

import { HomeComponent } from './home.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { GridReadyEvent } from 'ag-grid-community';

import atmDebitCardInquiryMock from '../../mock-data/atmDebitCardInquiry.mock.json';
import { Observable, of } from 'rxjs';
import { EFTCardSrchResponse } from '../../models/atmDebitCardInquiry-response.model';

let component: HomeComponent;

const atmDebitCardInquiryActionsMock = {
    getAtmDebitCardInquiry: jest.fn(),
};
const atmDebitCardInquirySelectorMock ={
    selectAtmDebitCardInquiryDetails:jest.fn(),
    selectExcludeHotCardsData:jest.fn(),
};
const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() =>({
        subscribe:jest.fn(),
    })),
};
const gridDef = {

};

describe('HomeComponent', () => {
    let fixture: ComponentFixture<HomeComponent>;


    beforeEach(() => {
        component = new HomeComponent(storeMock as any,gridDef as any);
        component.atmDebitCardInquiryActions = atmDebitCardInquiryActionsMock as any;
        component.atmDebitCardInquirySelector = atmDebitCardInquirySelectorMock as any;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('data should be fetched on oninit', () => {
        component.ngOnInit();
        expect(atmDebitCardInquiryActionsMock.getAtmDebitCardInquiry).toBeCalledWith({ request: {} as any });
        expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
        expect(atmDebitCardInquiryActionsMock.getAtmDebitCardInquiry).toHaveBeenCalledTimes(1);
    });
    it('onGridReady method - should be executed', () => {
        const event = {
            api: { closeToolPanel: jest.fn(),
                sizeColumnsToFit: jest.fn(),
                getRowNode: jest.fn(() => {
                    // eslint-disable-next-line no-unused-labels
                    setSelected: jest.fn();
                })
            },
            columnApi: {},
        };
        component.onGridReady(event as any);
        expect(event.api.closeToolPanel).toBeCalledTimes(1);
    });
    it('onGridSizeChanged method - should be executed', () => {
        const event = {
            api:{
                sizeColumnsToFit:jest.fn()
            }
        } as any;
        component.onGridSizeChanged(event);
        const actualValue = event.api.sizeColumnsToFit;
        expect(actualValue).toBeCalled();
    });;
    it('onExclude Hot Cards Click method - should be excuted if hotcardstatus Exclude Hot Cards', () => {
        const selectedCardtype = {
            detail: 'Exclude Hot Cards'
        };
        component.getAtmDebitCardInquiryType(selectedCardtype);
        expect(selectedCardtype.detail).toEqual('Exclude Hot Cards');
        expect(storeMock.select).toBeCalled();
    });
    it('onView All Cards Click method - should be excuted if View All Cards false', () => {
        const selectedCardtype = {
            detail: 'View All Cards'
        };
        component.getAtmDebitCardInquiryType(selectedCardtype);
        expect(selectedCardtype.detail).toEqual('View All Cards');
        expect(storeMock.select).toBeCalled();
    });
    it('ngOnDestroy: should be called', () => {
        component.atmDebitCardAccountType$=of();
        component.ngOnDestroy();
    });
});
