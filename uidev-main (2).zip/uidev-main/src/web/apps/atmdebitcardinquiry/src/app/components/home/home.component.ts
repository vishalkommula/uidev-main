
import { Component, OnInit,OnDestroy ,ViewChild } from '@angular/core';

// Ag grid
import { GridApi, GridOptions } from 'ag-grid-enterprise';
import { GridReadyEvent, GridSizeChangedEvent } from 'ag-grid-community';

// Libs
import { UidAggridComponent } from '@uid/uid-grid';

// NGRX
import { Store } from '@ngrx/store';
import { Observable, of, Subscription } from 'rxjs';
import { EftCardSrcRecItemModel } from '../../models/atmDebitCardInquiry-item.model';
import * as AtmDebitCardInquiryActions from '../../store/actions/atmdebitcardinquiry.action';
import * as AtmDebitCardInquirySelector from '../../store/selectors/atmdebitcardinquiry.selector';
import { AtmDebitCardInquiryGridService } from './atmdebitcardinquiry-grid.def';
import { AtmDebitCardType } from '../../models/atmdebitcard.enum';
import { unsubscribe } from '@uid/uid-utilities';
@Component({
    selector: 'uid-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit,OnDestroy {
  @ViewChild(UidAggridComponent) uidAggrid!: UidAggridComponent;
  gridApi: GridApi = {} as GridApi;
  atmDebitCardInquiryActions = AtmDebitCardInquiryActions;
  atmDebitCardInquirySelector = AtmDebitCardInquirySelector;
  hotCardStatus = true;
  acctType!: string;
  subs: Subscription[] = [];
  atmDebitCardInquiryDetails$: Observable<EftCardSrcRecItemModel[]> = of();
  atmDebitCardInquiryType = AtmDebitCardType;
  atmDebitCardAccountType$: Observable<string>= of();
  public gridOptions: GridOptions = {
      onGridReady: (event) => this.onGridReady(event),
      onGridSizeChanged: (event) => this.onGridSizeChanged(event),
  };


  constructor(private store: Store, private gridDef: AtmDebitCardInquiryGridService) {
      this.atmDebitCardInquiryDetails$ = this.store.select(this.atmDebitCardInquirySelector.selectAtmDebitCardInquiryDetails);
      this.atmDebitCardAccountType$ = this.store.select(this.atmDebitCardInquirySelector.selectAtmDebitCardAccountType);
      const atmDebitCardAccountTypeSub = this.atmDebitCardAccountType$.subscribe(x =>{
          this.gridDef.getAccountType(x);
      });
      this.subs.push(atmDebitCardAccountTypeSub);
  }

  ngOnInit(): void {
      // assigning gridoption
      this.gridOptions = { ...this.gridOptions, ...this.gridDef.gridOptions };
      this.store.dispatch(this.atmDebitCardInquiryActions.getAtmDebitCardInquiry({ request: {} as any }));
  }

  onGridReady(event: GridReadyEvent) {
      this.gridApi = event.api;
      event.api?.closeToolPanel();
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
      event.api.sizeColumnsToFit();
  }

  //   toggle function
  getAtmDebitCardInquiryType(selectedCardType: any){
      this.atmDebitCardInquiryDetails$ = selectedCardType.detail === AtmDebitCardType.excludeHotCard ?
          this.store.select(this.atmDebitCardInquirySelector.selectExcludeHotCardsData):
          this.store.select(this.atmDebitCardInquirySelector.selectAtmDebitCardInquiryDetails);
  }
  ngOnDestroy(): void {
      unsubscribe(this.subs);
  }
}
