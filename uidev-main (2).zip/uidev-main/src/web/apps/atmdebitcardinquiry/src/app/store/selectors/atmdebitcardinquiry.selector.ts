import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AtmDebitCardInquiryState } from '../state/atmdebitcardinquiry.state';



export const selectAtmDebitCardInquiryRoot = createFeatureSelector<AtmDebitCardInquiryState>('atmDebitCardInquiry');
// select atmDebitCard selector
export const selectAtmDebitCardInquiryDetails = createSelector(selectAtmDebitCardInquiryRoot, (state: AtmDebitCardInquiryState)=> state.atmDebitCardInquiryDetailsResponse.eFTCardSrchArray);
// select accounttype
export const selectAtmDebitCardAccountType = createSelector(selectAtmDebitCardInquiryRoot, (state: AtmDebitCardInquiryState)=> state.atmDebitCardInquiryDetailsResponse.acctType);
// select exclude hot card data selector
export const selectExcludeHotCardsData = createSelector(selectAtmDebitCardInquiryRoot, (state: AtmDebitCardInquiryState)=> {
    const excludeHotCardData = state.atmDebitCardInquiryDetailsResponse.eFTCardSrchArray;
    if(excludeHotCardData !== null && excludeHotCardData !== undefined && excludeHotCardData.length > 1){
        return excludeHotCardData.filter((data)=>data.eFTCardStatDesc !== 'Hot Card');
    }
    return [];
}

);
