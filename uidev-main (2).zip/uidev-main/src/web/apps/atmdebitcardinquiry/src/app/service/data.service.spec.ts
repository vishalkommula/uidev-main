
import { DataService } from './data.service';

let service: DataService;

describe('DataService', () => {

    beforeEach(() => {
        service = new DataService();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('getAtmCardDetails method - should be excuted', async ()=> {
        expect(await service.getAtmDebitCardInquiryDetails({} as any).toPromise()).toBeTruthy();
    });
});
