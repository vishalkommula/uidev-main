
import { AppComponent } from './app.component';
let component: AppComponent;
describe('AppComponent', () => {
    beforeEach(async () => {
        component=new AppComponent();
    });

    it('should create the app', () => {
        expect(component).toBeTruthy();
    });

    it('should have as title \'atmdebitcardinquiry\'', () => {
        expect(component.title).toEqual('atmdebitcardinquiry');
    });
});
