import { atmDebitCardInquiryReducer, initialAtmDebitCardInquiryState } from './atmdebitcardinquiry.reducer';

import * as AtmDebitCardInquiryActions  from '../actions/atmdebitcardinquiry.action';


const expectedState = {
    atmDebitCardInquiryDetailsResponse :{} as any
};

const responseData = { data: 'data' };

describe('Atm Debit Card Inquiry Reducers test', () => {

    it('getAtmDebitCardInquirySuccess - should be executed',()=>{
        const newState = initialAtmDebitCardInquiryState;
        const state = atmDebitCardInquiryReducer(newState, AtmDebitCardInquiryActions.getAtmDebitCardInquirySuccess({ response: responseData as any }));
        expectedState.atmDebitCardInquiryDetailsResponse = responseData;
        expect(state).toEqual(expectedState);
    });
});
