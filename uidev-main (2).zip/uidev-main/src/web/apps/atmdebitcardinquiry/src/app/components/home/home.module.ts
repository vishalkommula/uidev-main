import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// Ag-grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// UID
import { UidDirectivesModule } from '@uid/uid-directives';
import { UidAggridModule } from '@uid/uid-grid';

// Store
import { AtmDebitCardInquiryEffects } from '../../store/effects/atmdebitcardinquiry.effects';
import { atmDebitCardInquiryReducer } from '../../store/reducers/atmdebitcardinquiry.reducer';

// Components
import { HomeComponent } from './home.component';


// Service
import { DataService } from '../../service/data.service';

const routes: Routes = [
    { path: '', component: HomeComponent, children: [
        { path: '', component: HomeComponent },
    ] },
];

@NgModule({
    declarations: [
        HomeComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,
        HttpClientModule,
        UidDirectivesModule,
        UidAggridModule,
        ReactiveFormsModule,
        AgGridModule.withComponents([]),
        ReactiveComponentModule,
        StoreModule.forFeature('atmDebitCardInquiry', atmDebitCardInquiryReducer),
        EffectsModule.forFeature([AtmDebitCardInquiryEffects]),
    ],
    providers: [DataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule{}
