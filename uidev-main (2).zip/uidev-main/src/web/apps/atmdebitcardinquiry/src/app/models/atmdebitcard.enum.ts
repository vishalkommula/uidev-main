export enum AtmDebitCardType {
    viewCard = 'View All Cards',
    excludeHotCard = 'Exclude Hot Cards',
  }
