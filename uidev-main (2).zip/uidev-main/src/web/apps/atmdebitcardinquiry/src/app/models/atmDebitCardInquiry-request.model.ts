import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface EFTCardSrchRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    acctType: string;
};
