module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'atmdebitcardinquiry',
    exposes: {
        './Module': 'apps/atmdebitcardinquiry/src/app/components/home/home.module.ts',
    },
};
