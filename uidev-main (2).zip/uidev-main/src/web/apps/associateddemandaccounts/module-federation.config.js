module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'associateddemandaccounts',
    exposes: {
        './Module': 'apps/associateddemandaccounts/src/app/components/home/home.module.ts'
    },
};
