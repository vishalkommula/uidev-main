/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { AccountFunction } from '../../models/account-function.model';
import { AssociatedDemandAccountFormDateTypeEnum } from '../../models/associated-demand-accounts.resource';
import { InquiryType } from '../../models/inquiry-type.model';

export const getAssociatedTypeOptions =function (field?: FormlyFieldConfig): InquiryType[] {
    return field?.options?.formState.addProtectionAccountTypes ?? [];
};

export const getCustomerAccountFunction =function (field?: FormlyFieldConfig): AccountFunction[] {
    return field?.options?.formState.customerAccountFunctions ?? [];
};

export const getAccountTypes =function (field?: FormlyFieldConfig): InquiryType[] {
    return field?.options?.formState.addAccountTypes ?? [];
};

export const selectCustomerAcccount=function(field: any, $event: any){
    // setting the accountTye while changing the selectedCustomerAccount
    const selectedAccount=$event.value;
    const accountInfo=field.props.typeahead.find((x: AccountFunction)=>x.accId===selectedAccount);
    if(accountInfo!=null && accountInfo !== undefined){
        field?.form?.get('accountType')?.setValue(accountInfo.acctType);
    }else{
        field?.form?.get('accountType')?.setValue(null);
    }
};

//TODO : created generic model to error message
export const accIdRequiredValidation = function (field: FormlyFieldConfig) {
    if((field?.options?.formState.submitted ||
         field.formControl?.touched) && (field.props?.required &&field.formControl?.hasError('required'))){
            field.props!['validationMessages'].push(
                { message: 'Account Id is required.',errorType:'required' });
            return true;
    };
    return false;
};

export const checkAccIdExistValidation = function (field: FormlyFieldConfig) {
    if((field?.options?.formState.submitted ||
         field.formControl?.touched) && field.formControl?.value){
        const enteredAccId=field.formControl?.value;
        const isAccidExist=field.options?.formState.addedProtectionAccounts.findIndex((x: string)=>x===enteredAccId);
        if(isAccidExist!==-1){
            field.props!['validationMessages'].push(
                { message: `Account ${enteredAccId} has already been added.`,errorType:'custom' });
            return true;
        }
        return false;
    };
    return false;
};

export const accIdErrorValidation=function (field: FormlyFieldConfig) {
    field.props!['validationMessages']=[];
    const isAccIdRequiredValidationDisplay=accIdRequiredValidation(field);
    const isCheckAccIdExistValidationDisplayed=checkAccIdExistValidation(field);
    return isAccIdRequiredValidationDisplay || isCheckAccIdExistValidationDisplayed;
};

export const acctTypeRequiredValidation = function (field: FormlyFieldConfig) {
    if((field?.options?.formState.submitted ||
         field.formControl?.touched) && (field.props?.required &&field.formControl?.hasError('required'))){
        field.props!['validationMessages'] = [
            { message: 'Account Type is required.',errorType:'required' }];
        return true;
    };
    return false;
};

export function getAssociatedDemandAccountGroups(): FormlyFieldConfig[] {
    return [
        {
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'associatedType',
                    wrappers: ['form-field'],
                    props: {
                        label: 'Associated Account Type',
                        labelProp:'displayName',
                        labelClasses:'col-md-6',
                        valueClasses:'col-md-6',
                        valueProp:'typeCode',
                        style:{ 'width':'100%' },
                        attributes: {
                            'data-test-id': 'associateddemand-associatedType-01'
                        }
                    },
                    expressions:{
                        'props.options':getAssociatedTypeOptions
                    },
                    type: FormDataTypeEnum.dropdown,
                },
                {
                    key: 'accId',
                    wrappers: ['form-field'],
                    props: {
                        label: 'Account',
                        labelClasses:'col-md-6',
                        valueClasses:'col-md-6',
                        typeaheadOptionField:'accId',
                        maxlength:16,
                        actionButtonIconType:'ellipsis',
                        required:true,
                        valueProp:'accId',
                        optionValue:'accId',
                        typeaheadOptionsLimit:12,
                        style:{ 'width':'100%','height':'100%' },
                        attributes: {
                            'data-test-id': 'associateddemand-accId-01'
                        },
                        onSelect:selectCustomerAcccount
                    },
                    expressions:{
                        'props.typeahead':getCustomerAccountFunction,
                        'validation.show': accIdErrorValidation,
                    },
                    type: AssociatedDemandAccountFormDateTypeEnum.typeahead,
                },
                {
                    key: 'accountType',
                    wrappers: ['form-field'],
                    props: {
                        label: '',
                        labelProp:'displayName',
                        labelClasses:'col-md-6',
                        required:true,
                        placeholder :'\u00A0',    // this is to display empty placeholder
                        valueClasses:'col-md-6',
                        valueProp:'typeCode',
                        style:{ 'width':'100%' },
                        attributes: {
                            'data-test-id': 'associateddemand-accountType-01'
                        },
                    },
                    expressions:{
                        'props.options':getAccountTypes,
                        'validation.show': acctTypeRequiredValidation,
                    },
                    type: FormDataTypeEnum.dropdown,
                }
            ],
        },
    ];
}

