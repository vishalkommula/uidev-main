import { TypeaheadComponent } from './typeahead.component';

describe('TypeaheadComponent', () => {
    let component: TypeaheadComponent;

    beforeEach(() => {
        component = new TypeaheadComponent();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
