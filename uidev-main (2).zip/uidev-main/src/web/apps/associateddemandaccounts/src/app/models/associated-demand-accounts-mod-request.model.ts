import { FaultMsgRec, SearchRequestHeaderModel } from '@uid/uid-models';
import { AccountInfo } from './account-info.model';


export interface AssociatedDemandAccountsModRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    // acctId and acctType store the current account info
    acctId:       string;
    acctType:     string;
    associatedAccountType: string;
    // associatedAccountInfoRecords holds new ly added account to associated Account type
    // for Add : if protection type is already existing then existing records and
    // newly added account are passed.
    associatedAccountInfoRecords: AccountInfo[];
    // used for removing the account to associated type
    dlt: boolean;
    // TODO : should create separate model with name errorOvrRd and has just errorCode as property
    errOvrRdInfoArray: FaultMsgRec[];
};
