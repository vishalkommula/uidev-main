import {reducer, initialState} from './associateddemandaccounts.reducer';
import * as AssociatedDemandAccountsActions from '../action/associateddemandaccounts.action';
import { PageMode } from '@uid/uid-models';

describe('Associated Demand Accounts Reducers test', () => {
    it('associatedDemandAccountRetrieved returns the correct state', () => {
        const responseModel = {this: 'is a test'};
        const state = reducer(initialState, AssociatedDemandAccountsActions.associatedDemandAccountRetrieved({response: responseModel as any}));

        expect(state).toEqual({
            associateDemandAccountResponse: responseModel,
            associatedDemandAccountAddResponse: {},
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
        });
    });

    it('getAddDropDownsValuesRetrieved returns the correct state', () => {
        const responseModel = {this: 'is a test'};
        const state = reducer(initialState, AssociatedDemandAccountsActions.getAddDropDownsValuesRetrieved({response: responseModel as any}));

        expect(state).toEqual({
            associateDemandAccountResponse: {},
            associatedDemandAccountAddResponse: responseModel,
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
        });
    });

    it('addAssociatedDemandAccountSuccess returns the correct state', () => {
        const responseModel = {multipleAccountInfoRecords: {value1:'is a test'}};
        const state = reducer(initialState, AssociatedDemandAccountsActions.
            addAssociatedDemandAccountSuccess({response: responseModel as any}));

        expect(state).toEqual({
            associateDemandAccountResponse: {multipleAccountInfoRecords: {value1:'is a test'}},
            associatedDemandAccountAddResponse: {},
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
        });
    });

    it('deleteAssociatedDemandAccountSuccess returns the correct state', () => {
        const responseModel = {multipleAccountInfoRecords: {value1:'is a test'}};
        const state = reducer(initialState, AssociatedDemandAccountsActions.
            deleteAssociatedDemandAccountSuccess({response: responseModel as any}));

        expect(state).toEqual({
            associateDemandAccountResponse: {multipleAccountInfoRecords: {value1:'is a test'}},
            associatedDemandAccountAddResponse: {},
            pageMode: PageMode.Inquiry,
            faultRecInfoArray: [],
        });
    });

    it('pageMode returns the correct state', () => {
        const state = reducer(initialState, AssociatedDemandAccountsActions.togglePageMode
            ({pageMode:PageMode.Inquiry}));

        expect(state).toEqual({
            ...initialState,
            pageMode: PageMode.Inquiry,
        });
    });

    it('addFaultRecMessages returns the correct state', () => {
        const state = reducer(initialState, AssociatedDemandAccountsActions.
            addFaultRecMessages({faultRec:[1,2]} as any));

        expect(state).toEqual({
            ...initialState,
            faultRecInfoArray:[1,2]
        });
    });
});
