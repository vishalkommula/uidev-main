/* eslint-disable @typescript-eslint/naming-convention */
export const AssociatedDemandAccountValueType = {
    deleteDialogBoxTitle: 'Do you want to delete this associated demand account?',
};

export enum AssociatedDemandAccountFormDateTypeEnum {
  typeahead = 'typeahead',
};

export enum AssociatedAccountType{
  ProtectionAccount = 'ProtectionAccount',
  ProtectionAccountDesc ='Protection Account',
}

