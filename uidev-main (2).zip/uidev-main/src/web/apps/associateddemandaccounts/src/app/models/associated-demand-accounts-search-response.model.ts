import { SearchResponseHeaderModel } from '@uid/uid-models';
import { InquiryType } from './inquiry-type.model';
import { MultipleAccountInfoRecord } from './multiple-account-info-record.model';

export interface AssociatedDemandAccountsSearchResponseModel {
    srchMsgRsHdr:    SearchResponseHeaderModel;
    multipleAccountInfoRecords: MultipleAccountInfoRecord[];
    addProtectionAccountTypes: InquiryType[];
    showACHAutoReturn: boolean;
};
