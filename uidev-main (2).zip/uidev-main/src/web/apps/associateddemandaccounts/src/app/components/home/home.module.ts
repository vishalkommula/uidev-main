import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
// ag grid
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
// third party modules
import { AngularSplitModule } from 'angular-split';
import { JhaFormsModule } from '@jha/rui-angular/jha-forms';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';

// store
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { AssociatedDemandAccountsEffects } from '../../store/effect/associateddemandaccounts.effect';
import { reducer } from '../../store/reducer/associateddemandaccounts.reducer';

// formly
import { FormlyModule } from '@ngx-formly/core';
import { FormlyPrimeNGModule } from '@ngx-formly/primeng';
import { FormlySelectModule } from '@ngx-formly/core/select';
// primeng
import { DropdownModule } from 'primeng/dropdown';
// shared libs
import { UidPrimaryDetailModule } from '@uid/uid-primary-detail';
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';
import { UidAggridModule } from '@uid/uid-grid';
// component
import { HomeComponent } from './home.component';
import { DataService } from '../../service/data.service';
import { TypeaheadComponent } from './formly/type/typeahead/typeahead.component';


const routes = [
    { path: '', component: HomeComponent },
];

@NgModule({
    declarations: [HomeComponent,TypeaheadComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        UidDirectivesModule,
        UidAngularControlsModule,
        AgGridModule,
        UidAggridModule,
        FormlyModule.forRoot({
            types: [
                { name: 'typeahead', component: TypeaheadComponent }
            ],
        }),
        FormlyPrimeNGModule,
        DropdownModule,
        RouterModule.forChild(routes),
        FormlySelectModule,
        AngularSplitModule,
        ReactiveFormsModule,
        JhaFormsModule.forRoot(),
        StoreModule.forFeature('associatedDemandAccounts',reducer),
        EffectsModule.forFeature([AssociatedDemandAccountsEffects]),
        ReactiveComponentModule,
        UidPrimaryDetailModule,
        UidPipesModule,
        TypeaheadModule.forRoot(),
    ],
    providers: [DataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule {}
