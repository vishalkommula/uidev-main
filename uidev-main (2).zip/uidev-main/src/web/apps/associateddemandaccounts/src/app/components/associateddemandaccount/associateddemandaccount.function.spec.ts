import * as sut from './associateddemandaccount.function';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

describe('Associated Demand Account Functions!', () => {
    it('getAssociatedDemandAccountGroups returns stuff', () => {
        const retVal = sut.getAssociatedDemandAccountGroups();

        expect(retVal).toBeTruthy();
    });

    it('getAssociatedTypeOptions should array of associate Type', () => {
        const retVal = sut.getAssociatedTypeOptions({ options:{ formState:{ addProtectionAccountTypes: ['data1'] } } } as any);
        expect(retVal).toStrictEqual(['data1']);
    });

    it('getCustomerAccountFunction should array of associate Type', () => {
        const retVal = sut.getCustomerAccountFunction({ options:{ formState:{ customerAccountFunctions: ['data1'] } } } as any);
        expect(retVal).toStrictEqual(['data1']);
    });

    it('getAccountTypes should array of associate Type', () => {
        const retVal = sut.getAccountTypes({ options:{ formState: { addAccountTypes: ['data1'] } } } as any);
        expect(retVal).toStrictEqual(['data1']);
    });

    it('getAssociatedTypeOptions should empty array', () => {
        const retVal = sut.getAssociatedTypeOptions({} as any);
        expect(retVal).toStrictEqual([]);
    });

    it('getCustomerAccountFunction should empty array', () => {
        const retVal = sut.getCustomerAccountFunction({} as any);
        expect(retVal).toStrictEqual([]);
    });

    it('getAccountTypes should empty array', () => {
        const retVal = sut.getAccountTypes({} as any);
        expect(retVal).toStrictEqual([]);
    });

    it('selectCustomerAcccount should update dropdown value of account type', () => {
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ typeahead:[{ accId:'88880' }] } } as any;
        const retVal = sut.selectCustomerAcccount(field, { value:'88880' } as any);
        expect(field.form.get).toBeCalledTimes(1);
    });

    it('selectCustomerAcccount should not update dropdown value of account type', () => {
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ typeahead:[{ accId:'88880' }] } } as any;
        const retVal = sut.selectCustomerAcccount(field, { value:'81880' } as any);
        expect(field.form.get).toBeCalledTimes(1);
    });

    it('getAssociatedDemandAccountGroups returns the right form group structure', () => {
        const fields = sut.getAssociatedDemandAccountGroups();

        expect(fields.length).toBe(1);
        expect(fields[0].fieldGroup?.length).toBe(3);
    });


    it('acctTypeRequiredValidation check acctType is not added then return true',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:true } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(true) } } as any;
        const expectedValue=sut.acctTypeRequiredValidation(field as any);
        expect(expectedValue).toBe(true);
    });

    it('acctTypeRequiredValidation check acctType is added then return false',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:true } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false) } } as any;
        const expectedValue=sut.acctTypeRequiredValidation(field as any);
        expect(expectedValue).toBe(false);
    });

    it('acctTypeRequiredValidation check acctType is not added and touched or submitted then return false',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:false } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false) } } as any;
        const expectedValue=sut.acctTypeRequiredValidation(field as any);
        expect(expectedValue).toBe(false);
    });

    it('accIdRequiredValidation check accId is not added then return true',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:true } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(true) } } as any;
        const expectedValue=sut.accIdRequiredValidation(field as any);
        expect(expectedValue).toBe(true);
    });

    it('accIdRequiredValidation check accId is added then return false',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:true } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false) } } as any;
        const expectedValue=sut.accIdRequiredValidation(field as any);
        expect(expectedValue).toBe(false);
    });

    it('accIdRequiredValidation check accId is not added and touched or submitted then return false',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:false } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false) } } as any;
        const expectedValue=sut.accIdRequiredValidation(field as any);
        expect(expectedValue).toBe(false);
    });

    it('checkAccIdExistValidation check accId is added then return true',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:true,value:'121',addedProtectionAccounts:['121'] } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false),value:'121' } } as any;
        const expectedValue=sut.checkAccIdExistValidation(field as any);
        expect(expectedValue).toBe(true);
    });

    it('checkAccIdExistValidation check accId is not exist then return false',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:true,value:'121',addedProtectionAccounts:['121'] } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false),value:'1211' } } as any;
        const expectedValue=sut.checkAccIdExistValidation(field as any);
        expect(expectedValue).toBe(false);
    });

    it('checkAccIdExistValidation check accId is not added and touched or submitted then return false',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:false } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(false) } } as any;
        const expectedValue=sut.checkAccIdExistValidation(field as any);
        expect(expectedValue).toBe(false);
    });

    it('accIdErrorValidation should return true as required is true and hasError is not null',()=>{
        const field={ form:{ get:jest.fn(
            ()=>{
                jest.fn().mockReturnValueOnce(true);
            }
        ) },props:{ required:true,validationMessages:[] },options:{ formState:{ submitted:false } },
        formControl:{ hasError:jest.fn().mockReturnValueOnce(true),touched:true } } as any;
        const expectedValue=sut.accIdErrorValidation(field as any);
        expect(expectedValue).toBe(true);
    });
});
