import { ButtonRendererClickParms } from '@uid/uid-grid';
import { AssociatedDemandAccountsGridColDef } from './associateddemandaccount-grid-def';

jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

let sut: AssociatedDemandAccountsGridColDef;

describe('AssociatedDemandAccountGridColDef', () => {
    beforeEach(() => {
        sut = new AssociatedDemandAccountsGridColDef();
    });

    it('service should be created', () => {
        expect(sut).toBeTruthy();
    });

    it('for now, onDelete just cover them up', () => {
        (<any>window).console = { log: jest.fn() };
        sut.onDelete({} as ButtonRendererClickParms);
        expect(console.log).toBeCalledTimes(1);
    });
    it('getAccountTypeEnumValue method - should be executed', () => {
        const enumString = 'D' ;
        expect(sut.getAccountTypeEnumValue(enumString)).toBe('check');
    });
    it('getAccountTypeEnumValue method undefined - should be executed', () => {
        const  enumString =  '' ;
        expect(sut.getAccountTypeEnumValue(enumString as any)).toBe('');
    });
});
