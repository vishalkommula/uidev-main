import { AccountType } from '@uid/uid-models';

export interface MultipleAccountInfoRecord {
    accountDescription: string;
    accountStatus: string;
    acctId: string;
    acctType: AccountType;
    currentBalance: number;
    amount: number;
    multipleAcctTypeDesc: string;
    originalAccountType: string;
    personName: string;
};
