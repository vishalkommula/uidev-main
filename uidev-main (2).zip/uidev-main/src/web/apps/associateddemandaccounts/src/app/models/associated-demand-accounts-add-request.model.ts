import { SearchRequestHeaderModel } from '@uid/uid-models';


export interface AssociatedDemandAccountsAddRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    associatedAccountType: string;
};
