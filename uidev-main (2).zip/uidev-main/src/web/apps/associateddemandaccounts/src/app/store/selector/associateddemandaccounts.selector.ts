import { createFeatureSelector, createSelector } from '@ngrx/store';
import { FormlyFormOptions } from '@ngx-formly/core';
import { formatFaultMessages } from '@uid/uid-utilities';
import { AssociatedDemandAccountFormState } from '../../models/associated-demand-accounts-formstate.model';
import { AssociatedAccountType } from '../../models/associated-demand-accounts.resource';
import { MultipleAccountInfoRecord } from '../../models/multiple-account-info-record.model';
// models
import { AssociatedDemandAccountsState } from '../state/associateddemandaccounts.state';

export const selectRoot = createFeatureSelector<AssociatedDemandAccountsState>('associatedDemandAccounts');

export const selectmultipleAccountInfoRecords = createSelector(selectRoot, (state) => state.associateDemandAccountResponse.multipleAccountInfoRecords);

export const selectAddProtectionAccountTypes = createSelector(selectRoot, (state) => state.associateDemandAccountResponse.addProtectionAccountTypes);

export const selectAddAccountTypes = createSelector(selectRoot, (state) => state.associatedDemandAccountAddResponse.addAccountTypes);

export const selectCustomerAccountFunctions = createSelector(selectRoot, (state) => state.associatedDemandAccountAddResponse.customerAccountFunctions);


export const selectFaultRecArray = createSelector(selectRoot, (state) => state.faultRecInfoArray);

export const selectShowACHAutoReturn = createSelector(selectRoot, (state) => state.associateDemandAccountResponse.showACHAutoReturn);

export const selectPageMode = createSelector(selectRoot, (state) => state.pageMode);

export const selectAssociatedDemandAccountsSearchMessageResponseHeader = createSelector(selectRoot, (state) => state.associateDemandAccountResponse?.srchMsgRsHdr);

export const selectFaultMessages = createSelector(selectFaultRecArray, formatFaultMessages);

export const selectFormlyOptions = createSelector(selectAddProtectionAccountTypes,
    selectCustomerAccountFunctions,selectPageMode, selectAddAccountTypes,selectmultipleAccountInfoRecords,
    (addProtectionAccountTypes, customerAccountFunctions, pageMode,addAccountTypes,multipleAccountInfoRecords) => {
        const addedProtectionAccounts: string[]=[];
        multipleAccountInfoRecords?.filter(
            (x: MultipleAccountInfoRecord) => {
                if(x.multipleAcctTypeDesc === AssociatedAccountType.ProtectionAccountDesc) {
                    addedProtectionAccounts.push(x.acctId);
                }
            });
        const formState: AssociatedDemandAccountFormState = {
            addProtectionAccountTypes,
            customerAccountFunctions,
            pageMode: pageMode,
            addAccountTypes,
            submitted:false,
            addedProtectionAccounts:addedProtectionAccounts
        };
        return formState;
    });
