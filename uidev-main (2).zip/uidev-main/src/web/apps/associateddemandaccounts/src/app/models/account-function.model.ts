export interface AccountFunction {
  accId: string;
  acctType: string;
  acctName: string;
  acctRelDesc: string;
  iconType: string;
  dispalyAmt: number;
  acctStatDesc: string;
}
