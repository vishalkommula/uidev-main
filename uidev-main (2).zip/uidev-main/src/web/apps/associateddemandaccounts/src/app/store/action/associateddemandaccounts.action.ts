import { createAction, props } from '@ngrx/store';
import { FaultMsgRec, PageMode } from '@uid/uid-models';
import { AssociatedDemandAccountsAddRequest } from '../../models/associated-demand-accounts-add-request.model';
import { AssociatedDemandAccountsAddResponse } from '../../models/associated-demand-accounts-add-response.model';
import { AssociatedDemandAccountsModResponse } from '../../models/associated-demand-accounts-mod-response.model';
import { AssociatedDemandAccountsModRequest } from '../../models/associated-demand-accounts-mod-request.model';
import { AssociatedDemandAccountsSearchRequest } from '../../models/associated-demand-accounts-search-request.model';
import { AssociatedDemandAccountsSearchResponseModel } from '../../models/associated-demand-accounts-search-response.model';

export const togglePageMode = createAction(
    '[Associated Demand Accounts] Change Page Mode',
    props<{pageMode: PageMode}>()
);

export const getAssociatedDemandAccountRecords =createAction(
    '[Associated Demand Accounts] Get Associated Demand Account Records',
    props<{ request: AssociatedDemandAccountsSearchRequest }>()
);
export const associatedDemandAccountRetrieved = createAction(
    '[Associated Demand Accounts] Associated Demand Account Records Retrieved',
    props<{ response: AssociatedDemandAccountsSearchResponseModel }>()
);

export const associatedDemandAccountFailure = createAction(
    '[Associated Demand Accounts] Associated Demand Account Records Failure',
    props<{ error: Error }>()
);


export const getAddDropDownsValues= createAction(
    '[Associated Demand Accounts] Get Add DropDowns Value',
    props<{ request: AssociatedDemandAccountsAddRequest}>()
);


export const getAddDropDownsValuesRetrieved= createAction(
    '[Associated Demand Accounts] Get Add DropDowns Values Retrieved',
    props<{ response: AssociatedDemandAccountsAddResponse}>()
);

export const getAddDropDownsValuesFailure= createAction(
    '[Associated Demand Accounts] Get Add DropDowns Values Failure',
    props<{ error: Error }>()
);

export const addAssociatedDemandAccount= createAction(
    '[Associated Demand Accounts] Add Associated Demand Account Record',
    props<{ request: AssociatedDemandAccountsModRequest}>()
);

export const addAssociatedDemandAccountSuccess= createAction(
    '[Associated Demand Accounts] Add Associated Demand Account Record Success',
    props<{ response: AssociatedDemandAccountsModResponse}>()
);

export const addAssociatedDemandAccountFailure= createAction(
    '[Associated Demand Accounts] Add Associated Demand Account Record Failure',
    props<{ error: Error }>()
);

export const deleteAssociatedDemandAccount= createAction(
    '[Associated Demand Accounts] Delete Associated Demand Account Record',
    props<{ request: AssociatedDemandAccountsModRequest}>()
);

export const deleteAssociatedDemandAccountSuccess= createAction(
    '[Associated Demand Accounts] Delete Associated Demand Account Record Success',
    props<{ response: AssociatedDemandAccountsModResponse}>()
);

export const deleteAssociatedDemandAccountFailure= createAction(
    '[Associated Demand Accounts] Delete Associated Demand Account Record Failure',
    props<{ error: Error }>()
);


export const addFaultRecMessages=createAction(
    '[Associated Demand Accounts] Add FaultRecMessages To Store',
    props<{faultRec: FaultMsgRec[]}>()
);
