import { AccountFunction } from './account-function.model';
// custom model to hold the dropdown values.these values are used to frame the array of accountId and accountType.
export interface AssociatedDemandAccountFormModel
{
    associatedType: string;
    accId: string;
    accountType: string | null;
};
