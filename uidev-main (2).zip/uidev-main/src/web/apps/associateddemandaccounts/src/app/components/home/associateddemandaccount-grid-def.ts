/* eslint-disable @typescript-eslint/member-ordering */
import { Injectable } from '@angular/core';
import { ButtonRendererModel, ButtonRendererClickParms, ButtonRendererComponent, AmountRendererComponent, AgGridHyperlinkCellRendererComponent } from '@uid/uid-grid';
import { AccountTypesIcons } from '@uid/uid-models';
import { ColDef, GridOptions, ICellRendererParams } from 'ag-grid-community';

@Injectable({ providedIn: 'root' })
export class AssociatedDemandAccountsGridColDef {
    public buttonRendererList: ButtonRendererModel[] = [
        {
            iconType: 'delete',
            onClick: this.onDelete.bind(this),
        }
    ];

    public default: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public columns: ColDef[] = [
        {
            field: 'multipleAcctTypeDesc',
            headerName: 'Associated Account Type',
            rowGroup: true,
            hide: true,
            suppressColumnsToolPanel: true,
            suppressFiltersToolPanel: true
        },
        {
            field: 'acctId',
            headerName: 'Account',
            filter: 'agTextColumnFilter',
            cellRendererSelector: (params) => ({
                component: AgGridHyperlinkCellRendererComponent,
                params: { iconType:this.getAccountTypeEnumValue(params.data.acctType), iconContext: 'secondary-btn' },
            }),
            suppressColumnsToolPanel:true,
            lockVisible: true,
            cellStyle: { 'padding-left': '60px' }
        },
        {
            field: 'personName',
            headerName: 'Customer Name',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'accountDescription',
            headerName: 'Account Description',
            filter: 'agTextColumnFilter',
        },
        // TODO: add ag right aligned cell
        {
            field: 'currentBalance',
            headerName: 'Balance',
            filter: 'agNumberColumnFilter',
            cellRenderer: AmountRendererComponent,
            cellClass: 'ag-right-aligned-cell',
            cellStyle: params => params.value <0 ? { color: 'red' }: null
        },
        {
            field: 'accountStatus',
            headerName: 'Status ',
            filter: 'agSetColumnFilter',
        },
        {
            field: 'actionButtons',
            headerName: '',
            sortable: false,
            filter: false,
            suppressFiltersToolPanel:true,
            pinned: 'right',
            minWidth: 125,
            cellRenderer: ButtonRendererComponent,
            cellRendererParams: {
                buttonList: this.buttonRendererList
            },
            suppressColumnsToolPanel: true,
        }
    ];

    public gridOptions: GridOptions = {
        columnDefs: this.columns,
        defaultColDef: this.default,
        rowSelection:'',
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        pagination: true,
        paginationPageSize: 25,
        paginationAutoPageSize: true,
        paginateChildRows: true,
        suppressRowClickSelection: false,
        groupDefaultExpanded: 1,
        groupDisplayType: 'groupRows'
    };

    onDelete(event: ButtonRendererClickParms): void {
        console.log('clicking Delete!!', event);
    }
    getAccountTypeEnumValue(enumString: any){
        const enumValue = (<any>AccountTypesIcons)[enumString];
        return enumValue === undefined ? '' : enumValue;
    }
};
