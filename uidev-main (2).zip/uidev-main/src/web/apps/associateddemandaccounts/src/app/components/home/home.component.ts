import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
// store
import * as AssociatedDemandAccountsActions from '../../store/action/associateddemandaccounts.action';
import * as AssociatedDemandAccountsSelector from '../../store/selector/associateddemandaccounts.selector';
// ag grid
import { GridOptions, GridReadyEvent, GridSizeChangedEvent } from 'ag-grid-community';
// libs
import { SelectedFaultError } from '@uid/uid-angular-controls';
import { ButtonText, DialogBoxText, DialogBoxType, FaultArrayMessages, FaultMsgRec, PageMode } from '@uid/uid-models';
import { UidAggridComponent, ButtonRendererClickParms, ButtonRendererComponent, ButtonRendererModel } from '@uid/uid-grid';
// store
import { Store } from '@ngrx/store';
// models
import { InquiryType } from '../../models/inquiry-type.model';
import { MultipleAccountInfoRecord } from '../../models/multiple-account-info-record.model';
import { AccountFunction } from '../../models/account-function.model';
import { AssociatedAccountType, AssociatedDemandAccountValueType } from '../../models/associated-demand-accounts.resource';
import { AssociatedDemandAccountsGridColDef } from './associateddemandaccount-grid-def';
import { AssociatedDemandAccountsModRequest } from '../../models/associated-demand-accounts-mod-request.model';
import { getAssociatedDemandAccountGroups } from '../associateddemandaccount/associateddemandaccount.function';
import { FormlyFormOptions } from '@ngx-formly/core';
import { AssociatedDemandAccountsAddRequest } from '../../models/associated-demand-accounts-add-request.model';
import { AssociatedDemandAccountFormModel } from '../../models/associated-demand-accounts-form.model';
import { AccountInfo } from '../../models/account-info.model';
import { FormGroup } from '@angular/forms';
import { AssociatedDemandAccountFormState } from '../../models/associated-demand-accounts-formstate.model';

@Component({
    selector: 'uid-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {
  @ViewChild(UidAggridComponent) uidAggrid!: UidAggridComponent;

  associatedDemandAccountValueTypes = AssociatedDemandAccountValueType;
  associatedAccountTypeEnum = AssociatedAccountType;
  pageModeEnum = PageMode;

  associatedDemandAccountsActions = AssociatedDemandAccountsActions;
  associatedDemandAccountsSelectors = AssociatedDemandAccountsSelector;
  // formly field config
  associatedDemandAccountGroups = getAssociatedDemandAccountGroups();
  associateDemandAccountFormState$!: Observable<AssociatedDemandAccountFormState>;

  multipleAccountInfoRecords$!: Observable<MultipleAccountInfoRecord[]>;
  addProtectionAccountTypes$!: Observable<InquiryType[]>;
  addAccountTypes$!: Observable<InquiryType[]>;
  customerAccountFunctions$!: Observable<AccountFunction[]>;
  pageMode$!: Observable<PageMode>;
  faultArrayMessages$!: Observable<FaultArrayMessages>;
  associatedDemandAccountForm: FormGroup = new FormGroup({});
  gridOptions: GridOptions = {
      onGridReady: (event) => this.onGridReady(event),
      onGridSizeChanged: (event) => this.onGridSizeChanged(event),
  };

  pageSize = 25;
  // this property is defined with partial model since associatedType property is set with initial value.
  associatedDemandAccountFormModel!: Partial<AssociatedDemandAccountFormModel>;

  frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
  };

  subs: Subscription[] = [];

  // showDialogBox displays the dialog box on cancel click and delete click .
  showDialogBox = false;
  // generic dialog box title display for delete and cancel click.
  dialogBoxTitle = '';
  // dialogBoxType defines the type of dialogbox like delete and cencel.
  dialogBoxType!: DialogBoxType;
  dialogBoxTypeEnum = DialogBoxType;
  // dialogBoxText contains the body of dialog box
  dialogBoxText: string[] = [];

  // this property is used to refer the added accounttype for protection account type.
  multipleAccountInfoRecords!: MultipleAccountInfoRecord[];

  showOverrideDialogBox = false;
  // this property used to show the unsaved dialog box.
  showUnsaveDialogBox = false;
  // this property holds the current row Index
  currentRowIndex = -1;
  // this property helps to show validation error.
  showValidationError = false;

  gridApi: any;
  // this property holds the deleted protection Account Info to display the information in delete pop up
  deleteProtectionAccountInfoRecord!: MultipleAccountInfoRecord;
  // this property helps to track if record is deleted.
  isRecordDelete = false;

  associateDemandAccountFormState!: AssociatedDemandAccountFormState;
  buttonTextEnum=ButtonText;
  dialogBoxTextEnum=DialogBoxText;

  constructor(private store: Store, private gridDef: AssociatedDemandAccountsGridColDef) {
      this.multipleAccountInfoRecords$ = this.store.select(this.associatedDemandAccountsSelectors.selectmultipleAccountInfoRecords);
      this.addProtectionAccountTypes$ = this.store.select(this.associatedDemandAccountsSelectors.selectAddProtectionAccountTypes);
      this.addAccountTypes$ = this.store.select(this.associatedDemandAccountsSelectors.selectAddAccountTypes);
      this.customerAccountFunctions$ = this.store.select(this.associatedDemandAccountsSelectors.selectCustomerAccountFunctions);
      this.pageMode$ = this.store.select(this.associatedDemandAccountsSelectors.selectPageMode);
      // formly options.
      this.associateDemandAccountFormState$ = this.store.select(this.associatedDemandAccountsSelectors.selectFormlyOptions);
      this.faultArrayMessages$ = this.store.select(this.associatedDemandAccountsSelectors.selectFaultMessages);
      this.mapGridButtons(gridDef);
      this.mapOnChangeFormFunction();
  }

  ngOnInit(): void {
      // assigning grid options
      this.gridOptions = Object.assign(this.gridOptions, this.gridDef.gridOptions);

      const subFaultArrayMessage = this.faultArrayMessages$.subscribe((faultMsgs) => {
          if (faultMsgs !== undefined) {
              this.showOverrideDialogBox = faultMsgs.errorArray.length < 1 && faultMsgs.faultArray.length > 0;
          }
      });
      const submultipleAccountInfoRecords = this.multipleAccountInfoRecords$.subscribe((accountInfoRecords) => {
          if (accountInfoRecords !== undefined) {
              this.multipleAccountInfoRecords = accountInfoRecords;
          }
      });

      const subAssociateDemandAccountFormState = this.associateDemandAccountFormState$.subscribe((associateDemandAccountFormState) => {
          if (associateDemandAccountFormState !== undefined) {
              this.associateDemandAccountFormState = associateDemandAccountFormState;
          }
      });

      this.subs.push(subFaultArrayMessage, submultipleAccountInfoRecords, subAssociateDemandAccountFormState);

      this.store.dispatch(this.associatedDemandAccountsActions.getAssociatedDemandAccountRecords({ request: {} as any }));
  }

  ngOnDestroy(): void {
      this.subs.forEach((sub) => sub.unsubscribe());
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
      event.api.sizeColumnsToFit();
  }

  onGridReady(event: GridReadyEvent) {
      if (!event || !event.api || !this.uidAggrid.uidGrid) {
          return;
      }
      this.gridApi = event.api;
      event.api?.closeToolPanel();
  }

  // mapping onchange function of drop down change.
  mapOnChangeFormFunction() {
      const associatedTypeFieldConfig = this.associatedDemandAccountGroups[0].fieldGroup?.find((x) => x.key === 'associatedType');
      // assign current function and instance to formly.
      if (associatedTypeFieldConfig?.props) {
          associatedTypeFieldConfig.props.change = this.getAddAssociatedTypeDropDownOptions;
          associatedTypeFieldConfig.props.change = associatedTypeFieldConfig.props.change.bind(this);
      }
  }

  // mapping the button click to delete function.
  mapGridButtons(gridDef: AssociatedDemandAccountsGridColDef): void {
      const deleteButton = gridDef.buttonRendererList.find((x: ButtonRendererModel) => x.iconType === 'delete');

      if (deleteButton) {
          deleteButton.onClick = this.deleteButtonClick.bind(this);
      }
  }

  // this event executes on click of view button in grid which nagivates to details screen
  deleteButtonClick(e: ButtonRendererClickParms) {
      // assign the deleted record to deleteProtectionAccountInforRecord to dispaly information in pop up.
      this.deleteProtectionAccountInfoRecord = e.rowData;
      this.dialogBoxType = this.dialogBoxTypeEnum.Delete;
      this.dialogBoxTitle = this.associatedDemandAccountValueTypes.deleteDialogBoxTitle;
      this.dialogBoxText = [];
      this.showDialogBox = true;
  }

  cancelButton() {
      this.dialogBoxType = this.dialogBoxTypeEnum.unsavedChanges;
      this.dialogBoxTitle = this.dialogBoxTextEnum.CancelDialogBoxTitle;
      this.dialogBoxText = [];
      this.dialogBoxText.push(this.dialogBoxTextEnum.CancelDialogBoxText);
      this.showDialogBox = true;
  }

  addAssociatedDemandAccountsRecord() {
      // resetting the validation error message.
      this.associatedDemandAccountForm.reset();
      this.associateDemandAccountFormState.submitted=false;

      this.associatedDemandAccountFormModel = {
          associatedType: 'ProtectionAccount',
          accountType: null,
      };

      // the call to get dropdown values are blocked when associatedType is null but add screen is not stopped display.
      if (this.associatedDemandAccountFormModel !== undefined && this.associatedDemandAccountFormModel.associatedType !== undefined && this.associatedDemandAccountFormModel.associatedType != null) {
          const addAssociatedDemandAccountRequest: AssociatedDemandAccountsAddRequest = {
              srchMsgRqHdr: {
                  trackingId: '',
                  institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
                  workstationId: '',
                  securityGroup: '',
                  maxRecords: '10',
                  cursor: '123'
              },
              acctId: '12',
              acctType: 'A',
              associatedAccountType: this.associatedDemandAccountFormModel.associatedType ?? '',
          };
          this.store.dispatch(this.associatedDemandAccountsActions.getAddDropDownsValues({ request: addAssociatedDemandAccountRequest }));
      }
      // default add screen is display
      this.store.dispatch(this.associatedDemandAccountsActions.togglePageMode({ pageMode: this.pageModeEnum.Add }));
  }

  // this function is used to dispatch delete action
  deleteAssociatedDemandAccountsRecord(faultArrayMessages: FaultMsgRec[] = []) {
      const associatedAccountType = this.uidAggrid.uidGrid.api.getDisplayedRowAtIndex(this.currentRowIndex)?.data?.multipleAcctTypeDesc;
      const associatedAcctId = this.uidAggrid.uidGrid.api.getDisplayedRowAtIndex(this.currentRowIndex)?.data?.acctId;
      const associatedAcctType = this.uidAggrid.uidGrid.api.getDisplayedRowAtIndex(this.currentRowIndex)?.data?.acctType;

      const deleteAssociatedDemandAccounts: AssociatedDemandAccountsModRequest = {
          srchMsgRqHdr: {
              trackingId: '',
              institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
              workstationId: '',
              securityGroup: '',
              maxRecords: '10',
              cursor: '123'
          },
          acctId: '12',
          acctType: 'A',
          associatedAccountInfoRecords: [{ accId: associatedAcctId, acctType: associatedAcctType }],
          associatedAccountType: associatedAccountType,
          dlt: true,
          errOvrRdInfoArray: faultArrayMessages,
      };
      this.isRecordDelete = true;
      this.store.dispatch(this.associatedDemandAccountsActions.deleteAssociatedDemandAccount({ request: deleteAssociatedDemandAccounts }));
  }

  // this condition executes on click of save in add and edit screen. faultArray is passed when user selected the
  // fault error messages displayed in override dialog box.
  saveAssociatedDemandAccounts(faultArrayMessages: FaultMsgRec[] = []) {
      // changing the formstate.
      if(this.associatedDemandAccountForm.invalid){
          this.associateDemandAccountFormState.submitted = true;
          return ;
      }

      const accountInfo: AccountInfo[] = [];
      if (this.associatedDemandAccountFormModel.associatedType === this.associatedAccountTypeEnum.ProtectionAccount) {
          const protectionTypes = this.multipleAccountInfoRecords.filter(
              (x) => x.multipleAcctTypeDesc === this.associatedAccountTypeEnum.ProtectionAccountDesc);
          if (protectionTypes !== undefined && protectionTypes.length > 0) {
              const arrayAccountInfo = protectionTypes.map((v) => ({ accId: v.acctId, acctType: v.acctType }));
              accountInfo.push(...arrayAccountInfo);
          }
      }
      accountInfo.push({ accId: this.associatedDemandAccountFormModel.accId ?? '', acctType: this.associatedDemandAccountFormModel.associatedType ?? '' });

      const addAssociatedDemandAccounts: AssociatedDemandAccountsModRequest = {
          srchMsgRqHdr: {
              trackingId: '',
              institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
              workstationId: '',
              securityGroup: '',
              maxRecords: '10',
              cursor: '123'
          },
          acctId: '12',
          acctType: 'A',
          associatedAccountInfoRecords: accountInfo ?? [],
          associatedAccountType: this.associatedDemandAccountFormModel.associatedType ?? '',
          dlt: false,
          errOvrRdInfoArray: faultArrayMessages,
      };
      this.store.dispatch(
          this.associatedDemandAccountsActions.addAssociatedDemandAccount({
              request: addAssociatedDemandAccounts,
          })
      );
  }

  dialogBoxClose(e: any) {
      if (e.detail === this.buttonTextEnum.Delete) {
          this.deleteAssociatedDemandAccountsRecord();
      }
      if (e.detail === this.buttonTextEnum.DonotSave) {
          this.store.dispatch(this.associatedDemandAccountsActions.togglePageMode({ pageMode: this.pageModeEnum.Inquiry }));
      }
      this.showDialogBox = false;
  }

  // this event will execute before closing of override dialog box
  // TODO : complete functionality for override dailog box will be implemented when screen is integrated with api.
  overridedialogBoxClose(selectedFaultError: SelectedFaultError) {
      if (selectedFaultError.clickAction === this.buttonTextEnum.Override) {
          this.saveAssociatedDemandAccounts(selectedFaultError.faultRecInfoArray);
      } else if (selectedFaultError.clickAction === this.buttonTextEnum.Cancel) {
      // resetting fault error message in store to show the override dialogbox for same error message again.
      // override dialogbox will not display if same error message is stored again in ngrx store.
          this.store.dispatch(this.associatedDemandAccountsActions.addFaultRecMessages({ faultRec: [] }));
      }
      this.showOverrideDialogBox = false;
  }

  // api call for getting dropdown info
  getAddAssociatedTypeDropDownOptions(field: any, $event: any) {
      const associatedAcctType = $event.value;
      const addAssociatedDemandAccountRequest: AssociatedDemandAccountsAddRequest = {
          srchMsgRqHdr: {
              trackingId: '',
              institutionId: '89a3d643-e1b1-41e3-aec7-bdac9703a802',
              workstationId: '',
              securityGroup: '',
              maxRecords: '10',
              cursor: '123'
          },
          acctId: '12',
          acctType: 'A',
          associatedAccountType: associatedAcctType,
      };
      this.store.dispatch(this.associatedDemandAccountsActions.getAddDropDownsValues({ request: addAssociatedDemandAccountRequest }));
  }
}
