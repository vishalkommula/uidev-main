import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface AssociatedDemandAccountsSearchRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId:       string;
    acctType:     string;
};
