import { Component, Input, SimpleChanges, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
// formly
import { FormlyFormOptions } from '@ngx-formly/core';

// functions
import * as BillDetailsFunction from './bill-details.function';
// ngrx store
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import * as BillInfoSelector from '../../../store/selectors/billInfo.selector';
import * as CommonActions from '../../../store/actions/common.action';
import * as BillFeeActions from '../../../store/actions/billfee.action';
import * as BillFeeSelector from '../../../store/selectors/billfee.selector';
import * as CommonSelector from '../../../store/selectors/common.selector';
// models
import { BillFormStateModel } from '../../../models/bill-info-formstate.model';
import { LnBilSrchRec } from '../../../models/loan-bill-search-record.model';
import { LnBilDeleteRequestModel } from '../../../models/loan-bill-delete-request.model';
import { LnBilInfoRecItem } from '../../../models/loan-bill-info-record-item.model';
import { LnBilModRequest } from '../../../models/loan-bill-mod-request.model';
import { LnBilAddRequestModel } from '../../../models/loan-billI-add-request.model';
import { billFeeValueTypes, FeesGridParentEnum } from '../../../models/bill-fee-enums';
import { GridCellSelectedRecord } from '../../../models/grid-cell-selected-data.model';
import { LnBilInfoResponse } from '../../../models/loan-bill-info-response.model';
// uid-utilities.
import { formatDate, unsubscribe } from '@uid/uid-utilities';
import { ActIntentType, DateFormatterType, ErrCat, PageMode, ResultInfoMessage, UserAction } from '@uid/uid-models';
import { SLLnFeeInfoRecItem } from '../../../models/sl-loan-fee-Info-record-item.model';
import { SelectedFaultError } from '@uid/uid-angular-controls';
import { LnStmtInfoRecItem } from '../../../models/loan-statement-info-record.model';
import { LnFeeSrchRequest } from '../../../models/loan-fee-search-request.model';

@Component({
    selector: 'uid-bill-details',
    templateUrl: './bill-details.component.html',
    styleUrls: ['./bill-details.component.scss'],
})
export class BillDetailsComponent implements OnChanges, OnInit, OnDestroy {
    @Input() pageMode!: PageMode;
    @Input() billDetails!: LnBilInfoResponse | null;
    // get bill due date
    billDueDt$!: Observable<string>;
    // assign the actions of bill action
    billInfoActions = BillInfoActions;
    commonActions = CommonActions;
    // assign the selector of bill selectors
    billInfoSelector = BillInfoSelector;
    // actions and selectors for bill fee
    billFeeSelect = BillFeeSelector;
    // common selector.
    commonSelector = CommonSelector;

    billFeeActions = BillFeeActions;
    // formly definitions
    billInfoForm = new FormGroup({});

    billInfoOptions: FormlyFormOptions = {};

    billInfoFields = BillDetailsFunction.getBillDetailFormField();
    statementInfoFields = BillDetailsFunction.getStatementDetailFormField();

    // this model is used to render the default value for properties in add screeen.
    addBillInfoModel!: LnBilInfoRecItem;

    // formState holds the state variable of formly
    formState$!: Observable<BillFormStateModel>;

    formState!: BillFormStateModel;

    // bill search info
    billSearchData$!: Observable<LnBilSrchRec | null>;

    // showDialogBox displays the dialog box on cancel click and delete click .
    showDialogBox = false;

    // generic dialog box title display for delete and cancel click.
    dialogBoxTitle = '';
    // dialogBoxType defines the type of dialogbox like delete and cencel.
    dialogBoxType = '';

    // dialogBoxText contains the body of dialog box
    dialogBoxText: string[] = [];
    billFeeData$!: Observable<SLLnFeeInfoRecItem[]>;
    // enums
    pageModeEnum = PageMode;
    feesGridParentEnum = FeesGridParentEnum;
    billFeeValues = billFeeValueTypes;
    dateFormatterType = DateFormatterType;

    // to how current date and time for delete confirmation
    currentDateTime = '';

    // get the form state of statement details
    statementDetailsFormState$: Observable<BillFormStateModel>;

    // to store previous state of print billing notice
    printBillingNotice = false;

    subscriptions: Subscription[] = [];
    // validationMessages is used to display the validation messages.
    validationMessages$!: Observable<ResultInfoMessage[]>;

    errCatEnum = ErrCat;
    UserActionEnum= UserAction;

    constructor(private store: Store) {
        this.formState$ = this.store.select(this.billInfoSelector.selectFormState);

        this.billDueDt$ = this.store.select(this.billInfoSelector.selectBillDueDt);

        this.billFeeData$ = this.store.select(this.billFeeSelect.selectBillFeeSearch);

        this.billSearchData$ = this.store.select(this.billInfoSelector.selectBillSearchByBillDueDt);

        this.statementDetailsFormState$ = this.store.select(this.billInfoSelector.selectStatementDetailsFormState);

        this.validationMessages$ = this.store.select(this.commonSelector.selectMessages);
    }
    ngOnInit(): void {
        const subformState = this.formState$.subscribe((state: BillFormStateModel) => (this.formState = state));

        this.subscriptions.push(subformState);
    }

    ngOnDestroy(): void {
        /**
         * form is retriving previous state of the user's interaction with the form like touched,pristine and dirty.
         * this is happening to formcontrols which are part of user interaction in previous state.
         * The billInfoForm.reset() method is used to reset all the form controls to their default values.
         * When this method is called, all the input fields, checkboxes, radio buttons, and drop-down lists in the form will be cleared and reset to their initial values.
         * it will reset the validation to inital state.
         */
        this.billInfoForm.reset();
        unsubscribe(this.subscriptions);
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes['pageMode']) {
            /**
             * form is retriving previous state of the user's interaction with the form like touched,pristine and dirty.
             * this is happening to formcontrols which are part of user interaction in previous state.
             * The billInfoForm.reset() method is used to reset all the form controls to their default values.
             * When this method is called, all the input fields, checkboxes, radio buttons, and drop-down lists in the form will be cleared and reset to their initial values.
             * it will reset the validation to inital state.
             */
            this.billInfoForm.reset();
            if (this.pageMode === PageMode.Add) {
                // form reset.
                this.bindBillInfoModelForAdd();
                this.store.dispatch(
                    this.billFeeActions.getFeeSearchRecords({
                        feeSearchRequest: {
                            shadowCapFeeOnly: false,
                        } as LnFeeSrchRequest,
                    })
                );
            }
        }
        if (changes['billDetails']) {
            this.printBillingNotice = this.billDetails?.lnBilInfoRec?.printbillingnotice ?? false;
        }
    }

    editBill() {
        // API Call is made to get the actIntentKey.
        this.store.dispatch(this.billInfoActions.getBillDetails({ dueDate : this.billDetails?.lnBilInfoRec.bilDueDt ?? '' , activityIntention: { actIntent: ActIntentType.Update } }));
    }

    deleteBill() {
        // to generate currentDateTime in 'MM/dd/yyyy t' format, options need to pass in localeString.
        const options: Intl.DateTimeFormatOptions = {
            month: '2-digit',
            day: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        };
        this.currentDateTime = new Date().toLocaleString('en-US', options).replace(',', '');
        this.dialogBoxType = billFeeValueTypes.deleteMsg;
        this.dialogBoxTitle = billFeeValueTypes.deleteDialogBoxTitle;
        this.dialogBoxText = [];
        this.showDialogBox = true;
    }
    cancelBill() {
        this.dialogBoxType = billFeeValueTypes.cancelMsg;
        this.dialogBoxTitle = billFeeValueTypes.cancelDialogBoxTitle;
        this.dialogBoxText = [];
        this.dialogBoxText.push(billFeeValueTypes.cancelDialogBoxText);
        this.showDialogBox = true;
    }

    dialogBoxClose(e: any) {
        if (e.detail === billFeeValueTypes.deleteMsg) {
            const loanBillDelReq = {
                bilDueDt: this.billDetails?.lnBilInfoRec?.bilDueDt ?? '',
            } as LnBilDeleteRequestModel;
            // setting the value for errOverRdInfo
            loanBillDelReq.errOvrRdInfoArray=[];

            this.store.dispatch(this.billInfoActions.deleteBillDetails({ deleteRequest: loanBillDelReq }));
        }
        if (e.detail === billFeeValueTypes.donotSave) {
            if (this.pageMode === PageMode.Edit) {
                // get billinfo by billduedate
                // this logic reverts all store update after user is clicking on don't save button in edit screen
                this.store.dispatch(this.billInfoActions.getBillDetails({ dueDate : this.billDetails?.lnBilInfoRec.bilDueDt ?? '', activityIntention: { actIntent: ActIntentType.ReadOnly } }));
            } else {
                this.store.dispatch(this.commonActions.updatePageMode({ pageMode: this.pageModeEnum.Inquiry }));
            }
        }
        this.showDialogBox = false;
    }
    // this event will execute before closing of override dialog box
    overrideDialogBoxClose(selectedFaultError: SelectedFaultError) {
        if (selectedFaultError.clickAction === billFeeValueTypes.overrideMsg) {
            this.saveBill(selectedFaultError.faultRecInfoArray);
        }
    }

    // bind the billInfoModel for add screen to set the initial values.
    bindBillInfoModelForAdd() {
        this.addBillInfoModel = {
            bilPrincAmt: 0,
            remBilPrincAmt: 0,
            bilIntAmt: 0,
            remBilIntAmt: 0,
            bilEscrwAmt: 0,
            remBilEscrwAmt: 0,
            bilLateChgAmt: 0,
            remBilLateChgAmt: 0,
            bilOtherChgAmt: 0,
            remBilOtherChgAmt: 0,
            totalBilled: 0,
            totalRemaining: 0,
            printbillingnotice: false,
            // set addBilDuedt to undefined to block the validation.
            addBilDueDt: undefined,
        } as LnBilInfoRecItem;
        // setting the initial value to lnFeeInfoRec
        this.addBillInfoModel.lnFeeInfoRec=[];
    }
    // save logic for edit and add save click
    saveBill(faultInfoArray: ResultInfoMessage[] = []) {
        if (this.pageMode === PageMode.Edit) {
            const loanbillinforeq = {
                activityIntention: {
                    actIntent: ActIntentType.Update,
                    actIntentKey: this.billDetails?.activityIntention?.actIntentKey,
                },
                lnBilInfoRec: this.billDetails ? this.billDetails.lnBilInfoRec : ({} as LnBilInfoRecItem),
                errOvrRdInfoArray: faultInfoArray,
            } as LnBilModRequest;

            this.store.dispatch(this.billInfoActions.updateBillDetails({ billModRequest: loanbillinforeq }));
        } else if (this.pageMode === PageMode.Add) {
            if (
                this.billInfoForm.get('addBilDueDt')?.hasError('addBilDueDtValidation') ||
                !this.addBillInfoModel?.addBilDueDt
            ) {
                this.formState.isSubmitted = true;
                return;
            }

            // formatting the add bill due date to ISO for posting in api
            if (this.addBillInfoModel?.addBilDueDt) {
                this.addBillInfoModel.bilDueDt = formatDate(
                    this.addBillInfoModel?.addBilDueDt ?? '',
                    DateFormatterType.IsoDateFormatter
                );
            }

            const loanBillAddReq = {
                lnBilInfoRec: { ...this.addBillInfoModel }, // shallow copy to avoid immutable refer excpetion,
                errOvrRdInfoArray: faultInfoArray,
            } as LnBilAddRequestModel;

            // dispatching the add bill details action to post updated data to api.
            this.store.dispatch(this.billInfoActions.addBillDetails({ billAddRequest: loanBillAddReq }));
        }
    }

    // add and remove selected fee record in attached fee of bill add screen.
    // this logic update the late Charges and Other Charges of bill info model when user selects checkbox of respective charge types.
    selectedFeeRecord(event: GridCellSelectedRecord<SLLnFeeInfoRecItem>) {
        const index =
            this.addBillInfoModel?.lnFeeInfoRec.length>0
                ? this.addBillInfoModel?.lnFeeInfoRec.findIndex((x) => x.lnFeeId === event?.selectedRecord.lnFeeId)
                : -1;

        if (event.selectedStatus && index === -1) {
            // FeeID alone is sent to api.
            this.addBillInfoModel?.lnFeeInfoRec.push({ lnFeeId: event.selectedRecord.lnFeeId } as SLLnFeeInfoRecItem);
        } else if (!event.selectedStatus && index !== -1) {
            this.addBillInfoModel?.lnFeeInfoRec.splice(index, 1);
        }
        // this switch cases is used to update the respective Billed and remaining fields based on selecting checkbox.
        switch (event.selectedRecord?.loanFeeCategory) {
        case billFeeValueTypes.lateCharges:
            this.setSelectedFeeRecord(
                billFeeValueTypes.lateChargeProperties,
                billFeeValueTypes.feeRecordProperties,
                event
            );
            break;
        case billFeeValueTypes.otherCharges:
            this.setSelectedFeeRecord(
                billFeeValueTypes.OtherChargeProperties,
                billFeeValueTypes.feeRecordProperties,
                event
            );
            break;
        case billFeeValueTypes.FinancialCharges:
            this.setSelectedFeeRecord(
                billFeeValueTypes.FinancialChargeProperties,
                billFeeValueTypes.feeRecordProperties,
                event
            );
            break;
        }
    }

    // bill info model change
    billInfoModelChange(model: LnBilInfoRecItem) {
        this.calTotalBilled(model);
        this.calTotalRemaining(model);
        if (this.pageMode === PageMode.Edit) {
            model.bilDueDt = formatDate(model.bilDueDt ?? '', DateFormatterType.IsoDateFormatter);
            model.bilCrtDt = formatDate(model.bilCrtDt ?? '', DateFormatterType.IsoDateFormatter);
            // match dateTime billDueDt.
            model.bilDueDt = model.bilDueDt + 'T00:00:00';
            this.store.dispatch(this.billInfoActions.updateBillInfoModel({ updateBillInfoModel: model }));
        }
    }
    /**
     * billInfoModelChange cannot be reused as model that is bound to statement details formly, so created a method to detect model change.
     * LnStmtInfoRecItem is assign to the billDetails before dispatching the event.
     */
    statementDetailsModelChange(model: LnStmtInfoRecItem) {
        if (this.billDetails && this.billDetails.lnBilInfoRec) {
            this.billDetails.lnBilInfoRec.bilDueDt = formatDate(
                this.billDetails.lnBilInfoRec.bilDueDt ?? '',
                DateFormatterType.IsoDateFormatter
            );
            // match dateTime billDueDt.
            this.billDetails.lnBilInfoRec.bilDueDt = this.billDetails.lnBilInfoRec.bilDueDt + 'T00:00:00';
            this.billDetails.lnBilInfoRec.lnStmtInfoRec = { ...model };
            this.store.dispatch(
                this.billInfoActions.updateBillInfoModel({ updateBillInfoModel: this.billDetails.lnBilInfoRec })
            );
        }
    }

    calTotalBilled(model: any) {
        model.totalBilled =
            model.bilPrincAmt + model.bilIntAmt + model.bilEscrwAmt + model.bilLateChgAmt + model.bilOtherChgAmt;
        this.billInfoForm.patchValue({ totalBilled: model.totalBilled });
    }
    calTotalRemaining(model: any) {
        model.totalRemaining =
            model.remBilPrincAmt +
            model.remBilIntAmt +
            model.remBilEscrwAmt +
            model.remBilLateChgAmt +
            model.remBilOtherChgAmt;
        this.billInfoForm.patchValue({ totalRemaining: model.totalRemaining });
    }

    setSelectedFeeRecord(
        billInfoFields: string[],
        selectedFeeRecordFields: string[],
        event: GridCellSelectedRecord<SLLnFeeInfoRecItem>
    ) {
        for (let i = 0; i < billInfoFields.length; i++) {
            const field: string = billInfoFields[i];
            if (event.selectedStatus) {
                (this.addBillInfoModel as any)[field] += (event.selectedRecord as any)[selectedFeeRecordFields[i]];
            } else {
                (this.addBillInfoModel as any)[field] -= (event.selectedRecord as any)[selectedFeeRecordFields[i]];
            }
            this.billInfoForm.get(field)?.patchValue((this.addBillInfoModel as any)[field]);
        }
    }
}
