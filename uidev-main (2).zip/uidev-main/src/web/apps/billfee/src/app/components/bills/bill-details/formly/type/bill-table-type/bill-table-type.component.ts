import { Component } from '@angular/core';
import { FieldType, FormlyFieldConfig } from '@ngx-formly/core';
import { PageMode } from '@uid/uid-models';

@Component({
    selector: 'uid-bill-table-type',
    templateUrl: './bill-table-type.component.html',
    styleUrls: ['./bill-table-type.component.scss']
})
export class BillTableTypeComponent extends FieldType  {
    formlyfields: FormlyFieldConfig[]=[];
    pageModeEnum=PageMode;

    constructor(){
        super();
    }

}
