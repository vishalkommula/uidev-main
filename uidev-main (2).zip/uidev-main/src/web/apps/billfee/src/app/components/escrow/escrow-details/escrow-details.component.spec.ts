import { BillFeeModulesEnum } from '../../../models/bill-fee-enums';
import { EscrowDetailsComponent } from './escrow-details.component';
import escrowMockData from '../../../mock-data/loanBillescrowResponse.mock.json';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { PageMode } from '@uid/uid-models';
import { GridReadyEvent } from 'ag-grid-community';

jest.useFakeTimers();
jest.spyOn(global, 'setTimeout');

let component: EscrowDetailsComponent;

const escrowActionsMock = {
    getEscrow: jest.fn(),
    saveEscrow:jest.fn(),
    updateEscrowDetails:jest.fn(),
    updateEscrowBalance:jest.fn()
};
const billActionsMock = {
    updateBillInfoEscrowDetail:jest.fn(),
    updateBillInfoEscrowModel:jest.fn(),
    updateEscrowBalance:jest.fn(),
    updateBillInfoEscrowBalance: jest.fn()
};
const escrowSelectorMock ={
    selectEscrowDetails:jest.fn(),
};
const escrowGridDefMock = {
    readonlyColumns:jest.fn(),
    default:jest.fn(),
    defaultEditableScreen:jest.fn(),
    editableColumns:jest.fn(),

    gridOptions:{
        stopEditingWhenCellsLoseFocus:true,
        singleClickEdit : true,
        rowHeight:2,
        readOnlyEdit:true,
        onGridReady: (event: any) => jest.fn(event),
        onGridSizeChanged: (event: any) => jest.fn(event),
        onFirstDataRendered: (event: any) => jest.fn(event),
        onCellEditRequest: (event: any) => jest.fn(event),
        onCellFocused: (event: any) => jest.fn(event),
    }
};
const router = {
    getCurrentNavigation:jest.fn(),
    navigate:jest.fn()
};
const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() =>({
        subscribe:jest.fn(),
    })),
};
describe('EscrowComponent', () => {
    beforeEach(() => {
        component = new EscrowDetailsComponent(storeMock as any,escrowGridDefMock as any,router as any);
        component.escrowActions = escrowActionsMock as any;
        component.escrowSelector = escrowSelectorMock as any;
        component.billInfoActions = billActionsMock as any;
        if(component.gridOptions.onGridReady){
            component.gridOptions.onGridReady({ api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn() } } as any);
        }
        if(component.gridOptions.onFirstDataRendered){
            component.gridOptions.onFirstDataRendered({} as any);
        }
        if(component.gridOptions.onCellValueChanged){
            component.gridOptions.onCellValueChanged({ data: { balFldAff: '1', amt: 2 }, colDef: { field: 'amt' }, newValue: 12, oldValue: 2, balFldAff: '1' } as any);
        }
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('data should be fetched on oninit', () => {
        component.ngOnInit();
        const actualValue = component.gridOptions;
        const expectedValue = escrowGridDefMock.gridOptions;
        expect(actualValue).toMatchObject(expectedValue);
    });
    it('screen type should set when passing the page type', ()=>{
        component.pageType = 'bill';
        expect(component.screenType).toBe('bill');
    });
    it('ngOnChanges() method should be execute when the escrowPageMode is inquiry', () => {
        const changes = {
            escrowPageMode : PageMode.Inquiry
        } as any;
        component.escrowPageMode = PageMode.Inquiry;
        component.gridOptions.defaultColDef = escrowGridDefMock.default as any;
        component.gridOptions.columnDefs = escrowGridDefMock.readonlyColumns as any;
        component.gridOptions = {
            stopEditingWhenCellsLoseFocus:true,
            singleClickEdit : true,
            readOnlyEdit:true,
            onDisplayedColumnsChanged: (event: any) => jest.fn(event),
            onFirstDataRendered: (event: any) => jest.fn(event),
            api: {
                stopEditing:jest.fn()
            }
        } as any;

        // const event:
        component.gridApi = { setColumnDefs: jest.fn(), setDefaultColDef: jest.fn(), setSuppressRowClickSelection: jest.fn(),
            deselectAll: jest.fn(), clearFocusedCell: jest.fn() } as any;
        component.ngOnChanges(changes);
        const expectedValue = PageMode.Inquiry;
        const escrowColDef = escrowGridDefMock.default as any;
        const escrowReadOnly = escrowGridDefMock.readonlyColumns as any;
        expect(component.gridApi).not.toBeUndefined();
        expect(component.gridApi.setColumnDefs).toBeCalledWith(escrowReadOnly);
        expect(component.gridApi.setDefaultColDef).toBeCalledWith(escrowColDef);
        expect(component.gridApi.setSuppressRowClickSelection).toBeCalledWith(true);
        expect(component.escrowPageMode).toStrictEqual(expectedValue);
        expect(component.gridOptions.defaultColDef).toStrictEqual(escrowColDef);
        expect(component.gridOptions.columnDefs).toStrictEqual(escrowReadOnly);
    });
    it('ngOnChanges() method should be execute when the pagemode is the edit', () => {
        const changes = {
            escrowPageMode:PageMode.Edit
        } as any;
        component.escrowPageMode = PageMode.Edit;
        component.gridOptions = {
            stopEditingWhenCellsLoseFocus:true,
            singleClickEdit : true,
            readOnlyEdit:true,
            onFirstDataRendered: (event: any) => jest.fn(event),

        };
        component.gridOptions.defaultColDef = escrowGridDefMock.defaultEditableScreen as any;
        component.gridOptions.columnDefs = escrowGridDefMock.editableColumns as any;
        component.gridApi = { setColumnDefs: jest.fn(), setDefaultColDef: jest.fn(), setSuppressRowClickSelection: jest.fn(), } as any;
        component.ngOnChanges(changes);
        const expectedValue = PageMode.Edit;
        const escrowColDef = escrowGridDefMock.defaultEditableScreen as any;
        const escrowEditOnly = escrowGridDefMock.editableColumns as any;
        expect (component.gridApi.setColumnDefs).toBeCalledWith(escrowEditOnly);
        expect (component.gridApi.setDefaultColDef).toBeCalledWith(escrowColDef);
        expect(component.gridApi.setSuppressRowClickSelection).toBeCalledWith(false);
        expect(component.escrowPageMode).toStrictEqual(expectedValue);
        expect(component.gridOptions.defaultColDef).toStrictEqual(escrowColDef);
        expect(component.gridOptions.columnDefs).toStrictEqual(escrowEditOnly);
    });
    it('ngonChanges() method should be execute escrow data', ()=>{
        const changes = {
            escrowData:{
                escrowInfo:{
                    nonEscrwPmt:767,
                    nonEscrwPmtRem:565
                }
            }
        } as any;
        component.escrowData = changes.escrowData;
        component.ngOnChanges(changes);
        const expectedValue = changes.escrowData;
        expect(component.escrowDetails).toEqual(expectedValue);
    });
    it('onGridReady() method should be execute', () => {
        const event: GridReadyEvent = {
            api: {
                closeToolPanel: jest.fn(),
                sizeColumnsToFit: jest.fn(),
                getRowNode: jest.fn().mockReturnValue({ setSelected: jest.fn() })
            }
        } as any;
        component.onGridReady(event);
        const actualValue = component.gridApi;
        const expectedValue = event.api;
        expect(actualValue).toEqual(expectedValue);
    });
    /*it('onGridSizeChanged() method should be execute', () => {
      const event = {
        api:{
          sizeColumnsToFit:jest.fn()
        }
      } as any;
      component.onGridSizeChanged(event);
      const actualValue = event.api.sizeColumnsToFit;
      expect(actualValue).toBeCalled();
    });*/
    it('onCellValueChanged() method screen type escrow should be execute', () =>{
        const event = {
            newValue:1,
            oldValue:0,
            data:{
                balFldAff: 1,
                escrwPmtAmt: 1,
                escrwPmtAmtRem: 47761,
                escrwPmtBalDesc: ''
            },
            colDef:{
                field:'escrwPmtAmt'
            },
            value:566
        } as any;
        component.screenType = BillFeeModulesEnum.escrow;
        component.onCellValueChanged(event);
        const cellModifiedData = {
            uniqueRowIdentifier: event.data.balFldAff,
            oldData: event.oldValue,
            newData: event.newValue,
            oldRowData: event.data,
            newRowData: event.data,
            field: event.colDef.field,
        } as any;
        const expectedValue = BillFeeModulesEnum.escrow;
        expect(component.screenType).toEqual(expectedValue);
        expect(escrowActionsMock.updateEscrowBalance).toBeCalledWith({ cellModifiedData: cellModifiedData });
        expect(storeMock.dispatch).toBeCalled();
        // expect(escrowActionsMock.updateEscrowBalance).toHaveBeenCalledTimes(1);
    });
    it('onCellValueChanged() method screen type bill escrow should be execute', () =>{
        const event = {
            newValue:1,
            oldValue:0,
            data:{
                balFldAff: 1,
                escrwPmtAmt: 1,
                escrwPmtAmtRem: 47761,
                escrwPmtBalDesc: ''
            },
            colDef:{
                field:'escrwPmtAmt'
            },
            value:566
        } as any;
        component.screenType = BillFeeModulesEnum.billsEscrow;
        component.billDueDt = escrowMockData.lnBilEscrwInfoRec.billDt;
        component.onCellValueChanged(event);
        const cellModifiedData = {
            uniqueRowIdentifier: event.data.balFldAff,
            oldData: event.oldValue,
            newData: event.newValue,
            oldRowData: event.data,
            newRowData: event.data,
            field: event.colDef.field,
        } as any;
        const expectedValue = BillFeeModulesEnum.billsEscrow;
        expect(component.screenType).toEqual(expectedValue);
        expect(billActionsMock.updateBillInfoEscrowBalance).toBeCalledWith({ updateBillInfoEscrowModel: cellModifiedData,billDueDt:escrowMockData.lnBilEscrwInfoRec.billDt });
        expect(storeMock.dispatch).toBeCalled();
        // expect(billActionsMock.updateBillInfoEscrowBalance).toHaveBeenCalledTimes(1);
    });

    it('loadBillDetailsForDueDate() method should be execute', () => {
        component.escrowDetails = escrowMockData.lnBilEscrwInfoRec;
        component.loadBillDetailsForDueDate();
        expect(router.navigate).toBeCalledTimes(1);
    });

    it('onFirstDataRendered() method should be execute', () => {
        const event = { api: { ensureIndexVisible:jest.fn(),
            getAllDisplayedColumns:jest.fn(),
            ensureColumnVisible:jest.fn(),
            setFocusedCell:jest.fn() } } as any;
        component.onFirstDataRendered(event);
        // document.addEventListener = jest.fn((event, callback) => {
        //     events[event] = callback;
        // });
    });

    it('onCellFocused() method should be execute', () => {
        const event = { rowIndex:123,column:{ getColId:jest.fn() },api: { ensureIndexVisible:jest.fn(),
            getAllDisplayedColumns:jest.fn(),
            ensureColumnVisible:jest.fn(),
            setFocusedCell:jest.fn() } } as any;
        component.gridApi = { setColumnDefs: jest.fn(), setDefaultColDef: jest.fn(), setSuppressRowClickSelection: jest.fn(),
            deselectAll: jest.fn(), clearFocusedCell: jest.fn(),
            startEditingCell:jest.fn(),getCellEditorInstances:jest.fn().mockReturnValue([{ type:'AgGridPInputnumberEditorComponent',selectCellValues:jest.fn() }]) } as any;
        component.onCellFocused(event);
        jest.advanceTimersByTime(100);
        // document.addEventListener = jest.fn((event, callback) => {
        //     events[event] = callback;
        // });
    });

    it('escrowInfoModelChange should esecute for screen type escrow',() => {
        component.pageType = BillFeeModulesEnum.escrow;
        component.escrowInfoModelChange({} as any);
        expect(escrowActionsMock.updateEscrowDetails).toBeCalled();
    });

    it('escrowInfoModelChange should esecute for screen type bills',() => {
        component.pageType = BillFeeModulesEnum.billsEscrow;
        component.escrowInfoModelChange({} as any);
        expect(billActionsMock.updateBillInfoEscrowDetail).toBeCalled();
    });
});


