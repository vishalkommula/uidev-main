import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { errorMessageDisplay } from '@uid/uid-utilities';

export function getEscrowDetailsFormField(): FormlyFieldConfig[] {
    return  [
        {
            key: 'nonEscrwPmtRem',
            type: FormDataTypeEnum.number,
            props: {
                label:'Payment Remaining',
                inputStyleClass: 'rui-form-control',
                prefix: '$',
                inputLength: 13,
                labelClasses:'col-md-6',
                valueClasses:'col-md-6',
                minFractionDigits: 2,
                maxFractionDigits: 2,
                attributes: {
                    'data-test-id': 'escrowDetails-nonEscrwPmtRem-01',
                },
                placeholder: '0.00'
            },
            expressions: {
                'validation.show': errorMessageDisplay,
            },
        },
        {
            key: 'nonEscrwPmt',
            type: FormDataTypeEnum.number,
            props: {
                label:'Payment Due',
                inputStyleClass: 'rui-form-control',
                inputLength: 13,
                minFractionDigits: 2,
                maxFractionDigits: 2,
                labelClasses:'col-md-6',
                valueClasses:'col-md-6',
                prefix: '$',
                attributes: {
                    'data-test-id': 'escrowDetails-nonEscrwPmt-01',
                },
                placeholder: '0.00'
            },
            expressions: {
                'validation.show': errorMessageDisplay,
            },
        },
    ];
}
