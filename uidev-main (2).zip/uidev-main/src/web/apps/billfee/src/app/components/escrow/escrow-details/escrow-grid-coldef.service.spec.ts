import { EscrowgridcoldefService } from './escrow-grid-coldef.service';

let service: EscrowgridcoldefService;

describe('EscrowgridcoldefService', () => {

    beforeEach(() => {
        service = new EscrowgridcoldefService();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
