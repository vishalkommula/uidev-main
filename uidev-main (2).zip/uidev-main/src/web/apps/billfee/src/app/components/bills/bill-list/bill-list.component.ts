import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { formatDate } from '@angular/common';
// store
import { Store } from '@ngrx/store';
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import * as CommonActions from '../../../store/actions/common.action';
import * as BillInfoSelectors from '../../../store/selectors/billInfo.selector';
// libs
import { getUTCDate } from '@uid/uid-utilities';
import { DateFormatterType, PageMode } from '@uid/uid-models';
// models
import { LnBilSrchFilterModel } from '../../../models/loan-bill-search-filter.model';
import { LnBilSrchRec } from '../../../models/loan-bill-search-record.model';
import { billFeeValueTypes, BillStatus } from '../../../models/bill-fee-enums';

@Component({
    selector: 'uid-bill-list',
    templateUrl: './bill-list.component.html',
    styleUrls: ['./bill-list.component.scss'],
})
export class BillListComponent implements OnInit {

    // p-calendar control
  @ViewChild('calendar') public calendar: any;

  // get the bill due date from bill dashboard component
  @Input() billDueDate!: string;
  // get the page mode from bill dashboard component
  @Input() pageMode!: PageMode;

  // output emitter to show unsaved changes dialog box
  @Output() showUnsavedChangesDialogBox = new EventEmitter<boolean>();
  // output emitter to send current selected bill due date to bill dashboard component
  @Output() billDueDateSelectedEvent = new EventEmitter<string>();

  private  _billsList: LnBilSrchRec[] | null | undefined;

  @Input() set billsList(billSearchArray: LnBilSrchRec[] | null | undefined){
      /**
     * sett calls  whenever billSearchArray is refreshed in store.
     */
      this._billsList=billSearchArray;
      /**
         * reseting the filter option when billSearchArray refreshed and filter is applied.
         */
      if(this.isFilterApplied){
          this.resetFilter(false);
          return ;
      }
      // setCurrentSelectedBillDueDate set the currentSelectedBillDueDate to higlight the record in rui-master-list.
      this.setCurrentSelectedBillDueDate();
  }

  get billsList(): LnBilSrchRec[] | null | undefined {
      return this._billsList;
  }

  filteredBillList: LnBilSrchRec[] | null | undefined;;
  filterRecordModel: LnBilSrchFilterModel = {} as LnBilSrchFilterModel;
  isBillInfoFormDirty=false;
  previousSelectedBillDueDt= '';
  currentSelectedBillDueDate = '';
  skipFormValidation = false;
  // to enable or disable apply and reset action buttons in bill lister filter popup
  isFilterActionButtonsDisabled = true;
  // get the bill info actions
  billInfoActions = BillInfoActions;
  commonActions = CommonActions;
  // get the bill info selectors
  billInfoSelectors = BillInfoSelectors;
  // enums
  billFeeValues = billFeeValueTypes;
  dateFormatterType = DateFormatterType;

  hideMenu = false;
  pageModeEnum = PageMode;
  billStatusEnum = BillStatus;
  /**
   * isFilterApplied track whether filter is applied to billlist.
   * isFilterApplied set to true when clicked on apply button in filter pop up.
   * isFilterApplied set to false when billList refreshed or reset button is clicked in filter pop up.
   */
  isFilterApplied=false;

  constructor(private store: Store) {
      this.resetFilterRecordModel();
  }

  ngOnInit(): void {
      if(!this.billDueDate){
          this.getBillList();
      }
  }

  setCurrentSelectedBillDueDate() {
      if (this.billsList && this.billsList.length > 0) {
          this.higlightRecordOnRefresh();
      }else if (this.currentSelectedBillDueDate !== '') {
          this.resetSelectedBillDueDate();
      }
  }

  /**
   * highlight the record after billList refreshed.
   * _billsList has corresponding bill detail record , billDueDt is extracted from the bill detail record and highligh the record.
   * when bill is deleted then _billsList have bill detail record for first record.
   * when bill is updated then _billsList have bill detail record to corresponding billDueDt.
   * when bill is added then  _billsList have bill detail record for first record.
   */
  higlightRecordOnRefresh(){
      // set the selected bill due date from escrow and fee.
      if(this.billDueDate){
          this.currentSelectedBillDueDate = this.billDueDate ?? '';
          this.billDueDate ='' ;
          return;
      }
      const selectedBillDueDt =this._billsList?.find((x) => (x.lnBilInfoRec !==null && x.lnBilInfoRec?.bilDueDt !==null))?.lnBilInfoRec?.bilDueDt;
      if(selectedBillDueDt){
          // setting the initial values
          this.previousSelectedBillDueDt='';
          this.currentSelectedBillDueDate = '';
          /**
             *rui-master-list is not highlighing the already selected record after refreshing the data.
             so, we need to set initial values , after update we are setting billDueDt to  currentSelectedBillDueDate
             */
          setTimeout(() => {
              this.currentSelectedBillDueDate = selectedBillDueDt ?? '';
          },);
      }
  }

  // If Filter didnt return rows. i.e., When no rows are available to display in list.
  resetSelectedBillDueDate(){
      this.currentSelectedBillDueDate = '';
      this.previousSelectedBillDueDt = '';
      this.billDueDateSelectedEvent.emit('');
  };

  // to display add button
  // add button is hidden for specific type of loans, that logic will be implemented in future.
  isAddBillAllowed() {
      return true;
  }

  // to get total over due days for a bill
  getOverdueDays(date?: string) {
      const dueDateUTC = getUTCDate(new Date(formatDate(date as string, 'yyyy-MM-dd', 'en-US')));
      const currentDateUTC =  getUTCDate(new Date());
      const passDueDays = ((currentDateUTC.getTime() - dueDateUTC.getTime()) / (1000 * 3600 * 24)).toFixed(0);
      return passDueDays;
  }

  // get the selected bill due date from master list and send to bill dashboard component
  // event.detail is the selected bill due date from master list
  getDataForSelectedBillDueDate(event: any) {
      if (event.detail !== '' && this.previousSelectedBillDueDt !== event.detail) {
          if (this.skipFormValidation || !(this.pageMode === PageMode.Edit)) {
              this.skipFormValidation = false;
              this.currentSelectedBillDueDate = event.detail;
              this.previousSelectedBillDueDt = this.currentSelectedBillDueDate;
              this.billDueDateSelectedEvent.emit(event.detail);
          } else {
              // to show unsaved changes dialog box when bill details are not saved
              // this.showUnsavedChangesDialogBox.emit(true);
              this.currentSelectedBillDueDate = '';
              // there are no properties to stop selecting the row in rui master list
              setTimeout(() => {
                  this.currentSelectedBillDueDate = this.previousSelectedBillDueDt;
              }, 50);
          }
      }
  }

  // click on add new bill button
  addBill(event: any) {
      if(this.pageMode!==PageMode.Edit){
          const element: any = document.getElementById('DisplayBlock');
          element.scrollToTop(event);
          this.store.dispatch(this.commonActions.updatePageMode({ pageMode: PageMode.Add }));
      }
  }

  // reset the filter model data
  resetFilterRecordModel() {
      this.filterRecordModel = {} as LnBilSrchFilterModel;
  }

  // click on apply button from filter popup
  applyFilter() {
      this.hideMenu = true;
      this.isFilterApplied = true;
      this.filteredBillList = this.applyFilterOnBillSearch();
      /**
       * higlightling the first record after applying ftiler.
       * if filteredBillList is undefined or null then resetSelectedBillDueDate method is called to set billDueDt to empty,to not show bill details on right-side.
       */
      if(this.filteredBillList && this.filteredBillList.length >0){
          this.currentSelectedBillDueDate = this.filteredBillList[0].lnBilSrchRecItem?.bilDueDt ?? '';
      }else if (this.currentSelectedBillDueDate !== '') {
          this.resetSelectedBillDueDate();
      }
  }
  // click on reset button from filter popup
  /**
   *
   * @param isResetButtonClick set to true when reset button is clicked in filter pop up.
   * if isResetButtonClick is true then first record in billList is highlighted.
   * if isResetButtonClick is false then the corresponding bill details fetched billDueDt is highlighted.
   */
  resetFilter(isResetButtonClick: boolean) {
      this.hideMenu = true;
      this.resetFilterRecordModel();
      this.isFilterActionButtonsDisabled = true;
      this.isFilterApplied = false;
      if(isResetButtonClick){
      // Setting first record to be higlighted on click of reset button in filter pop up.
          if(this._billsList && this._billsList.length >0){
              this.currentSelectedBillDueDate = this._billsList[0].lnBilSrchRecItem?.bilDueDt ?? '';
          }
      }else{
          this.setCurrentSelectedBillDueDate();
      }
  }

  // to close p-calendar popup
  onClickPCalendarPopup() {
      if (this.filterRecordModel.dateRange !== undefined && this.filterRecordModel.dateRange[1]) {
      // If second date is selected
          this.calendar.overlayVisible = false;
      }
  }

  // detect the changes in filter model to enable/disable the apply and reset buttons in filter popup.
  filterModelChange(){
      this.isFilterActionButtonsDisabled = true;
      // p-calendar input field validation
      if(this.filterRecordModel.dateRange !== undefined && this.filterRecordModel.dateRange !== null){
      // check if the to date is selected
          if(this.filterRecordModel.dateRange[1] === null){
              this.isFilterActionButtonsDisabled = true;
              return;
          }
          this.isFilterActionButtonsDisabled = false;
          return;
      }
      // payment amount from input field validation
      if(this.filterRecordModel.paymentAmountFrom !== undefined && this.filterRecordModel.paymentAmountFrom !== null && this.filterRecordModel.paymentAmountFrom > 0){
          this.isFilterActionButtonsDisabled = false;
          return;
      }
      // payment amount to input field validation
      if(this.filterRecordModel.paymentAmountTo !== undefined && this.filterRecordModel.paymentAmountTo !== null && this.filterRecordModel.paymentAmountTo > 0){
          this.isFilterActionButtonsDisabled = false;
          return;
      }
  }

  /**
   * applyFilterOnBillSearch cannot able to handle in selector since new array is passed after filter is applied
    which is resulted in calling subscribe multiple times whenever store is updated.
   * filterRecordModel is applied on _billsList after shallow Copy.
   * @returns filterBillList when _billsList is undefined.
   */
  applyFilterOnBillSearch(){
      if (this._billsList && this._billsList.length > 1) {
          let filteredBillList = [...this._billsList ];
          // reset
          if (
              this.filterRecordModel.paymentAmountFrom !== undefined &&
            this.filterRecordModel.paymentAmountFrom === 0 &&
            this.filterRecordModel.paymentAmountTo !== undefined &&
            this.filterRecordModel.paymentAmountTo === 0 &&
            this.filterRecordModel.dateRange !== undefined &&
            this.filterRecordModel.dateRange.length !== 2
          ) {
              return this._billsList ;
          }
          // filter payment amount from
          if (
              this.filterRecordModel.paymentAmountFrom !== undefined &&
            this.filterRecordModel.paymentAmountFrom !== null &&
            this.filterRecordModel.paymentAmountFrom !== 0
          ) {
              filteredBillList  =
                this.filterRecordModel.paymentAmountFrom !== 0
                    ? filteredBillList .filter((bill) => {
                        if (
                            bill.lnBilSrchRecItem?.orgTotAmt !== undefined &&
                              this.filterRecordModel.paymentAmountFrom !== undefined
                        ) {
                            return bill.lnBilSrchRecItem.orgTotAmt >= this.filterRecordModel.paymentAmountFrom;
                        }
                        return bill;
                    })
                    : filteredBillList ;
          }
          // filter payment amount to
          if (
              this.filterRecordModel.paymentAmountTo !== undefined &&
            this.filterRecordModel.paymentAmountTo !== null &&
            this.filterRecordModel.paymentAmountTo !== 0
          ) {
              filteredBillList  =
                this.filterRecordModel.paymentAmountTo !== 0
                    ? filteredBillList .filter((bill) => {
                        if (
                            bill.lnBilSrchRecItem?.orgTotAmt !== undefined &&
                              this.filterRecordModel.paymentAmountTo !== undefined
                        ) {
                            return bill.lnBilSrchRecItem.orgTotAmt <= this.filterRecordModel.paymentAmountTo;
                        }
                        return bill;
                    })
                    : filteredBillList ;
          }
          // filter payment due date
          if (
              this.filterRecordModel.dateRange !== undefined &&
            this.filterRecordModel.dateRange !== null &&
            this.filterRecordModel.dateRange.length === 2
          ) {
              // get from and to dates without time
              const fromDate = getUTCDate(new Date(formatDate(this.filterRecordModel.dateRange[0], 'yyyy-MM-dd', 'en-US')));
              const toDate = getUTCDate(new Date(formatDate(this.filterRecordModel.dateRange[1], 'yyyy-MM-dd', 'en-US')));
              filteredBillList  =
                this.filterRecordModel.dateRange.length === 2
                    ? filteredBillList .filter((bill) => {
                        if (this.filterRecordModel.dateRange !== undefined && bill.lnBilSrchRecItem?.bilDueDt !== undefined) {
                            // get bill due date without time
                            const billDueDate = getUTCDate(new Date(formatDate(bill.lnBilSrchRecItem.bilDueDt, 'yyyy-MM-dd', 'en-US')));
                            return fromDate === toDate ?  billDueDate===fromDate : billDueDate >= fromDate && billDueDate <= toDate;
                        }
                        return bill;
                    })
                    : filteredBillList ;
          }
          return filteredBillList;
      }
      return this._billsList;
  }

  // request model and action to get billSearch
  getBillList(){
      this.store.dispatch(this.billInfoActions.getBillList());
  }
}
