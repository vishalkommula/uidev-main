import { BillTableTypeComponent } from './bill-table-type.component';

describe('BillTableTypeComponent', () => {
    let sut: BillTableTypeComponent;

    beforeEach(() => {
        sut = new BillTableTypeComponent();
    });

    it('should create', () => {
        expect(sut).toBeTruthy();
    });
});
