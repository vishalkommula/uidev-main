import { Injectable } from '@angular/core';
import { ColDef, GridOptions } from 'ag-grid-community';
import {
    AgGridPInputnumberEditorComponent,
    AgGridPInputnumberRendererComponent,
    AmountRendererComponent,
} from '@uid/uid-grid';

@Injectable({
    providedIn: 'root',
})
export class EscrowgridcoldefService {
    constructor() {
    }


    public default: ColDef = {
        enablePivot: false,
        resizable:true,
        sortable:true,
        filter: true,
        editable: false,
        enableValue: false,
        suppressMenu: false,
        menuTabs: ['generalMenuTab', 'filterMenuTab'],
    };
    public defaultEditableScreen: ColDef = {
        enablePivot: false,
        filter: false,
        resizable:false,
        sortable:false,
        suppressMenu:true
    };

    public editableColumns: ColDef[] = [
        {
            field: 'balFldAff',
            headerName: 'Balance Field to Affect',
            filter: 'agNumberColumnFilter',
        },
        {
            field: 'escrwPmtBalDesc',
            headerName: 'Balance Description',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'escrwPmtAmt',
            headerName: 'Payment Due',
            editable: true,
            filter: 'agNumberColumnFilter',
            cellClass: 'ag-cell-zeroPadding',
            cellEditor: 'agGridPInputnumberEditor',
            cellEditorParams :{
                minFractionDigits: 2,
                maxFractionDigits: 2,
                locale: 'en-US',
                step: .01,
                prefix: '$',
                mode: 'currency',
                currency:'USD',
                inputLength: 11,
                inputStyleClass:'prime-inputNumber',
                dataTestId:'escrow-PmtAmt',
            },
            cellRenderer: 'agGridPInputnumber',
            cellRendererParams :{
                minFractionDigits: 2,
                maxFractionDigits: 2,
                locale: 'en-US',
                step: .01,
                prefix: '$',
                mode: 'currency',
                currency:'USD',
                inputLength: 11,
                inputStyleClass:'prime-inputNumber',
                dataTestId:'escrow-PmtAmt',
            },
        },
        {
            field: 'escrwPmtAmtRem',
            headerName: 'Payment Remaining',
            editable: true,
            filter: 'agNumberColumnFilter',
            cellClass: 'ag-cell-zeroPadding',
            cellEditor: 'agGridPInputnumberEditor',
            cellEditorParams :{
                minFractionDigits: 2,
                maxFractionDigits: 2,
                locale: 'en-US',
                step: .01,
                prefix: '$',
                mode: 'currency',
                currency:'USD',
                inputLength: 11,
                inputStyleClass:'prime-inputNumber',
                dataTestId:'escrow-PmtAmtRem',
            },
            cellRenderer: 'agGridPInputnumber',
            cellRendererParams :{
                minFractionDigits: 2,
                maxFractionDigits: 2,
                locale: 'en-US',
                step: .01,
                prefix: '$',
                mode: 'currency',
                currency:'USD',
                inputLength: 11,
                inputStyleClass:'prime-inputNumber',
                dataTestId:'escrow-PmtAmtRem',
            },
        },
    ];

    public readonlyColumns: ColDef[] = [
        {
            field: 'balFldAff',
            headerName: 'Balance Field to Affect',
            filter: 'agNumberColumnFilter',
            // filterParams: {
            //     comparator: (a: any, b: any) => {
            //         // eslint-disable-next-line radix
            //         const valA = parseInt(a);
            //         // eslint-disable-next-line radix
            //         const valB = parseInt(b);
            //         if (valA === valB){
            //             return 0;
            //         }
            //         return valA > valB ? 1 : -1;
            //     }
            // }
        },
        {
            field: 'escrwPmtBalDesc',
            headerName: 'Balance Description',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'escrwPmtAmt',
            headerName: 'Payment Due',
            cellRenderer: AmountRendererComponent,
            cellClass: 'ag-right-aligned-cell',
            resizable: true,
            filter: 'agNumberColumnFilter'
        },
        {
            field: 'escrwPmtAmtRem',
            headerName: 'Payment Remaining',
            cellRenderer: AmountRendererComponent,
            cellClass: 'ag-right-aligned-cell',
            resizable: true,
            filter: 'agNumberColumnFilter',
        },
    ];

    public gridOptions: GridOptions = {
        sideBar: false,
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        rowHeight: 30,
        singleClickEdit: true,
        readOnlyEdit: true,
        domLayout: 'autoHeight',
        stopEditingWhenCellsLoseFocus: true,
        suppressRowClickSelection: true,
        frameworkComponents: {
            agGridPInputnumber: AgGridPInputnumberRendererComponent,
            agGridPInputnumberEditor: AgGridPInputnumberEditorComponent,
        }
    };

}
