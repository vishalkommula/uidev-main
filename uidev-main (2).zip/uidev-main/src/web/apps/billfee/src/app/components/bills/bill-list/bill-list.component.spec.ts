import { Observable, Subscription,of } from 'rxjs';
import { LnBilSrchFilterModel } from '../../../models/loan-bill-search-filter.model';
import { LnBilSrchRec } from '../../../models/loan-bill-search-record.model';
import { BillListComponent } from './bill-list.component';
import lnBilSrchResponse from '../../../mock-data/loanBillSearchResponse.mock.json';
import { PageMode } from '@uid/uid-models';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.useFakeTimers();
jest.spyOn(global, 'setTimeout');

let component: BillListComponent;

const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(()=> ({
        subscribe:jest.fn(),
    })),
};

const billInfoActionsMock = {
    getBillList: jest.fn(),
    billDueDate: jest.fn(),
    getbilldetails:jest.fn(),
    billClickAction: jest.fn(),
    setBillListFilter: jest.fn(),
    clearBillListFilter: jest.fn()
};

const billInfoSelectorsMock = {
    selectFilteredBills: jest.fn(),
    selectIsBillInfoDeleted: jest.fn(),
    selectIsBillInfoUpdated: jest.fn(),
    selectAction: jest.fn(),
    selectIsBillInfoFormDirty: jest.fn(),
};


const calendar = {
    overlayVisible: jest.fn()
};

const billDueDateSelectedEventMock = {
    emit: jest.fn()
};


describe('bill list component test',()=>{
    beforeEach(()=>{
        component = new BillListComponent(storeMock as any);
        component.resetFilterRecordModel();
        component.billInfoActions = billInfoActionsMock as any;
        component.billInfoSelectors = billInfoSelectorsMock as any;
        component.calendar = calendar;
        component.billDueDateSelectedEvent = billDueDateSelectedEventMock as any;
        jest.useFakeTimers();

    });


    afterEach(() => {
        jest.clearAllTimers();
    });

    it('component should be created',()=>{
        expect(component).toBeTruthy();
    });

    it('billsList - should be executed',()=>{
        component.billsList=[{ billDueDt:'02/22/2022' } as any];
        expect(component.billsList).toStrictEqual([{ billDueDt:'02/22/2022' }]);
    });

    it('billsList - should be executed with filterApplied',()=>{
        component.isFilterApplied=true;
        component.billsList=[{ billDueDt:'02/22/2022' } as any];
        expect(component.billsList).toStrictEqual([{ billDueDt:'02/22/2022' }]);
    });

    it('billsList - should be executed to Get Data',()=>{
        component.billsList=[{ billDueDt:'02/22/2022' } as any];
        expect(component.billsList).toStrictEqual([{ billDueDt:'02/22/2022' }]);
    });

    // ngOnInit method test
    it('ngOnInit - should be executed',()=>{
        component.billDueDate='';
        component.ngOnInit();
        expect(storeMock.dispatch).toBeCalled();
        expect(billInfoActionsMock.getBillList).toBeCalled();
    });

    it('setCurrentSelectedBillDueDate - execute resetSelectedBillDueDate when billsList is undefined',()=>{
        component.billsList=undefined;
        component.resetSelectedBillDueDate = jest.fn();
        component.currentSelectedBillDueDate = '10/10/2010';
        component.setCurrentSelectedBillDueDate();
        expect(component.resetSelectedBillDueDate).toBeCalled();
    });

    it('setCurrentSelectedBillDueDate - execute higlightRecordOnRefresh when billsList is not undefined',()=>{
        component.billsList=[{ billDueDt : '10/10/2022' } as any];
        component.higlightRecordOnRefresh = jest.fn();
        component.setCurrentSelectedBillDueDate();
        expect(component.higlightRecordOnRefresh).toBeCalled();
    });

    it('higlightRecordOnRefresh - set BillDuedt ',()=>{
        component.billsList=[{ billDueDt : '10/10/2022' } as any];
        component.billDueDate ='10/10/2022';
        component.higlightRecordOnRefresh();
        expect(component.currentSelectedBillDueDate).toEqual('10/10/2022');
    });

    it('higlightRecordOnRefresh - set currentSelectedBillDueDate with billDueDt available in billsList ',()=>{
        component.billsList=[{ lnBilInfoRec  :{ bilDueDt  : '10/10/2022' }  } as any];
        component.billDueDate ='';
        component.higlightRecordOnRefresh();
        jest.advanceTimersByTime(0);
        expect(component.currentSelectedBillDueDate).toEqual('10/10/2022');
    });

    it('resetSelectedBillDueDate - set currentSelectedBillDueDate to null ',()=>{
        component.resetSelectedBillDueDate();
        expect(component.currentSelectedBillDueDate).toEqual('');
    });

    it('getOverdueDays - should be executed',() => {
        const billDueDate = '2022-05-30';
        const actualValue = component.getOverdueDays(billDueDate);
        const dueDate = new Date(billDueDate);
        const currentDate = new Date();
        const expectedValue = ((currentDate.getTime() - dueDate.getTime()) / (1000 * 3600 * 24)).toFixed(0);
        expect(actualValue).toEqual(expectedValue);
    });

    it('isAddBillAllowed - should be executed',()=>{
        const actualValue = component.isAddBillAllowed();
        const expectedValue = true;
        expect(actualValue).toEqual(expectedValue);
    });

    it('resetFilterRecordModel - should be executed',()=>{
        component.resetFilterRecordModel();
        expect(component.filterRecordModel).toEqual({} as LnBilSrchFilterModel);
    });

    it('applyFilter - should be executed when filteredBillList is not undefined',()=>{
        component.applyFilterOnBillSearch = jest.fn().mockReturnValue([{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022' } } as any]);
        component.applyFilter();
        expect(component.currentSelectedBillDueDate).toEqual('02/02/2022');
    });

    it('applyFilter - should be executed when filteredBillList is  undefined',()=>{
        component.applyFilterOnBillSearch = jest.fn().mockReturnValue(undefined);
        component.resetSelectedBillDueDate =jest.fn();
        component.currentSelectedBillDueDate = '10/20/2022';
        component.applyFilter();
        expect(component.resetSelectedBillDueDate).toBeCalled();
    });

    it('resetFilter - should be executed when isResetButtonClick is true',()=>{
        component.billsList = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022' } } as any];
        component.resetFilter(true);
        expect(component.currentSelectedBillDueDate).toEqual('02/02/2022');

    });

    it('resetFilter - should be executed when isResetButtonClick is false',()=>{
        component.billsList = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022' } } as any];
        component.setCurrentSelectedBillDueDate=jest.fn();
        component.resetFilter(false);
        expect(component.setCurrentSelectedBillDueDate).toBeCalled();

    });

    // ToCheck
    it('addBill - should be executed',()=>{
        // create a mock html tag wth scrollToTop function
        const displayBlock = document.createElement('rui-display-block') as any;
        displayBlock.setAttribute('id', 'DisplayBlock');
        displayBlock.scrollToTop = jest.fn();
        document.body.appendChild(displayBlock);
        component.addBill({} as any);
    });

    it('onClickPCalendarPopup - should be executed', ()=>{
        component.filterRecordModel = { dateRange:[new Date(),new Date()] };
        component.onClickPCalendarPopup();
        expect(calendar.overlayVisible).toBeFalsy();
    });


    it('filterModelChange - should be executed',()=>{
        component.filterModelChange();
        expect(component.isFilterActionButtonsDisabled).toBeTruthy();
    });

    it('filterModelChange - from and to dates',()=>{
        const filterModelData = { dateRange: [new Date,new Date], paymentAmountTo: undefined, paymentAmountFrom: undefined };
        component.filterRecordModel = filterModelData as any;
        component.filterModelChange();
        expect(component.isFilterActionButtonsDisabled).toBeFalsy();
    });

    it('filterModelChange - payment amount to',()=>{
        const filterModelData = { dateRange:undefined, paymentAmountTo: 300, paymentAmountFrom: undefined };
        component.filterRecordModel = filterModelData as any;
        component.filterModelChange();
        expect(component.isFilterActionButtonsDisabled).toBeFalsy();
    });

    it('filterModelChange - payment amount from',()=>{
        const filterModelData = { dateRange:undefined, paymentAmountTo: undefined, paymentAmountFrom: 400 };
        component.filterRecordModel = filterModelData as any;
        component.filterModelChange();
        expect(component.isFilterActionButtonsDisabled).toBeFalsy();
    });

    it('filterModelChange - only from date in date range',()=>{
        const filterModelData = { dateRange:[new Date,null], paymentAmountTo: undefined, paymentAmountFrom: undefined };
        component.filterRecordModel = filterModelData as any;
        component.filterModelChange();
        expect(component.isFilterActionButtonsDisabled).toBeTruthy();
    });

    it('getDataForSelectedBillDueDate - view mode',()=>{
        const event = { detail: '2022-05-30' };
        const previousSelectedBillDueDate = '';
        const skipFormValidation = true;
        component.previousSelectedBillDueDt = previousSelectedBillDueDate;
        component.skipFormValidation = skipFormValidation;
        component.getDataForSelectedBillDueDate(event as any);
        jest.advanceTimersByTime(50);
        expect(component.skipFormValidation).toBeFalsy();
        expect(component.currentSelectedBillDueDate).toEqual(event.detail);
        expect(component.previousSelectedBillDueDt).toEqual(component.currentSelectedBillDueDate);
        expect(component.billDueDateSelectedEvent.emit).toHaveBeenCalledWith(event.detail);
    });

    it('getDataForSelectedBillDueDate - edit mode',()=>{
        const event = { detail: '2022-05-30' };
        const skipFormValidation = false;
        const pageMode = PageMode.Edit;
        component.pageMode = pageMode;
        component.previousSelectedBillDueDt = '02/02/2022';
        component.skipFormValidation = skipFormValidation;
        component.getDataForSelectedBillDueDate(event as any);
        jest.advanceTimersByTime(70);
        expect(component.currentSelectedBillDueDate).toEqual(component.previousSelectedBillDueDt);
    });


    it('applyFilterOnBillSearch - apply filter when filterParameters are undefiend',()=>{
        component.billsList = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022' } } as any];
        component.applyFilterOnBillSearch();
        expect(component.billsList).toStrictEqual([{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022' } } as any]);
    });

    it('applyFilterOnBillSearch - apply filter when filterParameters are with from Date',()=>{
        const billsListValue = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 10 } } as any,{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 0 } } as any];
        component.billsList = billsListValue;
        component.filterRecordModel = { paymentAmountFrom: 10 };
        const filteredList= component.applyFilterOnBillSearch();
        expect(filteredList).toStrictEqual([{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 10 } } as any]);
    });

    it('applyFilterOnBillSearch - apply filter when filterParameters are with to Date ',()=>{
        const billsListValue = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 20 } } as any,{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 30 } } as any];
        component.billsList = billsListValue;
        component.filterRecordModel = { paymentAmountTo : 20 };
        const filteredList= component.applyFilterOnBillSearch();
        expect(filteredList).toStrictEqual([{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 20 } } as any]);
    });

    it('applyFilterOnBillSearch - apply filter when filterParameters are with dateRange ',()=>{
        const billsListValue = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 20 } } as any,{ lnBilSrchRecItem :{ bilDueDt:'02/01/2022', orgTotAmt : 30 } } as any];
        component.billsList = billsListValue;
        component.filterRecordModel = { dateRange : [new Date('02/02/2022'),new Date('02/02/2022')] };
        const filteredList= component.applyFilterOnBillSearch();
        expect(filteredList).toStrictEqual([{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : 20 } } as any]);
    });

    it('applyFilterOnBillSearch - apply filter when filterParameters are with from Date with orgTotAmt as undefined',()=>{
        const billsListValue = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : undefined } } as any,{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : undefined } } as any];
        component.billsList = billsListValue;
        component.filterRecordModel = { paymentAmountFrom: 10 };
        const filteredList= component.applyFilterOnBillSearch();
        expect(filteredList).toStrictEqual(billsListValue);
    });

    it('applyFilterOnBillSearch - apply filter when filterParameters are with to Date  with orgTotAmt as undefined',()=>{
        const billsListValue = [{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : undefined } } as any,{ lnBilSrchRecItem :{ bilDueDt:'02/02/2022', orgTotAmt : undefined } } as any];
        component.billsList = billsListValue;
        component.filterRecordModel = { paymentAmountTo : 20 };
        const filteredList= component.applyFilterOnBillSearch();
        expect(filteredList).toStrictEqual(billsListValue);
    });

    it('applyFilterOnBillSearch - apply filter when filterParameters are with dateRange  with orgTotAmt as undefined',()=>{
        const billsListValue = [{ lnBilSrchRecItem :{ bilDueDt:undefined, orgTotAmt : 20 } } as any,{ lnBilSrchRecItem :{ bilDueDt:undefined, orgTotAmt : 30 } } as any];
        component.billsList = billsListValue;
        component.filterRecordModel = { dateRange : [new Date('02/02/2022'),new Date('02/02/2022')] };
        const filteredList= component.applyFilterOnBillSearch();
        expect(filteredList).toStrictEqual(billsListValue);
    });

});
