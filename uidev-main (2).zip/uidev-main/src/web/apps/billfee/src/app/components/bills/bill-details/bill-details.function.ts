/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { clearErrorMessage, errorMessageDisplay, formatDate,setErrorMessage } from '@uid/uid-utilities';
import { DateFormatterType, FieldMode, FieldValidation, PageMode } from '@uid/uid-models';
import { BillFeeFormDateTypeEnum } from '../../../models/bill-fee-enums';
import { LnBilInfoResponse } from '../../../models/loan-bill-info-response.model';
import { LnBilSrchRec } from '../../../models/loan-bill-search-record.model';

// to set input type for numbers field
// eslint-disable-next-line @typescript-eslint/naming-convention
const InputNumberModeEnum = {
    decimal: 'decimal',
    currency: 'currency',
};

// common fields for edit and add
export const isBillDetailView = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Edit || field?.options?.formState.pageMode === PageMode.Add ? false : true;
};
// edit display form
export const isAddView = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Add ? false : true;
};
// view dispaly fiels
export const isBillInfoView = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Inquiry || field?.options?.formState.pageMode === PageMode.Edit ? false : true;
};

// printno dispaly fields
export const isPrintNoDisplay = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Add || field?.options?.formState.pageMode === PageMode.Edit ? false : true;
};

// disable field if bill due date is empty
export const isBillDueDtEmpty = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Add ?
        (field?.model.addBilDueDt &&
    !(field?.form?.get('addBilDueDt')?.hasError('addBilDueDtValidation')) ? false : true) : false;
};

export const tableWidth = function (field?: FormlyFieldConfig): string {
    return field?.options?.formState.pageMode === PageMode.Inquiry ? '368px' : '500px';
};

export const billInfoScreenStyle = function (field?: FormlyFieldConfig): any {
    return field?.options?.formState.pageMode === PageMode.Inquiry
        ? field?.key === 'totalRemaining' || field?.key === 'totalBilled'
            ? { 'text-align': 'right', 'font-weight': '600' }
            : { 'text-align': 'right', 'font-weight': '400' }
        : { 'text-align': 'right', 'font-weight': '600' };
};

export const prntLabelClass = function (field?: FormlyFieldConfig): string {
    return field?.options?.formState.pageMode === PageMode.Add ? 'col-md-4' : 'col-md-10';
};

export const prntValueClass = function (field?: FormlyFieldConfig): string {
    return field?.options?.formState.pageMode === PageMode.Add ? 'col-md-3' : 'col-md-2';
};
export const isEditView = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Edit ? false : true;
};

export const isDetailsView = function (field?: FormlyFieldConfig): boolean {
    return field?.options?.formState.pageMode === PageMode.Inquiry ? false : true;
};

// toggle input mode mode statement details
export const getInputMode = function (field?: FormlyFieldConfig) {
    return field?.options?.formState.pageMode === PageMode.Edit ? InputNumberModeEnum.decimal : InputNumberModeEnum.currency;
};


//DateTime is part of common date formatter Type in Luxon
export function dateISOFormatter(date: string): string {
    return date !== undefined ? formatDate(date, DateFormatterType.DisplayedDateFormatter) : date;
}

export function billDueDtInvalidValidation(field: FormlyFieldConfig) {
    const addBilDueDt = field?.form?.get('addBilDueDt')?.value;
    if(field?.options?.formState.pageMode=== PageMode.Add &&
        (field?.options?.formState.isSubmitted || field.formControl?.touched)){
        if((!addBilDueDt)){
            setErrorMessage(field,'addBilDueDt','addBilDueDtValidation',[{ message: BillFeeFormDateTypeEnum.BillDueDateValidationMsg }]);
            return true;
        }
        // convert the selected Due Bill Date to the required format.
        const extractDueDate=formatDate(addBilDueDt ?? '', DateFormatterType.IsoDateFormatter);
        // find if selected Bill Due Date is available in addedBillDueDtList.
        const index=field.options?.formState.addedBillDueDtList.findIndex((x: string)=>x===extractDueDate);
        if(index !==-1){
            // set the error message to be displayed
            return setErrorMessage(field,'addBilDueDt','addBilDueDtValidation',[{ message: BillFeeFormDateTypeEnum.BillDueDtAlreadyExistValidationMessage }]);
        } else if(field?.form?.get('addBilDueDt')?.hasError('addBilDueDtValidation')){
            // clear all the error message.
            return clearErrorMessage(field,'addBilDueDt','addBilDueDtValidation');
        }
        return false;
    }
    return false;
};



export function getBillDetailFormField(): FormlyFieldConfig[] {
    return [
        {
            props: { width: 'medium', hideLabel: true },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'nxtPayDt',
                    type: FormDataTypeEnum.input,
                    props: {
                        label: 'Payment Due Date',
                        attributes: {
                            'data-test-id': 'billDetails-nxtPayDt-01',
                        },
                        fieldMode: FieldMode.Inquiry,
                        placeholder: '0.00'
                    },
                },
                {
                    key: 'bilDueDt',
                    type: FormDataTypeEnum.input,
                    props: {
                        label: 'Bill Due Date',
                        attributes: {
                            'data-test-id': 'billDetails-bilDueDt-01',
                        },
                        fieldMode: FieldMode.Inquiry,
                        placeholder: '0.00'
                    },
                },
                {
                    key: 'bilCrtDt',
                    type: FormDataTypeEnum.input,
                    props: {
                        label: 'Billed Date',
                        attributes: {
                            'data-test-id': 'billDetails-bilCrtDt-01',
                        },
                        fieldMode: FieldMode.Inquiry,
                        placeholder: '0.00'
                    },
                },
                {
                    key: 'bilPaidDt',
                    type: FormDataTypeEnum.input,
                    props: {
                        label: 'Billed Date',
                        attributes: {
                            'data-test-id': 'billDetails-bilCrtDt-01',
                        },
                        fieldMode: FieldMode.Inquiry,
                        placeholder: '0.00'
                    },
                    expressions:{
                        hide : '!model.bilPaidDt'
                    }
                }
            ],
            expressions:{
                hide:isBillInfoView
            }
        },
        {
            fieldGroup: [
                {
                    key: 'addBilDueDt',
                    type: FormDataTypeEnum.datepicker,
                    props: {
                        label: 'Bill Due Date:',
                        styleclass: 'styleclass',
                        placeholder: 'MM/DD/YYYY',
                        dateFormat: 'mm/dd/yy',
                        labelClasses: 'col-md-4',
                        valueClasses: 'col-md-4',
                        showButtonBar: false,
                        required:true,
                        attributes: {
                            'data-test-id': 'billDetails-addBilDueDt-01',
                        },
                    },
                    expressions:{
                        hide:isAddView,
                        'validation.show': billDueDtInvalidValidation,
                    }
                },
                {
                    props: {
                        label: 'Print Billing Notice',
                        name: 'printbillingnotice',
                        id: 'printbillingnotice',
                        inputid: 'printbillingnotice',
                        attributes: {
                            'data-test-id': 'billDetails-printBN-01',
                        },
                        placeholder: '0.00'
                    },
                    wrappers: ['form-field'],
                    key: 'printbillingnotice',
                    type: FormDataTypeEnum.toggleButton,
                    expressions: {
                        'props.disabled': isBillDueDtEmpty,
                        'props.labelClasses': prntLabelClass,
                        'props.valueClasses': prntValueClass,
                        hide:isPrintNoDisplay,
                    },
                },
            ],
        },
        {
            type: BillFeeFormDateTypeEnum.BillTableType,
            expressions: {
                'props.width': tableWidth,
                'props.isDetailsView': isDetailsView
            },
            fieldGroup: [
                {
                    name: 'Principal',
                    props: {
                        attributes: {
                            'data-test-id': 'billDetails-tableLabel-01',
                        },
                    },
                },
                {
                    key: 'remBilPrincAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        prefix: '$',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        inputLength: 11,
                        min: 0,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-remBilPrincAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    key: 'bilPrincAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        inputLength: 11,
                        fieldValidation: FieldValidation.Hide,
                        min: 0,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        prefix: '$',
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-bilPrincAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    name: 'Interest',
                    props: {
                        attributes: {
                            'data-test-id': 'billDetails-tableLabel-02',
                        },
                        placeholder: '0.00'
                    },
                },
                {
                    key: 'remBilIntAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        prefix: '$',
                        fieldValidation: FieldValidation.Hide,
                        inputLength: 11,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        min: 0,
                        placeholder: '0.00',
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-remBilIntAmt-01',
                        }
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    key: 'bilIntAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        prefix: '$',
                        fieldValidation: FieldValidation.Hide,
                        setwidth: 'setwidth',
                        inputLength: 11,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        min: 0,
                        screenMode: 'bill',
                        placeholder: '0.00',
                        attributes: {
                            'data-test-id': 'billDetails-bilIntAmt-01',
                        },
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    name: 'Escrow',
                    props: {
                        attributes: {
                            'data-test-id': 'billDetails-tableLabel-03',
                        },
                        placeholder: '0.00',
                    },
                },
                {
                    key: 'remBilEscrwAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        prefix: '$',
                        inputLength: 9,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        min: 0,
                        screenMode: 'bill',
                        placeholder: '0.00',
                        attributes: {
                            'data-test-id': 'billDetails-remBilEscrwAmt-01',
                        },
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    key: 'bilEscrwAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        inputLength: 9,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        min: 0,
                        prefix: '$',
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-bilEscrwAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    name: 'Late Charge',
                    props: {
                        attributes: {
                            'data-test-id': 'billDetails-tableLabel-04',
                        },
                        placeholder: '0.00',
                    },
                },
                {
                    key: 'remBilLateChgAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        inputLength: 9,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        min: 0,
                        prefix: '$',
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-remBilLateChgAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    key: 'bilLateChgAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        inputLength: 9,
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        prefix: '$',
                        min: 0,
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-bilLateChgAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    name: 'Other Charges',
                    props: {
                        attributes: {
                            'data-test-id': 'billDetails-tableLabel-05',
                        },
                        placeholder: '0.00',
                    },
                },
                {
                    key: 'remBilOtherChgAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        inputLength: 11,
                        min: 0,
                        prefix: '$',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-remBilOtherChgAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    key: 'bilOtherChgAmt',
                    type: FormDataTypeEnum.number,
                    props: {
                        inputStyleClass: 'rui-form-control',
                        setwidth: 'setwidth',
                        fieldValidation: FieldValidation.Hide,
                        prefix: '$',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        inputLength: 11,
                        min: 0,
                        screenMode: 'bill',
                        attributes: {
                            'data-test-id': 'billDetails-bilOtherChgAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    id: 'bilOtherChgAmt',  // used for handling tab event and set focus to feegrid
                    expressions: {
                        'props.islabeldata': isBillDetailView,
                        'props.disabled': isBillDueDtEmpty,
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                        'validation.show': errorMessageDisplay,
                    },
                },
                {
                    name: 'Totals',
                    props: {
                        attributes: {
                            'data-test-id': 'billDetails-tableLabel-06',
                        },
                    },
                },
                {
                    key: 'totalRemaining',
                    props: {
                        inputStyleClass: 'rui-form-control',
                        islabeldata: true,
                        attributes: {
                            'data-test-id': 'billDetails-totalRemaining-01',
                        },
                    },
                    expressions: {
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                    },
                },
                {
                    key: 'totalBilled',
                    props: {
                        inputStyleClass: 'rui-form-control',
                        islabeldata: true,
                        attributes: {
                            'data-test-id': 'billDetails-totalBilled-01',
                        },
                    },
                    expressions: {
                        'props.billInfoScreenStyle': billInfoScreenStyle,
                    },
                },
            ],
        },
    ];
}

// statement details fields
// as per mock in edit view the blocks are grouped and rearranged, so activity block code is alone repeated.
export function getStatementDetailFormField(): FormlyFieldConfig[] {
    return [
        {
            props: { width: 'small' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'rePrtFlg',
                    type: FormDataTypeEnum.checkbox,
                    props: {
                        label: 'Reprint Statement',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        attributes: {
                            'data-test-id': 'statementDetail-rePrtFlg-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions:{
                        hide:isEditView
                    }
                },
                {
                    props: { label: 'Balance' },
                    wrappers: ['record-detail-block'],
                    fieldGroup: [
                        {
                            key: 'crLineAmt',
                            props: {
                                label: 'Credit Line Amount',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 2,
                                maxFractionDigits: 2,
                                max: 99999999999,
                                inputLength: 14,
                                prefix: '$',
                                attributes: {
                                    'data-test-id': 'statementDetail-crLineAmt-01',
                                },
                                placeholder: '0.00'
                            },
                            type: FormDataTypeEnum.currency,
                            expressions: {
                                'props.mode': getInputMode,
                            },
                        },
                        {
                            key: 'avalBal',
                            props: {
                                label: 'Available Credit',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 2,
                                maxFractionDigits: 2,
                                max: 99999999999,
                                inputLength: 14,
                                prefix: '$',
                                attributes: {
                                    'data-test-id': 'statementDetail-avalBal-01',
                                },
                                placeholder: '0.00'
                            },
                            expressions: {
                                'props.mode': getInputMode,
                            },
                            type: FormDataTypeEnum.currency,
                        },
                        {
                            key: 'prevAmtStillPastDue',
                            props: {
                                label: 'Minimum Due Amount',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 2,
                                maxFractionDigits: 2,
                                max: 99999999999,
                                inputLength: 14,
                                prefix: '$',
                                attributes: {
                                    'data-test-id': 'statementDetail-prevAmtStillPastDue-01',
                                },
                                placeholder: '0.00'
                            },
                            expressions: {
                                'props.mode': getInputMode,
                            },
                            type: FormDataTypeEnum.currency,
                        },
                        {
                            key: 'curBal',
                            props: {
                                label: 'New Balance',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 2,
                                maxFractionDigits: 2,
                                max: 99999999999,
                                inputLength: 14,
                                prefix: '$',
                                attributes: {
                                    'data-test-id': 'statementDetail-curBal-01',
                                },
                                placeholder: '0.00'
                            },
                            expressions: {
                                'props.mode': getInputMode,
                            },
                            type: FormDataTypeEnum.currency,
                        },
                        {
                            key: 'balLstStmt',
                            props: {
                                label: 'Previous Statement Balance',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 2,
                                maxFractionDigits: 2,
                                max: 99999999999,
                                inputLength: 14,
                                prefix: '$',
                                attributes: {
                                    'data-test-id': 'statementDetail-balLstStmt-01',
                                },
                                placeholder: '0.00'
                            },
                            expressions: {
                                'props.mode': getInputMode,
                            },
                            type: FormDataTypeEnum.currency,
                        },
                        {
                            key: 'avgBal',
                            props: {
                                label: 'Average Daily Balance',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 2,
                                maxFractionDigits: 2,
                                max: 99999999999,
                                inputLength: 14,
                                prefix: '$',
                                attributes: {
                                    'data-test-id': 'statementDetail-avgBal-01',
                                },
                                placeholder: '0.00'
                            },
                            expressions: {
                                'props.mode': getInputMode,
                            },
                            type: FormDataTypeEnum.currency,
                        },
                        // activity block for edit view
                        {
                            props: { label: 'Activity' },
                            wrappers: ['record-detail-block'],
                            fieldGroup: [
                                {
                                    key: 'amtOfAdvas',
                                    props: {
                                        label: 'Checks and Advance Amount',
                                        labelClasses: 'col-md-7',
                                        valueClasses: 'col-md-5',
                                        inputStyleClass: 'rui-form-control',
                                        minFractionDigits: 2,
                                        maxFractionDigits: 2,
                                        max: 999999999,
                                        inputLength: 11,
                                        prefix: '$',
                                        attributes: {
                                            'data-test-id': 'statementDetail-amtOfAdvas-01',
                                        },
                                        placeholder: '0.00'
                                    },
                                    expressions: {
                                        'props.mode': getInputMode,
                                        hide:isEditView
                                    },
                                    type: FormDataTypeEnum.currency,
                                },
                                {
                                    key: 'amtOfPmts',
                                    props: {
                                        label: 'Payments and Credits',
                                        labelClasses: 'col-md-7',
                                        valueClasses: 'col-md-5',
                                        inputStyleClass: 'rui-form-control',
                                        minFractionDigits: 2,
                                        maxFractionDigits: 2,
                                        max: 999999999,
                                        inputLength: 11,
                                        prefix: '$',
                                        attributes: {
                                            'data-test-id': 'statementDetail-amtOfPmts-01',
                                        },
                                        placeholder: '0.00'
                                    },
                                    expressions: {
                                        'props.mode': getInputMode,
                                    },
                                    type: FormDataTypeEnum.currency,
                                },
                                {
                                    key: 'aggDays',
                                    props: {
                                        label: 'Days in Cycle',
                                        labelClasses: 'col-md-7',
                                        valueClasses: 'col-md-5',
                                        inputStyleClass: 'rui-form-control',
                                        max: 999,
                                        min: 0,
                                        inputLength: 3,
                                        minFractionDigits: 0,
                                        maxFractionDigits: 0,
                                        attributes: {
                                            'data-test-id': 'statementDetail-aggDays-01',
                                        },
                                        placeholder: '0.00'
                                    },
                                    type: FormDataTypeEnum.number,
                                },
                            ],
                        },
                    ],
                },
            ],
        },
        // activity block for details view
        {
            props: { label: 'Activity' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'amtOfAdvas',
                    props: {
                        label: 'Checks and Advance Amount',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'statementDetail-amtOfAdvas-02',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'amtOfPmts',
                    props: {
                        label: 'Payments and Credits',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'statementDetail-amtOfPmts-02',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'aggDays',
                    props: {
                        label: 'Days in Cycle',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        attributes: {
                            'data-test-id': 'statementDetail-aggDays-02',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.number,
                },
            ],
            expressions:{
                hide:isDetailsView
            }
        },
        {
            props: { label: 'Payment' },
            wrappers: ['record-detail-block'],
            fieldGroup: [
                {
                    key: 'nxtPmtDueDt',
                    type: FormDataTypeEnum.datepicker,
                    props: {
                        label: 'Payment Due Date',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        placeholder: 'MM/DD/YYYY',
                        showButtonBar: false,
                        attributes: {
                            'data-test-id': 'statementDetail-nxtPmtDueDt-01',
                        },
                    },
                },
                {
                    key: 'pmtAmt',
                    props: {
                        label: 'Current Due Amount',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        max: 999999999,
                        inputLength: 11,
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'statementDetail-pmtAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'pastDuePmtAmt',
                    props: {
                        label: 'Past Due Amount',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        max: 99999999999,
                        inputLength: 13,
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'statementDetail-pastDuePmtAmt-01',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'othChgs',
                    props: {
                        label: 'Other Charges',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        max: 999999999,
                        inputLength: 11,
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'statementDetail-currencyUsd-13',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    key: 'fincChg',
                    props: {
                        label: 'Finance Charges',
                        labelClasses: 'col-md-7',
                        valueClasses: 'col-md-5',
                        inputStyleClass: 'rui-form-control',
                        minFractionDigits: 2,
                        maxFractionDigits: 2,
                        max: 999999999,
                        inputLength: 11,
                        prefix: '$',
                        attributes: {
                            'data-test-id': 'statementDetail-currencyUsd-14',
                        },
                        placeholder: '0.00'
                    },
                    expressions: {
                        'props.mode': getInputMode,
                    },
                    type: FormDataTypeEnum.currency,
                },
                {
                    props: { label: 'Rate' },
                    wrappers: ['record-detail-block'],
                    expressions: {
                        'props.spacer': isEditView,
                    },
                    fieldGroup: [
                        {
                            key: 'annPctRate',
                            props: {
                                label: 'Annual Percentage Rate',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 6,
                                maxFractionDigits: 6,
                                max: 99999,
                                inputLength: 11,
                                suffix: '%',
                                attributes: {
                                    'data-test-id': 'statementDetail-percentage-01',
                                },
                                placeholder: '0.00'
                            },
                            expressions : {
                                'validation.show': errorMessageDisplay,
                            },
                            type: FormDataTypeEnum.percentage,
                        },
                        {
                            key: 'dlyPeriodicRate',
                            props: {
                                label: 'Daily Percentage Rate',
                                labelClasses: 'col-md-7',
                                valueClasses: 'col-md-5',
                                inputStyleClass: 'rui-form-control',
                                minFractionDigits: 8,
                                maxFractionDigits: 8,
                                max: 9.99999999,
                                min:-9.99999999,
                                suffix: '%',
                                placeholder: '0.00',
                                attributes: {
                                    'data-test-id': 'statementDetail-dailypercentage-01',
                                },
                            },
                            expressions: {
                                'props.mode': getInputMode,
                                'validation.show': errorMessageDisplay,
                            },
                            type: FormDataTypeEnum.percentage,
                        },
                    ],
                },
            ],
        },
    ];
}

export function isBillDetailCachedInState(billList: LnBilSrchRec[]){
    if(billList && billList.length > 0){
        return true;
    }
    return false;
}

// this method is used in formatErrorMessage function to ignore the errorElement ,
// and find LnBilInfoRec.SvcPrvdInfo.SilverLake.LnFeeInfoRecArray.LnFeeInfoRec.LnFeeId in errorElements.
export function findErrElementForBills(errorElements: string[]){
    return errorElements.findIndex(x => x === 'LnBilInfoRec.SvcPrvdInfo.SilverLake.LnFeeInfoRecArray.LnFeeInfoRec.LnFeeId');
}
