import { billFeeValueTypes } from '../../../models/bill-fee-enums';
import { BillDetailsComponent } from './bill-details.component';
import { PageMode } from '@uid/uid-models';
import { of } from 'rxjs';
import { LnBilInfoRecItem } from '../../../models/loan-bill-info-record-item.model';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports',()=>jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(()=> ({
        subscribe:jest.fn()
    })),
};


const billInfoActionsMock = {
    billList: jest.fn(),
    billDueDate: jest.fn(),
    billListRetrived:jest.fn(),
    getBillDetails:jest.fn(),
    updatePageMode:jest.fn(),
    updateBillInfoModel:jest.fn(),
    updateBillDetails:jest.fn(),
    addBillDetails:jest.fn(),
    deleteBillDetails:jest.fn()
};

const billFeeActionsMock={
    getFeeSearchRecords: jest.fn()
};

const commonActionsMock={
    updatePageMode: jest.fn()
};

const billInfoSelectorMock = {
    selectFormState: jest.fn(),
    selectBillinfo: jest.fn(),
    selectBillsearchbybillduedt: jest.fn()
};
describe('BillDetailsComponent', () => {
    let component: BillDetailsComponent;

    beforeEach(()=>{
        component = new BillDetailsComponent(storeMock as any);
        component.billInfoActions = billInfoActionsMock as any;
        component.billInfoSelector=billInfoSelectorMock as any;
        component.billFeeActions=billFeeActionsMock as any;
        component.billFeeValues=billFeeValueTypes;
        component.commonActions = commonActionsMock as any;
    });

    it('Component should be created',()=>{
        expect(component).toBeTruthy();
    });

    // editBill method test
    it('editBill should be executed',()=>{
        component.editBill();
        expect(billInfoActionsMock.getBillDetails).toBeCalled();
    });

    // delete method test
    it('deletebill call test',()=>{
        component.deleteBill();
        expect(component.dialogBoxType).toBe('Delete');
    });

    // cancel method test
    it('cancel call test',()=>{
        component.cancelBill();
        expect(component.dialogBoxType).toBe('Cancel');
    });

    it('calTotalRemaining, calculate the total remaining',()=>{
        const model={ remBilPrincAmt:100,totalRemaining:0,remBilIntAmt:0,remBilEscrwAmt:0,remBilLateChgAmt:0,remBilOtherChgAmt:0 };
        component.calTotalRemaining(model as any);
        expect(model.totalRemaining).toBe(100);
    });

    it('calTotalBilled, calculate the total billed',()=>{
        const model={ bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0 };
        component.calTotalBilled(model as any);
        expect(model.totalBilled).toBe(1100);
    });

    it('billInfoModelChange, during edit store dispatch the action method to update date in store',()=>{
        const model={ bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0,remBilPrincAmt:100,
            totalRemaining:0,remBilIntAmt:0,remBilEscrwAmt:0,remBilLateChgAmt:0,remBilOtherChgAmt:0,bilDueDt:'07/07/2007' };
        component.pageMode=PageMode.Edit;
        component.calTotalBilled=jest.fn();
        component.calTotalRemaining=jest.fn();
        component.billInfoModelChange(model as any);
        // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
        expect(billInfoActionsMock.updateBillInfoModel).toHaveBeenCalledTimes(1);
        expect(billInfoActionsMock.updateBillInfoModel).toHaveBeenCalledWith({ updateBillInfoModel: model });
    });

    it('saveBill should be executed for page mode add',()=>{
        component.pageMode = PageMode.Add;
        component.addBillInfoModel = {
            addBilDueDt: '02/02/2022'
        } as LnBilInfoRecItem;
        component.saveBill([]);
        expect(billInfoActionsMock.addBillDetails).toBeCalled();
    });

    it('saveBill should be executed for page mode edit',()=>{
        component.pageMode = PageMode.Edit;
        component.billDetails = {
            lnBilInfoRec: {}
        } as any;
        component.saveBill([]);
        expect(billInfoActionsMock.updateBillDetails).toBeCalled();
    });

    it('saveBill should be executed for page mode add (invalid form)',()=>{
        component.pageMode = PageMode.Add;
        component.formState = {
            isSubmitted: false
        } as any;
        component.billInfoForm = { get: jest.fn(), addBilDueDt: {
            hasError: jest.fn(() => true)
        } } as any;
        component.saveBill([]);
        expect(component.formState.isSubmitted).toBeTruthy();
    });


    it('bindBillInfoModelForAdd, binds the data for addBillInfoModel bill add screen',()=>{
        const model={
            bilPrincAmt: 0,
            remBilPrincAmt: 0,
            bilIntAmt: 0,
            remBilIntAmt: 0,
            bilEscrwAmt: 0,
            remBilEscrwAmt: 0,
            bilLateChgAmt: 0,
            lnFeeInfoRec: [],
            remBilLateChgAmt: 0,
            bilOtherChgAmt: 0,
            remBilOtherChgAmt: 0,
            totalBilled: 0,
            totalRemaining: 0,
            printbillingnotice: false,
            addBilDueDt: undefined,
        };
        component.bindBillInfoModelForAdd();
        expect(component.addBillInfoModel).toStrictEqual(model);
    });

    it('overridedialogBoxClose should be executed on click of override button save function called ',()=>{
        component.pageMode = PageMode.Edit;
        component.billDetails = {
            lnBilInfoRec: {}
        } as any;
        component.overrideDialogBoxClose({ clickAction: billFeeValueTypes.overrideMsg, faultRecInfoArray: [] });
        expect(billInfoActionsMock.updateBillDetails).toBeCalled();
    });

    it('dialogBoxClose should be executed for delete button click',()=>{
        const event = { detail: billFeeValueTypes.deleteMsg };
        component.billDetails = {
            lnBilInfoRec: {
                bilDueDt: '02/02/2022'
            }
        } as any;
        component.dialogBoxClose(event);
        expect(billInfoActionsMock.deleteBillDetails).toBeCalled();
        expect(component.showDialogBox).toBeFalsy();
    });

    it('dialogBoxClose should be executed for dont save button click if page in edit mode',()=>{
        component.pageMode = PageMode.Edit;
        const event = { detail: billFeeValueTypes.donotSave };
        component.billDetails = {
            lnBilInfoRec: {
                bilDueDt: '02/02/2022'
            }
        } as any;
        component.dialogBoxClose(event);
        expect(billInfoActionsMock.getBillDetails).toBeCalled();
        expect(component.showDialogBox).toBeFalsy();
    });

    it('dialogBoxClose should be executed for dont save button click if page in add mode',()=>{
        component.pageMode = PageMode.Add;
        const event = { detail: billFeeValueTypes.donotSave };
        component.billDetails = {
            lnBilInfoRec: {
                bilDueDt: '02/02/2022'
            }
        } as any;
        component.dialogBoxClose(event);
        expect(commonActionsMock.updatePageMode).toBeCalledTimes(1);
        expect(component.showDialogBox).toBeFalsy();
    });

    it('ngOnChanges should be executed for change in page mode',()=>{
        component.pageMode = PageMode.Add;
        const changes = { pageMode: PageMode.Add };
        component.billInfoForm = { reset: jest.fn } as any;
        component.ngOnChanges(changes as any);
        expect(billFeeActionsMock.getFeeSearchRecords).toBeCalled();
    });

    it('ngOnChanges should be executed for change in billDetails',()=>{
        const changes = { billDetails: { lnBilInfoRec: { printbillingnotice: true } } };
        component.billDetails = { lnBilInfoRec: { printbillingnotice: true } } as any;
        component.ngOnChanges(changes as any);
        expect(component.printBillingNotice).toBeTruthy();
    });

    it('ngOnInit should be executed ',()=>{
        component.formState$ = of({} as any);
        component.ngOnInit();
    });

    it('ngOnDestroy should be executed',()=>{
        component.subscriptions = [{ unsubscribe: jest.fn() }] as any;
        component.billInfoForm = { reset: jest.fn() } as any;
        component.ngOnDestroy();
    });

    it('statementDetailsModelChange should be executed',() => {
        component.billDetails = {
            lnBilInfoRec: {
                bilDueDt: '02/02/2022',
                lnStmtInfoRec: {} as any
            }
        } as any;
        component.statementDetailsModelChange({} as any);
        expect(billInfoActionsMock.updateBillInfoModel).toBeCalled();
    });

    it('selectedFeeRecord should be executed for late charges if fee is selected and add fee id to the array',() => {
        component.billInfoForm = { patchValue: jest.fn(),get:jest.fn() } as any;
        component.addBillInfoModel = {
            remBilLateChgAmt: 0,
            bilLateChgAmt: 0,
            lnFeeInfoRec: [
                {
                    lnFeeId: '1',
                    lnFeeAmt: 90
                }
            ]
        } as any;
        const event = {
            selectedStatus: true,
            selectedRecord: {
                lnFeeId: '2',
                loanFeeCategory: billFeeValueTypes.lateCharges,
                lnFeeRemAmt: 20,
                lnFeeAmt: 30
            }
        };
        component.selectedFeeRecord(event as any);
        expect(component.billInfoForm.patchValue).toBeCalledTimes(0);
    });

    it('selectedFeeRecord should be executed for late charges if fee is unselected and remove fee id from the array',() => {
        component.billInfoForm = { patchValue: jest.fn(),get:jest.fn() } as any;
        component.addBillInfoModel = {
            remBilLateChgAmt: 0,
            bilLateChgAmt: 0,
            lnFeeInfoRec: [
                {
                    lnFeeId: '1',
                    lnFeeAmt: 90
                }
            ]
        } as any;
        const event = {
            selectedStatus: false,
            selectedRecord: {
                lnFeeId: '1',
                loanFeeCategory: billFeeValueTypes.lateCharges,
                lnFeeRemAmt: 20,
                lnFeeAmt: 30
            }
        };
        component.selectedFeeRecord(event as any);
        expect(component.billInfoForm.patchValue).toBeCalledTimes(0);
    });

    it('selectedFeeRecord should be executed for other charges if fee is selected and add fee id to the array',() => {
        component.billInfoForm = { patchValue: jest.fn(),get:jest.fn() } as any;
        component.addBillInfoModel = {
            remBilOtherChgAmt: 0,
            bilOtherChgAmt: 0,
            lnFeeInfoRec: [
                {
                    lnFeeId: '1',
                    lnFeeAmt: 90
                }
            ]
        } as any;
        const event = {
            selectedStatus: true,
            selectedRecord: {
                lnFeeId: '2',
                loanFeeCategory: billFeeValueTypes.otherCharges,
                lnFeeRemAmt: 20,
                lnFeeAmt: 30
            }
        };
        component.selectedFeeRecord(event as any);
        expect(component.billInfoForm.patchValue).toBeCalledTimes(0);
    });

    it('selectedFeeRecord should be executed for other charges if fee is unselected and remove fee id from the array',() => {
        component.billInfoForm = { patchValue: jest.fn(),get:jest.fn() } as any;
        component.addBillInfoModel = {
            remBilOtherChgAmt: 0,
            bilOtherChgAmt: 0,
            lnFeeInfoRec: [
                {
                    lnFeeId: '1',
                    lnFeeAmt: 90
                }
            ]
        } as any;
        const event = {
            selectedStatus: false,
            selectedRecord: {
                lnFeeId: '1',
                loanFeeCategory: billFeeValueTypes.otherCharges,
                lnFeeRemAmt: 20,
                lnFeeAmt: 30
            }
        };
        component.selectedFeeRecord(event as any);
        expect(component.billInfoForm.patchValue).toBeCalledTimes(0);
    });

    it('selectedFeeRecord should be executed for finance charges if fee is selected and add fee id to the array',() => {
        component.billInfoForm = { patchValue: jest.fn(),get:jest.fn() } as any;
        component.addBillInfoModel = {
            remBilIntAmt: 0,
            bilIntAmt: 0,
            lnFeeInfoRec: [
                {
                    lnFeeId: '1',
                    lnFeeAmt: 90
                }
            ]
        } as any;
        const event = {
            selectedStatus: true,
            selectedRecord: {
                lnFeeId: '2',
                loanFeeCategory: billFeeValueTypes.FinancialCharges,
                lnFeeRemAmt: 20,
                lnFeeAmt: 30
            }
        };
        component.selectedFeeRecord(event as any);
        expect(component.billInfoForm.patchValue).toBeCalledTimes(0);
    });

    it('selectedFeeRecord should be executed for finance charges if fee is unselected and remove fee id from the array',() => {
        component.billInfoForm = { patchValue: jest.fn(),get:jest.fn() } as any;
        component.addBillInfoModel = {
            remBilIntAmt: 0,
            bilIntAmt: 0,
            lnFeeInfoRec: [
                {
                    lnFeeId: '1',
                    lnFeeAmt: 90
                }
            ]
        } as any;
        const event = {
            selectedStatus: false,
            selectedRecord: {
                lnFeeId: '1',
                loanFeeCategory: billFeeValueTypes.FinancialCharges,
                lnFeeRemAmt: 20,
                lnFeeAmt: 30
            }
        };
        component.selectedFeeRecord(event as any);
        expect(component.billInfoForm.patchValue).toBeCalledTimes(0);
    });
});
