import { Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';

// functions
import * as EscrowDetailsFunction from './function/escrow-details.function';

// Ngrx store
import { CellFocusedEvent, FirstDataRenderedEvent, GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import * as EscrowActions from '../../../store/actions/billescrow.action';
import * as EscrowSelector from '../../../store/selectors/billescrow.selector';
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import { EscrowgridcoldefService } from './escrow-grid-coldef.service';

// Libs
import { LengthValidatorDirective } from '@uid/uid-directives';

// Models
import { BillFeeModulesEnum, BillFeeRoutesEnum } from '../../../models/bill-fee-enums';
import { LnBilEscrwInfoRec } from '../../../models/loan-bill-escrow-info-record.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';
import { SLLnBilEscrwInfoRecItemModel } from '../../../models/sl-loan-bill-escrow-info-record-item.model';
import { GridCellModifiedData, PageMode } from '@uid/uid-models';
import { FormGroup } from '@angular/forms';
import { FormlyFormOptions } from '@ngx-formly/core';
import { Observable } from 'rxjs';
import { EscrowDetailFormStateModel } from '../../../models/escrow-details.formstate.model';
import { AgGridPInputnumberEditorComponent } from '@uid/uid-grid';

@Component({
    selector: 'uid-escrow-details',
    templateUrl: './escrow-details.component.html',
    styleUrls: ['./escrow-details.component.scss'],
})
export class EscrowDetailsComponent implements OnInit,OnChanges {
  @ViewChild('uidLengthValidatorDirective')
      uidLengthValidatorDirective = {} as LengthValidatorDirective;

  escrowDetails!: LnBilEscrwInfoRec;
  gridOptions: GridOptions  = {
      onGridReady: (event) => this.onGridReady(event),
      onFirstDataRendered: (event) => this.onFirstDataRendered(event),
      onCellFocused: (event: CellFocusedEvent) => this.onCellFocused(event),
      onCellValueChanged: (event) => this.onCellValueChanged(event),
      //onCellEditRequest: (event) => this.onCellEditRequest(event)
  };
  gridApi!: GridApi;

  escrowBalance!: SLLnBilEscrwPmtBalInfoRecItem[];
  pageModeEnum = PageMode;
  billScreenTypeEnum = BillFeeModulesEnum;
  billScreenRoute = BillFeeRoutesEnum;

  escrowSelector = EscrowSelector;
  escrowActions = EscrowActions;
  billInfoActions = BillInfoActions;
  public screenType!: string;

  // formly definitions
  escrowDetailsForm = new FormGroup({});
  escrowDetailsOptions: FormlyFormOptions = {};
  escrowDetailsFields = EscrowDetailsFunction.getEscrowDetailsFormField();
  // formState holds the state variable of formly
  escrowDetailsFormState$!: Observable<EscrowDetailFormStateModel>;

  //Input Varibles
  @Input() billDueDt!: string;
  @Input() set pageType(pageType: string) {
      this.screenType = pageType;
  }
  @Input() escrowPageMode!: PageMode | undefined;
  @Input() escrowData: any;

  constructor(private store: Store, private gridDef: EscrowgridcoldefService, private router: Router) {
      this.escrowDetailsFormState$ = this.store.select(this.escrowSelector.selectEscrowDetailsFormState);
  }

  ngOnInit(): void {
      this.gridOptions = { ...this.gridOptions, ...this.gridDef.gridOptions };
  }
  // TODO : Replace ngOnChanges with event emitters.
  ngOnChanges(changes: SimpleChanges) {
      if(changes['escrowPageMode']){
          this.escrowDetailsForm.reset();
          if(this.escrowPageMode=== PageMode.Inquiry){
              this.gridOptions.defaultColDef = this.gridDef.default;
              this.gridOptions.columnDefs =  this.gridDef.readonlyColumns;
              this.gridOptions.singleClickEdit = false;
              this.gridOptions.readOnlyEdit = false;
              this.gridOptions.api?.stopEditing();
              this.gridApi?.setColumnDefs(this.gridDef.readonlyColumns);
              this.gridApi?.setDefaultColDef(this.gridDef.default);
              this.gridApi?.setSuppressRowClickSelection(true);
              this.gridApi?.deselectAll();
              this.gridApi?.clearFocusedCell();
              /* whenever the columns are changing this event will fire for getting id for the last input of formly and adding the EventListener to it,
                 for tab function */
              this.gridOptions.onDisplayedColumnsChanged = (event: FirstDataRenderedEvent)=>  {
                  this.onFirstDataRendered(event);
              };
          }else if(this.escrowPageMode===PageMode.Edit){
              this.gridOptions.singleClickEdit = true;
              this.gridOptions.readOnlyEdit = true;
              this.gridApi.setSuppressRowClickSelection(false);
              //   this.gridOptions.onCellEditRequest = (event: CellEditRequestEvent) => {
              //       this.onCellEditRequest(event);
              //   };
              this.gridApi.setColumnDefs(this.gridDef.editableColumns);
              this.gridApi.setDefaultColDef(this.gridDef.defaultEditableScreen);
          }
      }
      if(changes['escrowData']){

          //Requires deep clone before assigning data, as its Editable grid requiring force update data of changed data to
          //underlying data source during edit scenarios.
          this.escrowDetails = JSON.parse(JSON.stringify(this.escrowData));
      }
  }

  onGridReady(event: GridReadyEvent) {
      event?.api?.closeToolPanel();
      event?.api?.sizeColumnsToFit();
      this.gridApi = event?.api;
  }

  onCellValueChanged(event: any) {
      const tempNewRowData = {};
      Object.entries(event.data as SLLnBilEscrwPmtBalInfoRecItem).find(([key, value]) => {
          if (key === event.colDef.field) {
              (tempNewRowData as any)[key] = event.newValue;
          } else {
              (tempNewRowData as any)[key] = value;
          }
      });
      const cellModifiedData: GridCellModifiedData<SLLnBilEscrwPmtBalInfoRecItem> = {
          uniqueRowIdentifier: event.data.balFldAff,
          oldData: event.oldValue,
          newData: event.newValue,
          oldRowData: event.data,
          newRowData: tempNewRowData as SLLnBilEscrwPmtBalInfoRecItem,
          field: event.colDef.field as string,
      };
      if (this.screenType === this.billScreenTypeEnum.escrow) {
          this.store.dispatch(this.escrowActions.updateEscrowBalance({ cellModifiedData: cellModifiedData }));
      } else if (this.screenType === this.billScreenTypeEnum.billsEscrow) {
          this.store.dispatch(this.billInfoActions.updateBillInfoEscrowBalance({ updateBillInfoEscrowModel: cellModifiedData, billDueDt: this.billDueDt }));
      }

      //   const cell = this.gridApi.getFocusedCell();
      //   event.api.setFocusedCell(cell?.rowIndex ?? 1,  cell?.column?.getColId() ?? '');

  }

  onCellFocused(event: CellFocusedEvent){
      console.log('on cell focussed');

      setTimeout(() => {
          //Below code is to pop open the Calendar when user does Mouse Click in lnPaidDt (during edit mode)
          const startEditingCellParams = { rowIndex: (event.rowIndex ?? 1),  colKey: event.column?.getColId() ?? '' };
          this.gridApi.startEditingCell(startEditingCellParams);
          const cellEditor = this.gridApi.getCellEditorInstances()[0] as AgGridPInputnumberEditorComponent ;
          if (cellEditor){
              cellEditor.selectCellValues();
          }
      }, 100);

  }

  // getting id and adding Eventlistener to it for tab key navigation
  onFirstDataRendered(params: FirstDataRenderedEvent) {
      /* intercept key strokes within input element
       TODO: need to remove document.getElementById and adding @viewchild */
      const lastInputfield = document.getElementById('nonEscrwPmt');
      // adding eventlistener
      lastInputfield?.addEventListener(
          'keydown',
          function (event) {
              // ignore non Tab key strokes
              if (event.key !== 'Tab') {
                  return;
              }
              // prevents tabbing into the url section
              event.preventDefault();
              // scrolls to the first row
              params.api.ensureIndexVisible(0);
              // scrolls to the first column
              const firstCol = params.columnApi.getAllDisplayedColumns()[2];
              params.api.ensureColumnVisible(firstCol);
              // sets focus into the first grid cell
              params.api.setFocusedCell(0, firstCol);
          },
          true
      );
  }

  escrowInfoModelChange(model: SLLnBilEscrwInfoRecItemModel) {
      if (this.screenType === this.billScreenTypeEnum.escrow) {
          this.store.dispatch(this.escrowActions.updateEscrowDetails({ updateEscrowDetails: model }));
      } else if (this.screenType === this.billScreenTypeEnum.billsEscrow) {
          this.store.dispatch(this.billInfoActions.updateBillInfoEscrowDetail({ updateBillEscrowDetails: model, billDueDt: this.billDueDt }));
      }
  }


  loadBillDetailsForDueDate(){
      //T00:00:00 is added since api sends the  data in dateTime format.
      this.router.navigate([this.billScreenRoute.billsScreen],{ state: { billDueDate: this.escrowDetails.billDt+'T00:00:00' } });
  }
}
