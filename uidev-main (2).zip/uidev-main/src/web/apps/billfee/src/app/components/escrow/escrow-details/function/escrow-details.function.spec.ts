import * as EscrowDetailsFunctions from './escrow-details.function';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

describe('Escrow Details Functions Test',() => {
    it('getEscrowDetailsFormField should return data', () => {
        const retVal = EscrowDetailsFunctions.getEscrowDetailsFormField();
        expect(retVal).toBeTruthy();
    });
});

