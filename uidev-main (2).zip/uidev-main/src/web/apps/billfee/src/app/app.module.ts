import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HomeModule } from './components/home/home.module';
import { HomeComponent } from './components/home/home.component';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { RootStateModule } from '@uid/uid-root-store';
@NgModule({
    declarations: [AppComponent],
    imports: [
        BrowserModule,
        StoreModule.forRoot({}),
        EffectsModule.forRoot([]),
        HomeModule,
        HttpClientModule,
        RouterModule.forRoot([{ path: '', component: HomeComponent }],
            { initialNavigation: 'enabledBlocking' }),
        RootStateModule
    ],
    providers: [],
    bootstrap: [AppComponent],
})
export class AppModule {}
