module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'billfee',
    exposes: {
        './Module': 'apps/billfee/src/app/components/home/home.module.ts'
    }
};
