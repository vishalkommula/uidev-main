
import { DataService } from './data.service';
let service: DataService;
describe('DataService', () => {

    beforeEach(() => {
        service=new DataService();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('getAssociated Accounts method - should be excuted this is silverLakeResponse', async ()=> {
        const request: any = {
            srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
            acctId: '12',
            acctType: 'A',
        };
        service.secondaryProductIsSupported = false;
        const actualValue = service.getAssociatedAccountsDetails(request as any);
        expect(await actualValue.toPromise()).toBeTruthy();
    });
    it('getAssociated Accounts method - should be excuted this is cifResponse', async ()=> {
        const request: any = {
            srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
            acctId: '12',
            acctType: 'A',
        };
        const actualValue = service.getAssociatedAccountsDetails(request as any);
        request.secondaryProductIsSupported = true;
        expect(await actualValue.toPromise()).toBeTruthy();
    });
    it('get glaccountinquiry method - should be excuted', async ()=> {
        const actualValue = service.getGlAccountInquiryDetails({} as any);
        expect(await actualValue.toPromise()).toBeTruthy();
    });
});
