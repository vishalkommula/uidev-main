
import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import associatedAccountsMockData from '../../mock-data/associatedaccounts.silverlake.mock.json';
import glAccountInquiryMockData from '../../mock-data/associatedaccounts.silverlake.mock.json';
import * as AssociatedAccountsActions from '../actions/associatedaccounts.action';
import { AssociatedAccountsEffects } from './associatedaccounts.effects';


// mocking success service method
const associatedAccountsSuccessMock = {
    getAssociatedAccountsDetails: ()=> of(associatedAccountsMockData),
    getGlAccountInquiryDetails: ()=> of(glAccountInquiryMockData),
};

// mocking faiure service method
const associatedAccountsFailureMock = {
    getAssociatedAccountsDetails: ()=> throwError('Error - getting the associated accounts list'),
    getGlAccountInquiryDetails: ()=> throwError('Error - getting the gl account inquiry list')
};

// mock action subject
let actions: ActionsSubject;

// mock effects
let effects: AssociatedAccountsEffects;

describe('Associated accounts Effects Test',()=> {
    beforeEach(()=>{
        actions = new ActionsSubject();
    });
    // get  associated accounts list info success response
    it('getAssociatedAccountsDetails$ - should be excuted if success response', ()=>{
        effects = new AssociatedAccountsEffects(associatedAccountsSuccessMock as any,actions);
        effects.getAssociatedAccountsDetails$.subscribe((response: any)=>{
            expect(response).toEqual(AssociatedAccountsActions.getAssociatedAccountsSuccess({ response: {} as any }));
        });
        // dispatch the action method
        const action = AssociatedAccountsActions.getAssociatedAccounts({ request:{} as any });
        actions.next(action);
    });
    it('getGlAccountInquiryDetails$ - should be excuted if success response', ()=>{
        effects = new AssociatedAccountsEffects(associatedAccountsSuccessMock as any,actions);
        effects.getGlAccountInquiryDetails$.subscribe((response: any)=>{
            expect(response).toEqual(AssociatedAccountsActions.getGlAccountInquirySuccess({ response: {} as any }));
        });
        // dispatch the action method
        const action = AssociatedAccountsActions.getGlAccountInquiry({ request:{} as any });
        actions.next(action);
    });

    // get associated accounts list info failure response
    it('getAssociatedAccountsDetails$ - should be excuted if failure response', ()=>{
        effects = new AssociatedAccountsEffects(associatedAccountsFailureMock as any,actions);
        effects.getAssociatedAccountsDetails$.subscribe((failure: any)=>{
            expect(failure).toEqual(AssociatedAccountsActions.getAssociatedAccountsFailure({ error:{} as Error }));
        });
        // dispatch the action method
        const action = AssociatedAccountsActions.getAssociatedAccounts({ request:{} as any });
        actions.next(action);
    });
    it('getGlAccountInquiryDetails$ - should be excuted if failure response', ()=>{
        effects = new AssociatedAccountsEffects(associatedAccountsFailureMock as any,actions);
        effects.getGlAccountInquiryDetails$.subscribe((failure: any)=>{
            expect(failure).toEqual(AssociatedAccountsActions.getGlAccountInquiryFailure({ error:{} as Error }));
        });
        // dispatch the action method
        const action = AssociatedAccountsActions.getGlAccountInquiry({ request:{} as any });
        actions.next(action);
    });

});
