import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface GLAcctInqRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    brCode: string;
    gLCostCtr: string;
    gGLProdCode: string;
};
