import { Injectable } from '@angular/core';
import { ColDef, GridOptions, ValueGetterParams } from 'ag-grid-community';
import {
    AmountRendererComponent, ButtonRendererClickParms,
    ButtonRendererComponent, ButtonRendererModel
} from '@uid/uid-grid';

@Injectable({ providedIn: 'root' })
export class AssociatedAccountsGridService {

    public buttonRendererList: ButtonRendererModel[] = [
        {
            iconType: 'preview',
            onClick: this.onPreview.bind(this)
        }
    ];

    public default: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public autoGroupColumnDef: ColDef =
        {
            headerName: 'Title',
            field: 'acctTitle',
            filter: 'agTextColumnFilter',
            cellRenderer: 'agGroupCellRenderer',
            minWidth: 210,
        };

    public gridOptions: GridOptions = {
        defaultColDef: this.default,
        autoGroupColumnDef: this.autoGroupColumnDef,
        groupDefaultExpanded: 1,
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
    };

    public associatedAccountsColumns(productCodeDisplay: boolean): ColDef[] {
        return [
            {
                field: 'brDesc',
                headerName: 'Title',
                rowGroup: true,
                hide: true,
                valueGetter: this.branchCodeValueGetter,
                filter: 'agTextColumnFilter',
            },
            {
                field: 'gLCostCtrDesc',
                headerName: 'Cost Center',
                filter: 'agTextColumnFilter',
                valueGetter: this.costCenterValueGetter,
                hide: productCodeDisplay ? false : true
            },
            {
                field: 'gLProdDesc',
                headerName: 'Product Code',
                filter: 'agTextColumnFilter',
                valueGetter: this.productCodeValueGetter,
                hide: productCodeDisplay ? false : true
            },
            {
                field: 'gLTotalLvl',
                headerName: 'Level',
                filter: 'agTextColumnFilter',
                hide: productCodeDisplay ? true : false
            },
            {
                field: 'gLInqType',
                headerName: 'Type',
                filter: 'agTextColumnFilter',
                hide: productCodeDisplay ? true : false
            },
            {
                field: 'curBal',
                headerName: 'Balance',
                filter: 'agNumberColumnFilter',
                cellClass: this.balanceCellClass,
                cellRenderer: AmountRendererComponent,
            },
            {
                field: 'acctId',
                headerName: '',
                sortable: false,
                filter: false,
                pinned: 'right',
                cellRenderer: ButtonRendererComponent,
                cellRendererParams: {
                    buttonList: this.buttonRendererList
                },
                suppressColumnsToolPanel: true,
                suppressFiltersToolPanel: true
            }
        ];
    }

    onPreview(event: ButtonRendererClickParms): void {
        console.log('clicking Preview!!', event);
    }

    balanceCellClass(params: any) {
        if (params.node?.group) {
            return;
        }
        return params.data.curBal < 0 ? ['rui-error-text-label', 'ag-right-aligned-cell'] : 'ag-right-aligned-cell';
    }

    costCenterValueGetter(params: ValueGetterParams) {
        if (params.node?.group) {
            return;
        }
        return params.data.gLCostCtr + ' - ' + params.data.gLCostCtrDesc;
    }

    productCodeValueGetter(params: ValueGetterParams) {
        if (params.node?.group) {
            return;
        }
        return params.data.gLProdCode + ' - ' + params.data.gLProdDesc;
    }

    branchCodeValueGetter(params: ValueGetterParams) {
        if (params.node?.group) {
            return;
        }
        return params.data.brCode + ' - ' + params.data.brDesc;
    }

}
