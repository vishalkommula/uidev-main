import { AmountRendererComponent, ButtonRendererComponent } from '@uid/uid-grid';
import { AssociatedAccountsGridService } from './associatedaccounts-grid.def';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());



let service: AssociatedAccountsGridService;

describe('AssociatedAccountsGridService', () => {

    beforeEach(() => {
        service = new AssociatedAccountsGridService();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
    it('onPreview should be executed',()=> {
        (<any>window).console = { log: jest.fn() };
        service.onPreview({} as any);
        expect(console.log).toBeCalled();
    });
    it('associatedAccountsColumns should be executed',()=> {
        const productCodeDisplay = false;
        const actualValue = service.associatedAccountsColumns(productCodeDisplay);
        expect(actualValue[0].field).toEqual('brDesc');
    });
    it('balanceCellClass return the red color when value should be negative', () => {
        const params = {
            data:{
                curBal : -12
            }
        };
        const actualValue = service.balanceCellClass(params as any);
        params.data.curBal = -12;
        expect(actualValue).toEqual(['rui-error-text-label','ag-right-aligned-cell']);
    });
    it('balanceCellClass return the black color when value should be positive', () => {
        const params = {
            data:{
                curBal : -12
            }
        };
        params.data.curBal = 12;
        expect(service.balanceCellClass(params as any)).toBe('ag-right-aligned-cell');
    });
    it('cellbalanceCellClass should be executed with rowgroup row', () => {
        const params = {
            node:{
                group : 12
            },
            data:{
                curBal : 12
            }
        };
        params.node.group = 12;
        expect(service.balanceCellClass(params as any)).toBe(undefined);
    });
    it('costCenterValueGetter should be executed with rowgroup row', () => {
        const params = {
            node:{
                group : 12
            },
            data:{
                gLCostCtr : '0',
                gLCostCtrDesc :'description'
            }
        };
        params.node.group = 12;
        expect(service.costCenterValueGetter(params as any)).toBe(undefined);
    });
    it('costCenterValueGetter should be executed without rowgroup row', () => {
        const params = {
            node:{
                group : undefined
            },
            data:{
                gLCostCtr : '0',
                gLCostCtrDesc :'description'
            }
        };
        params.node.group = undefined;
        expect(service.costCenterValueGetter(params as any)).toBe('0 - description');
    });
    it('productCodeValueGetter should be executed with rowgroup row', () => {
        const params = {
            node:{
                group : 12
            },
            data:{
                gLProdCode : '0',
                gLProdDesc :'description'
            }
        };
        params.node.group = 12;
        expect(service.productCodeValueGetter(params as any)).toBe(undefined);
    });
    it('productCodeValueGetter should be executed without rowgroup row', () => {
        const params = {
            node:{
                group : undefined
            },
            data:{
                gLProdCode : '0',
                gLProdDesc :'description'
            }
        };
        params.node.group = undefined;
        expect(service.productCodeValueGetter(params as any)).toBe('0 - description');
    });
    it('branchCodeValueGetter should be executed with rowgroup row', () => {
        const params = {
            node:{
                group : 12
            },
            data:{
                brCode : '903',
                brDesc :'Protection'
            }
        };
        params.node.group = 12;
        expect(service.branchCodeValueGetter(params as any)).toBe(undefined);
    });
    it('branchCodeValueGetter should be executed without rowgroup row', () => {
        const params = {
            node:{
                group : undefined
            },
            data:{
                brCode : '903',
                brDesc :'Protection'
            }
        };
        params.node.group = undefined;
        expect(service.branchCodeValueGetter(params as any)).toEqual('903 - Protection');
    });
});
