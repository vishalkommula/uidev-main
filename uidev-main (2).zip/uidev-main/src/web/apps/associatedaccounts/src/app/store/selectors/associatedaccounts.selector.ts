import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AssociatedAccountsState } from '../state/associatedaccounts.state';




export const selectAssociatedAccountsRoot = createFeatureSelector<AssociatedAccountsState>('associatedAccounts');
// select assocaited Accounts selector
export const selectAssociatedAccountsDetails = createSelector(selectAssociatedAccountsRoot, (state: AssociatedAccountsState)=> state.associatedAccountsResponse);

// select Gl Accounts Inquiry selector
export const selectGlAccountInquiryDetails = createSelector(selectAssociatedAccountsRoot, (state: AssociatedAccountsState)=> state.glAccountInquiryResponse);

