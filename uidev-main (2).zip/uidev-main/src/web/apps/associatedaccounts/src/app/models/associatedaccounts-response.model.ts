import { SearchResponseHeaderModel, ViewParameterModel } from '@uid/uid-models';
import { GLAcctSrchRecItemModel } from './associatedaccounts-item.model';


export interface GLAcctSrchResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    acctId: string;
    acctType: string;
    gLAcctSrchRecArray: GLAcctSrchRecItemModel[];
    viewParameter: ViewParameterModel;
};
