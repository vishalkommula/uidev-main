export interface GLAcctSrchRecItemModel{
    acctTitle?: string;
    acctId?: string;
    gLTotalLvl?: number;
    curBal?: number;
    brCode?: string;
    brDesc?: string;
    gLCostCtr?: string;
    gLProdCode?: string;
    gLProdDesc?: string;
    gLCostCtrDesc?: string;
    gLInqType?: string;
};

