import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { DataService } from '../../service/data.service';
import * as associatedAccountsAction from '../actions/associatedaccounts.action';

@Injectable()
export class AssociatedAccountsEffects{
    constructor(private dataService: DataService, private action$: Actions){}

    getAssociatedAccountsDetails$ = createEffect(() => this.action$.pipe(
        ofType(associatedAccountsAction.getAssociatedAccounts),
        switchMap((action) =>
            this.dataService.getAssociatedAccountsDetails(action.request)
                .pipe(
                    map((response) => associatedAccountsAction.getAssociatedAccountsSuccess({ response })),
                    catchError((error)=> of(associatedAccountsAction.getAssociatedAccountsFailure({ error })))
                )
        )
    ));

    getGlAccountInquiryDetails$ = createEffect(() => this.action$.pipe(
        ofType(associatedAccountsAction.getGlAccountInquiry),
        switchMap((action) =>
            this.dataService.getGlAccountInquiryDetails(action.request)
                .pipe(
                    map((response) => associatedAccountsAction.getGlAccountInquirySuccess({ response })),
                    catchError((error)=> of(associatedAccountsAction.getGlAccountInquiryFailure({ error })))
                )
        )
    ));

}
