import { Component, OnInit, ViewChild } from '@angular/core';

// Ag grid
import { ColDef, GridApi, GridOptions } from 'ag-grid-enterprise';
import { GridReadyEvent, GridSizeChangedEvent, RowSelectedEvent } from 'ag-grid-community';

// UID
import { UidAggridComponent } from '@uid/uid-grid';

// NGRX
import { Store } from '@ngrx/store';
import { Observable, of, Subscription } from 'rxjs';
import * as AssociatedAccountsActions from '../../store/actions/associatedaccounts.action';
import * as AssociatedAccountsSelector from '../../store/selectors/associatedaccounts.selector';

// Models
import { GLAcctSrchRecItemModel } from '../../models/associatedaccounts-item.model';
import { AssociatedAccountsGridService } from './associatedaccounts-grid.def';
import { GLAcctSrchResponse } from '../../models/associatedaccounts-response.model';
import { GLAcctInqResponse } from '../../models/glaccountinquiry-reponse.model';
import { GLAcctInqRequest } from '../../models/glaccountinquiry-request.model';
import { isElementSupported } from '@uid/uid-utilities';

@Component({
    selector: 'uid-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  // to get uidGrid
  @ViewChild(UidAggridComponent) uidAggrid!: UidAggridComponent;

  public colDefs!: ColDef[];
  public gridOptions: GridOptions = {
      onGridSizeChanged: event => this.onGridSizeChanged(event),
      onGridReady: event => this.onGridReady(event),
      onRowSelected: event => this.onRowSelected(event)
  };
  public subs: Subscription [] =[];

  gridApi: GridApi = {} as GridApi;
  associatedAccountsActions = AssociatedAccountsActions;
  associatedAccountsSelector = AssociatedAccountsSelector;
  associatedAccountsDetails$: Observable<GLAcctSrchResponse> = of();
  glAccountInquiryDetails$: Observable<GLAcctInqResponse> = of();
  getAssociatedAccountsDetails !: GLAcctSrchRecItemModel[];
  glAccountInquiryDetails !: GLAcctInqResponse;
  gridColumnApi: any;
  productCodeDisplay !: boolean;

  constructor(private store: Store, private gridDef: AssociatedAccountsGridService) {
      this.associatedAccountsDetails$ = this.store.select(this.associatedAccountsSelector.selectAssociatedAccountsDetails);
      this.glAccountInquiryDetails$ = this.store.select(this.associatedAccountsSelector.selectGlAccountInquiryDetails);
  }

  ngOnInit(): void {
      this.gridOptions = { ...this.gridOptions, ...this.gridDef.gridOptions };
      this.store.dispatch(this.associatedAccountsActions.getAssociatedAccounts({ request: {} as any }));
      const associatedAccountsResponse = this.associatedAccountsDetails$.subscribe((res)=>{
          this.getAssociatedAccountsDetails = res.gLAcctSrchRecArray;
          const id = 'gLProdCode';
          this.productCodeDisplay = isElementSupported(id,res.viewParameter);
          this.colDefs = this.gridDef.associatedAccountsColumns(this.productCodeDisplay);
      });
      this.store.dispatch(this.associatedAccountsActions.getGlAccountInquiry({ request: {} as GLAcctInqRequest }));
      const glAccountInquiryResponse = this.glAccountInquiryDetails$.subscribe((res)=>{
          this.glAccountInquiryDetails = res;
      });
      this.subs.push(associatedAccountsResponse,glAccountInquiryResponse);
  }

  onGridReady(event: GridReadyEvent) {
      this.gridApi = event.api;
      this.gridApi.setColumnDefs(this.colDefs);
      this.gridColumnApi = event.columnApi;
      event.api.closeToolPanel();
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
      event.api.sizeColumnsToFit();
  }

  onRowSelected(event: RowSelectedEvent) {
      // if the selected node is grouped node, the first child node will be selected by default
      if (event.node.group) {
          event.node.setSelected(false);
      }
  }

  ngOnDestroy(): void {
      this.subs.forEach((sub) => sub.unsubscribe());
  }
}
