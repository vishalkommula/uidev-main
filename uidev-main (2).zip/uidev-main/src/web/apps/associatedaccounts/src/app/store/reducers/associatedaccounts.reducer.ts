import { createReducer, on } from '@ngrx/store';
import { GLAcctSrchResponse } from '../../models/associatedaccounts-response.model';
import { GLAcctInqResponse } from '../../models/glaccountinquiry-reponse.model';
import * as AssociatedAccountsActions from '../actions/associatedaccounts.action';
import { AssociatedAccountsState } from '../state/associatedaccounts.state';



export const initialAssociatedAccountsState: AssociatedAccountsState = {
    // associated accounts state
    associatedAccountsResponse: {} as GLAcctSrchResponse,
    glAccountInquiryResponse: {} as GLAcctInqResponse
};

export const associatedAccountsReducer = createReducer(
    initialAssociatedAccountsState,

    //   associated accounts reducer
    on(
        AssociatedAccountsActions.getAssociatedAccountsSuccess,
        (state, action): AssociatedAccountsState => ({
            ...state,
            associatedAccountsResponse:action.response
        })
    ),

    on(
        AssociatedAccountsActions.getGlAccountInquirySuccess,
        (state, action): AssociatedAccountsState => ({
            ...state,
            glAccountInquiryResponse:action.response
        })
    ),

);
