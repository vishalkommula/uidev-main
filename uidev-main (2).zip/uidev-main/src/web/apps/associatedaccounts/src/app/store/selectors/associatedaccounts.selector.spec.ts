import * as AssociatedAccountsSelector from './associatedaccounts.selector';

describe('Associated Accounts Selector Test',()=> {

    // Associated Accounts list selector test
    it('selectAssociatedAccountsDetails - should be excuted',()=> {
        const associatedAccountsListMock = { associatedAccountsResponse: [{ this: 'test data 1' },{ this: 'test data 2' }] };
        const selector = AssociatedAccountsSelector.selectAssociatedAccountsDetails.projector(associatedAccountsListMock);
        expect(selector).toEqual(associatedAccountsListMock.associatedAccountsResponse);
    });
    it('selectGlAccountInquiryDetails - should be excuted',()=> {
        const glAccountInquiryListMock = { glAccountInquiryResponse: [{ this: 'test data 1' },{ this: 'test data 2' }] };
        const selector = AssociatedAccountsSelector.selectGlAccountInquiryDetails.projector(glAccountInquiryListMock);
        expect(selector).toEqual(glAccountInquiryListMock.glAccountInquiryResponse);
    });
});
