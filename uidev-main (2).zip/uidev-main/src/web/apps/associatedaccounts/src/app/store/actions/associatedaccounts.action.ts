import { createAction, props } from '@ngrx/store';
import { GLAcctSrchRequest } from '../../models/associatedaccounts-request.model';
import { GLAcctSrchResponse } from '../../models/associatedaccounts-response.model';
import { GLAcctInqResponse } from '../../models/glaccountinquiry-reponse.model';
import { GLAcctInqRequest } from '../../models/glaccountinquiry-request.model';


// Associated accounts details request action
export const getAssociatedAccounts = createAction('[Associated Accounts] get data request', props<{ request: GLAcctSrchRequest }>());

// Associated accounts details action success response
export const getAssociatedAccountsSuccess = createAction('[Associated Accounts] get success response', props<{ response: GLAcctSrchResponse }>());

// Associated accounts Inquiry details action error response
export const getAssociatedAccountsFailure = createAction('[Associated Accounts] get failed response', props<{ error: Error }>());

// Associated accounts Inquiry details request action
export const getGlAccountInquiry = createAction('[Gl Account Inquiry] get data request', props<{ request: GLAcctInqRequest }>());

// Associated accounts Inquiry details action success response
export const getGlAccountInquirySuccess = createAction('[Gl Account Inquiry] get success response', props<{ response: GLAcctInqResponse }>());

// Associated accounts Inquiry details action error response
export const getGlAccountInquiryFailure = createAction('[Gl Account Inquiry] get failed response', props<{ error: Error }>());


