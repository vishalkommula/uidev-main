import { SearchRequestHeaderModel } from '@uid/uid-models';

export interface GLAcctSrchRequest {
    srchMsgRqHdr: SearchRequestHeaderModel;
    acctId: string;
    acctType: string;
    secondaryProductIsSupported: boolean;
};
