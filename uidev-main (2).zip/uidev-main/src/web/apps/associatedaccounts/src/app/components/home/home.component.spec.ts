import { ComponentFixture } from '@angular/core/testing';

import { HomeComponent } from './home.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { GLAcctSrchResponse } from '../../models/associatedaccounts-response.model';
import { GLAcctInqResponse } from '../../models/glaccountinquiry-reponse.model';
import { isElementSupported } from '@uid/uid-utilities';
import { of } from 'rxjs';
import { ColDef } from 'ag-grid-enterprise';

let component: HomeComponent;

const associatedAccountsActionsMock = {
    getAssociatedAccounts: jest.fn(),
    getGlAccountInquiry: jest.fn()
};
const associatedAccountsSelectorMock ={
    selectAssociatedAccountsDetails:jest.fn(),
    selectGlAccountInquiryDetails:jest.fn(),
};
const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() =>({
        subscribe:jest.fn(),
    })),
};
const gridDef = {
    associatedAccountsColumns : jest.fn()
};

describe('HomeComponent', () => {
    beforeEach(() => {
        component = new HomeComponent(storeMock as any,gridDef as any);
        component.associatedAccountsActions = associatedAccountsActionsMock as any;
        component.associatedAccountsSelector = associatedAccountsSelectorMock as any;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('associated accounts data should be fetched on oninit', () => {
        component.glAccountInquiryDetails$ = of({
            srchMsgRsHdr:   {} as any,
            acctId:          '1010',
            brCode:          '2',
            gLCostCtr:       '0',
            gGLProdCode:     '0'
        });
        component.associatedAccountsDetails$ = of({
            srchMsgRsHdr:   {} as any,
            acctId:          '1010',
            acctType:        'Gl',
            gLAcctSrchRecArray: [],
            viewParameter: {
                viewName: 'associated accounts',
                parameters : [
                    {
                        name: 'gLProdCode',
                        isSupported: true,
                        attributes:{
                            isHidden: false,
                            otherValue: 'no'
                        }
                    },
                ]
            }
        });
        component.ngOnInit();
        expect(associatedAccountsActionsMock.getAssociatedAccounts).toHaveBeenCalledWith({ request: {} as any });
        expect(associatedAccountsActionsMock.getAssociatedAccounts).toHaveBeenCalledTimes(1);
        expect(associatedAccountsActionsMock.getGlAccountInquiry).toHaveBeenCalledWith({ request: {} as any });
        expect(associatedAccountsActionsMock.getGlAccountInquiry).toHaveBeenCalledTimes(1);
        component.associatedAccountsDetails$.subscribe((res: GLAcctSrchResponse) =>{
            component.getAssociatedAccountsDetails = res.gLAcctSrchRecArray;
            const id =  'gLProdCode';
            component.productCodeDisplay = isElementSupported(id,res.viewParameter);
            component.colDefs = gridDef.associatedAccountsColumns(component.productCodeDisplay);
            expect(component.getAssociatedAccountsDetails).toEqual(res.gLAcctSrchRecArray);
            expect(component.colDefs).toEqual(gridDef.associatedAccountsColumns(component.productCodeDisplay));
        });
        component.glAccountInquiryDetails$.subscribe((res: GLAcctInqResponse)=>{
            component.glAccountInquiryDetails = res;
        });
    });
    it('onGridReady method - should be executed', () => {
        const event = { api: { closeToolPanel: jest.fn(), setColumnDefs: jest.fn(), }, columnApi: {} };

        component.associatedAccountsDetails$.subscribe((res: GLAcctSrchResponse) =>{
            component.getAssociatedAccountsDetails = res.gLAcctSrchRecArray;
            const id =  'gLProdCode';
            component.productCodeDisplay = isElementSupported(id,res.viewParameter);
            component.colDefs = gridDef.associatedAccountsColumns(component.productCodeDisplay);
            component.onGridReady(event as any);
            expect(component.gridApi.setColumnDefs).toBeCalled();
        });
    });
    it('onGridSizeChanged method - should be executed', () => {
        const event = {
            api:{
                sizeColumnsToFit:jest.fn()
            }
        } as any;
        component.onGridSizeChanged(event);
        const actualValue = event.api.sizeColumnsToFit;
        expect(actualValue).toBeCalled();
    });
    it('ngOnDestroy() method should be execute', () => {
        component.subs = [of([1, 2, 3]).subscribe()] as any;
        component.ngOnDestroy();
        expect(component.subs[0].closed).toBeTruthy();
    });
});
