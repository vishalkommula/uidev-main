import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { GLAcctSrchResponse } from '../models/associatedaccounts-response.model';
import  AssociatedAccountsSilverMockData from '../mock-data/associatedaccounts.silverlake.mock.json';
import  AssociatedAccountsCifMockData from '../mock-data/associatedaccounts.cif.mock.json';
import  GlAccountInquiryMockData from '../mock-data/glaccountinquiry.mock.json';
import { GLAcctSrchRequest } from '../models/associatedaccounts-request.model';
import { GLAcctInqRequest } from '../models/glaccountinquiry-request.model';
import { GLAcctInqResponse } from '../models/glaccountinquiry-reponse.model';

@Injectable({
    providedIn: 'root'
})
export class DataService {
    public secondaryProductIsSupported = false;
    constructor() { }

    getAssociatedAccountsDetails(request: GLAcctSrchRequest): Observable<GLAcctSrchResponse>{
        if(this.secondaryProductIsSupported === false){
            const silverLakeResponse = JSON.parse(JSON.stringify(AssociatedAccountsSilverMockData));
            return of(silverLakeResponse);
        } else{
            const cifResponse = JSON.parse(JSON.stringify(AssociatedAccountsCifMockData));
            return of(cifResponse);
        }
    }

    getGlAccountInquiryDetails(request: GLAcctInqRequest): Observable<GLAcctInqResponse>{
        const glAccountResponse = JSON.parse(JSON.stringify(GlAccountInquiryMockData));
        return of(glAccountResponse);
    }

}
