import { GLAcctSrchResponse } from '../../models/associatedaccounts-response.model';
import { GLAcctInqResponse } from '../../models/glaccountinquiry-reponse.model';

export interface AssociatedAccountsState{
    associatedAccountsResponse: GLAcctSrchResponse;
    glAccountInquiryResponse: GLAcctInqResponse;
}
