
import * as AssociatedAccountsActions  from '../actions/associatedaccounts.action';
import { associatedAccountsReducer, initialAssociatedAccountsState } from './associatedaccounts.reducer';


const expectedState = {
    associatedAccountsResponse :{} as any,
    glAccountInquiryResponse :{} as any
};

const responseData = { data: 'data' };

describe('Associated Accounts Reducers test', () => {

    it('getAssociatedAccountsSuccess - should be executed',()=>{
        const newState = initialAssociatedAccountsState;
        const state = associatedAccountsReducer(newState, AssociatedAccountsActions.getAssociatedAccountsSuccess({ response: responseData as any }));
        expectedState.associatedAccountsResponse = responseData;
        expect(state).toEqual(expectedState);
    });
    it('getGlAccountInquirySuccess - should be executed',()=>{
        const newState = initialAssociatedAccountsState;
        const state = associatedAccountsReducer(newState, AssociatedAccountsActions.getGlAccountInquirySuccess({ response: responseData as any }));
        expectedState.associatedAccountsResponse = {};
        expectedState.glAccountInquiryResponse = responseData;
        expect(state).toEqual(expectedState);
    });
});
