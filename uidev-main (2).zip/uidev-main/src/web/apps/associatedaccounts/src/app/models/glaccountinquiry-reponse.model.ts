import { SearchResponseHeaderModel } from '@uid/uid-models';

export interface GLAcctInqResponse {
    srchMsgRsHdr: SearchResponseHeaderModel;
    acctId: string;
    brCode: string;
    gLCostCtr: string;
    gGLProdCode: string;
};
