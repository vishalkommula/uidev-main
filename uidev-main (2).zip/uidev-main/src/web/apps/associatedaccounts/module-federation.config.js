module.exports = {
    ...require('../../module-federation.base.config'),
    name: 'associatedaccounts',
    exposes: {
        './Module': 'apps/associatedaccounts/src/app/components/home/home.module.ts',
    },
};
